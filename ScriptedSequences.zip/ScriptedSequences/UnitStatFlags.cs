using System;

namespace Kixeye.WCM.ScriptedSequences
{
    [Flags]
    public enum UnitStatFlags
    {
        Health = 1
    }
}

