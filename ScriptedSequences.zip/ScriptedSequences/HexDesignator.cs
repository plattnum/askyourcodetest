using System;
using System.Collections.Generic;
using GameTypes;
using ProtoBuf;
using WorldMap;
using Kixeye.WCM.WorldMap;
using WorldMap.Model;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class HexDesignator : UnityEngine.ScriptableObject, ISerializationCallbackReceiver
    {
        [Flags]
        public enum Ownership
        {
            Default = 0,
            Self = 1 << 0,
            Ally = 1 << 1,
            Enemy = 1 << 2,
            Unowned = 1 << 3,
            [Obsolete("TODO: WCM-43892 - remove")]Controlled = 1 << 4,
            [Obsolete("TODO: WCM-43892 - remove")]Contested = 1 << 5,

            All = Self | Ally | Enemy | Unowned,
        }

        /// <summary>
        /// Whether the condition is met when an actor with SpawnerId is selected
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SpawnerId")]
        [ProtoMember(1)]
        public string SpawnerId;

        [Newtonsoft.Json.JsonProperty("Occupied")]
        [ProtoMember(2)]
        public bool? Occupied;

        [Newtonsoft.Json.JsonProperty("ZoneActorTypes")]
        [ProtoMember(3)]
        public ZoneActorType ZoneActorTypes = ZoneActorType.All;

        [Newtonsoft.Json.JsonProperty("ZoneActorSubType")]
        [ProtoMember(4)]
        public int? ZoneActorSubType;

        [Newtonsoft.Json.JsonProperty("TargetOwnership")]
        [ProtoMember(5)]
        public Ownership TargetOwnership = Ownership.All;

        [Newtonsoft.Json.JsonProperty("InBounds")]
        [ProtoMember(6)]
        public bool? InBounds;

        [Newtonsoft.Json.JsonProperty("ZoneAreaDefinitionId")]
        [ProtoMember(7)]
        public string ZoneAreaDefinitionId;

        // skip 8

        [Newtonsoft.Json.JsonProperty("ExactHex")]
        [ProtoMember(9)]
        public HexCell? ExactHex;

        [NonSerialized]
        public ulong? ExactZoneActorId; // Only used at runtime


        public static HexDesignator Alloc()
        {
            return ScriptableObject.CreateInstance<HexDesignator>();
        }

        #region Unity Serialization Support

        [Serializable]
        public class NullableHexCell : NullableSerialization<HexCell>
        {
        }

        [SerializeField]
        protected NullableSerializedBool _occupied;

        [SerializeField]
        protected NullableSerializedInt _zoneActorSubType;

        [SerializeField]
        protected NullableSerializedBool _inBounds;

        [SerializeField]
        protected NullableHexCell _exactHex;

        public void OnBeforeSerialize()
        {
            _occupied = new NullableSerializedBool
            {
                Value = Occupied,
            };

            _zoneActorSubType = new NullableSerializedInt
            {
                Value = ZoneActorSubType,
            };

            _inBounds = new NullableSerializedBool
            {
                Value = InBounds,
            };

            _exactHex = new NullableHexCell
            {
                Value = ExactHex,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_occupied != null)
            {
                Occupied = _occupied.Value;
            }
            _occupied = null;

            if (_zoneActorSubType != null)
            {
                ZoneActorSubType = _zoneActorSubType.Value;
            }
            _zoneActorSubType = null;

            if (_inBounds != null)
            {
                InBounds = _inBounds.Value;
            }
            _inBounds = null;

            if (_exactHex != null)
            {
                ExactHex = _exactHex.Value;
            }
            _exactHex = null;
        }

#endregion

        public string GetDebugName()
        {
            var result = string.Empty;
            if (!string.IsNullOrEmpty(SpawnerId))
            {
                result += SpawnerId + " ";
            }
            else
            {
                result += Occupied.HasValue ? Occupied.Value ? "" : "Unoccupied " : "Occupied or Unoccupied ";
            }
            if (Ownership.All != (TargetOwnership & Ownership.All))
            {
                result += (TargetOwnership == Ownership.Self ? "Own" : TargetOwnership.ToString()) + " ";
            }
            if (ZoneActorType.All != (ZoneActorTypes & ZoneActorType.All))
            {
                result += ZoneActorTypes + " ";
            }
            if (!string.IsNullOrEmpty(ZoneAreaDefinitionId))
            {
                result += "in " + ZoneAreaDefinitionId;
            }
            return result;
        }

        public IEnumerable<string> GetErrors()
        {
            if (!string.IsNullOrEmpty(SpawnerId))
            {
                if (Occupied.GetValueOrDefault(false) != true)
                {
                    yield return "If spawner id is specified, we must check for the hex being occupied.";
                }
            }
        }

        public void Migrate(bool onCreate)
        {
            if (!string.IsNullOrEmpty(SpawnerId))
            {
                Occupied = true;
            }
        }

        public bool CheckConditionsForHex(ZoneActorInfo actorInHex, HexCell hexCell, WorldMapController worldMap, PlayerManager players)
        {
            return CheckConditionsForHex(actorInHex, hexCell.WorldPosition, worldMap, players);
        }

        public bool CheckConditionsForHex(ZoneActorInfo actorInHex, Position2Data position2d, WorldMapController worldMap, PlayerManager players)
        {
            var currentZone = worldMap.CurrentZone;
            if (currentZone == null)
            {
                return false;
            }

            if (ExactHex.HasValue)
            {
                if (ExactHex.Value.Index != HexGridUtils.SnapToHexIndex(position2d))
                {
                    // Failed check for exact hex.
                    return false;
                }
            }

            if (InBounds.HasValue || !string.IsNullOrEmpty(ZoneAreaDefinitionId))
            {
                var areas = currentZone.ZoneAreas.GetAreasContainingPoint(position2d);
                var inBounds = !areas.IsNullOrEmpty();
                if (InBounds.HasValue && inBounds != InBounds.Value)
                {
                    // Failed in-bounds check.
                    return false;
                }

                if (!string.IsNullOrEmpty(ZoneAreaDefinitionId))
                {
                    var restrictToZoneArea = worldMap.FindZoneAreaByDefinitionId(ZoneAreaDefinitionId);
                    if (!areas.Contains(restrictToZoneArea))
                    {
                        // Failed check hex is in a specific zone area.
                        return false;
                    }
                }
            }

            if (actorInHex == null)
            {
                actorInHex = currentZone.GetActor(position2d);
            }

            if (ExactZoneActorId.HasValue)
            {
                if (actorInHex == null ||
                    actorInHex.ZoneActorId != ExactZoneActorId.Value)
                {
                    // Failed check for exact actor.
                    return false;
                }
            }

            var occupied = actorInHex != null;

            if (Occupied.HasValue)
            {
                if (occupied != Occupied.Value)
                {
                    // Failed occupancy check.
                    return false;
                }
            }

            if (!string.IsNullOrEmpty(SpawnerId))
            {
                // TODO: Fix UI so this condition cannot be entered.
                if (!occupied || actorInHex.SpawnerId != SpawnerId)
                {
                    return false;
                }
            }

            if (ZoneActorTypes != ZoneActorType.Invalid)
            {
                if (occupied && 0 == (actorInHex.Type & ZoneActorTypes))
                {
                    // Failed actor type check.
                    return false;
                }
            }

            if (ZoneActorSubType.HasValue)
            {
                int flag = 1 << actorInHex.SubType;
                if ((ZoneActorSubType.Value & flag) == 0)
                {
                    return false;
                }
            }
            
            var targetOwnership = Ownership.Default;

            if (occupied)
            {
                if (actorInHex.IsOwnedByLocalPlayer()) targetOwnership |= Ownership.Self;
                if (actorInHex.IsMemberOfLocalPlayerAlliance()) targetOwnership |= Ownership.Ally;
                if (actorInHex.IsEnemy()) targetOwnership |= Ownership.Enemy;
                if (actorInHex.OwnerAllianceId == 0 && !actorInHex.OwnerPersonaId.IsPlayer) targetOwnership |= Ownership.Unowned;
            }

            if (targetOwnership == Ownership.Default)
            {
                targetOwnership = Ownership.Unowned;
            }

            if (0 == (TargetOwnership & targetOwnership))
            {
                return false;
            }

            return true;
        }
    }
}
