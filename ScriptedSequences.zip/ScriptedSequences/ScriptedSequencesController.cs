using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using GameTypes;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Input;
using Kixeye.WCM.ui;
using UnityEngine;
using UnityEngine.UI;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Kixeye.Common;
using Kixeye.Common.Audio;
using System.Text;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using LoadBaseManagementStep = Kixeye.WCM.WCMGameStateController.LoadBaseManagementStep;
using GameTypes.GameDefinitions;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    public class ScriptedSequencesController
    {
        #region Public constants

        public const string ASSET_SUBDIRECTORY = "StaticAssets";
        public const string PROTO_ASSET_SUBDIRECTORY = "StaticProtoAssets";
        public const string RELATIVE_RESOURCE_DIRECTORY = "ScriptedSequences";
        public const string PREFAB_DIRECTORY = "Prefabs";
        public static string RESOURCE_PATH
        {
            get { return Application.dataPath + "/" + ASSET_SUBDIRECTORY + "/"; }
        }
        public static string PROTO_RESOURCE_PATH
        {
            get { return Application.dataPath + "/" + PROTO_ASSET_SUBDIRECTORY + "/"; }
        }
        public static string FULL_RESOURCE_DIRECTORY
        {
            get { return RESOURCE_PATH + RELATIVE_RESOURCE_DIRECTORY + "/"; }
        }
        public static string FULL_PROTO_RESOURCE_DIRECTORY
        {
            get { return PROTO_RESOURCE_PATH + RELATIVE_RESOURCE_DIRECTORY + "/"; }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The JSON settings used to serialize all the data.
        /// </summary>
        private static JsonSerializerSettings _jsonSettings;

        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(ScriptedSequencesController));

        // TODO: Consider making this a Dictionary once we decide on a unique identifier
        private List<ScriptedSequence> _availableSequences = new List<ScriptedSequence>();

        /// <summary>
        /// A cached reference to the local player's data for updates.
        /// </summary>
        private Player _localPlayer;

        /// <summary>
        /// A cached reference to the local player's player details data for updates.
        /// </summary>
        private PlayerDetailsData LocalPlayerDetails { get { return _localPlayer == null ? null : _localPlayer.Data.PlayerDetails; } }

        /// <summary>
        /// Holds all tagged sound effects being played by Scripted Sequences.
        /// </summary>
        private readonly Dictionary<String, List<ISoundEffect>> _taggedSoundEffects = new Dictionary<string, List<ISoundEffect>>();

        /// <summary>
        /// Hold all of the scripted sequences log internally so they can be grouped together easily.
        /// </summary>
        static private StringBuilder _internalLog = new StringBuilder();

        /// <summary>
        /// The currently spawned _touchCatcher.
        /// </summary>
        private GameObject _touchCatcher
        {
            get
            {
                if (BaseSceneReferences.Instance == null)
                {
                    return null;
                }
                return BaseSceneReferences.Instance.TouchCatcher;
            }
        }

        /// <summary>
        /// A reference count that tracks how many handlers are active for the touch catcher so it can be disabled when it hits zero.
        /// </summary>
        private int _touchCatcherRefCount = 0;


        /// <summary>
        /// A bool indicating Initialize has already been called
        /// </summary>
        private bool _initialized = false;

        #endregion

        #region Public variables

        /// <summary>
        /// A public async token that consumers can use to know when all the sequences have finished loading an initializing.
        /// </summary>
        public SimpleAsyncToken LoadingToken = new SimpleAsyncToken();

        /// <summary>
        /// Holds a collection of all Indicators created by Scripted Sequences, mainly for cleanup.
        /// </summary>
        public readonly List<ScriptedSequenceIndicator> Indicators = new List<ScriptedSequenceIndicator>();

        public readonly Dictionary<string, GameObject> HighlightElementGameObjects = new Dictionary<string, GameObject>();

        #endregion

        #region Public Properties

        public enum Modes
        {
            Run,
            Pause,
            Slow,
            Step,
        }

        public float SlowDelay = 0.5f;

        private Modes _mode;

        private SimpleAsyncToken _breakpoint;

        public ISimpleAsyncToken Breakpoint
        {
            get
            {
                if (Mode == Modes.Slow)
                {
                    return WCMApplicationDirector.Instance.Scheduler.Delay(SlowDelay);
                }
                return _breakpoint;
            }
        }

        public Modes Mode
        {
            get
            {
                return _mode;
            }
            set
            {
                _mode = value;
                if (value == Modes.Run || value == Modes.Step)
                {
                    if (_breakpoint != null)
                    {
                        var breakpoint = _breakpoint;
                        _breakpoint = null;
                        breakpoint.Succeed();
                    }
                }
                if (value == Modes.Pause || value == Modes.Step)
                {
                    _breakpoint = new SimpleAsyncToken();
                }
            }
        }

        public IEnumerable<ScriptedSequence> AvailableSequences { get { return _availableSequences; } }

        /// <summary>
        /// Whether to output logging for ScriptedSequences.
        /// </summary>
        static public bool LoggingOn
        {
            get
            {
                if (WCMApplicationDirector.Instance != null &&
                    WCMApplicationDirector.Instance.UserConfig != null &&
                    WCMApplicationDirector.Instance.UserConfig.Data != null)
                {
                    return WCMApplicationDirector.Instance.UserConfig.Data.ScriptedSequenceLogging;
                }

                return false;
            }
        }

        /// <summary>
        /// Gets the local player data.
        /// </summary>
        public PlayerDetailsData LocalPlayerData
        {
            get { return LocalPlayerDetails; }
        }

        #endregion

        /// <summary>
        /// Occurs when a sequence is activated.
        /// </summary>
        public event Action<ScriptedSequenceNode> NodeActivated;

        /// <summary>
        /// Occurs when all sequences have been loaded. Used to ensure that chained sequences can be linked properly.
        /// </summary>
        public event Action AllSequencesLoaded = delegate { };

        /// <summary>
        /// Stores the reason for latest reset procedure
        /// </summary>
        public bool WasResetByAppResume { get; set; }

        #region Public methods

        /// <summary>
        /// Loads the scripted sequences availiable for the given player from data.
        /// </summary>
        /// <param name='forPlayer'>
        /// The player to load for.
        /// </param>
        public ISimpleAsyncToken Initialize()
        {
            if (_initialized)
            {
                SetBaseManagementStep(LoadBaseManagementStep.WillSSAppResume);
                ResetSequences(ResetReason.ApplicationResume);
                SetBaseManagementStep(LoadBaseManagementStep.DidSSAppResume);
                return new SimpleAsyncToken(true);
            }

            SetBaseManagementStep(LoadBaseManagementStep.SSInitBegin);
            _initialized = true;

            if (WCMApplicationDirector.Instance != null && WCMApplicationDirector.Instance.Events != null)
            {
                WCMApplicationDirector.Instance.Events.AddEventHandler<PlayersOnLocalPlayerSetEvent>(OnLocalPlayerSet);
            }

            // Load sequences.
            _availableSequences.Clear();
            IAsyncToken<IEnumerable<ScriptedSequence>> token = null;
#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
            if(TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
            {
                token = WCMAddressableManager.GetScriptedSequence();
            }
            else
#endif
            {
                string uri = WCMDataManager.GetScriptedSequencesURI(false);
                _logger.Debug(null, "Loading Sequences... from {0}", uri);

                token = WCMApplicationDirector.Instance.DataManager.GetAll<ScriptedSequence>(uri);
            }
            token.ReadyUnity((response) =>
           {
               if (response.Success)
               {
                   _logger.Debug(null, "Sequences Loaded!");
                   SetBaseManagementStep(LoadBaseManagementStep.SSInitWillStartSequences);

                    // sort them so they are processed in a consistent order.
                    var srcSequences = new List<ScriptedSequence>(response.Value);
                   srcSequences.Sort((a, b) =>
                   {
                       return string.CompareOrdinal(a.Name, b.Name);
                   });

                   for (int i = 0; i < srcSequences.Count; i++)
                   {
                        // we do not check against the local player, as that has not likely been set yet.
                        ScriptedSequence newSequence = srcSequences[i];
                       newSequence.Migrate(onCreate: false);
                       if (newSequence.Disabled == false)
                       {
                           newSequence.SetParents();
                           newSequence.InitializeSequence(this, OnNodeActivated);
                           _availableSequences.Add(newSequence);

#if UNITY_EDITOR
                            if (Application.isEditor)
                           {
                               VerifyTypes(newSequence);
                           }
#endif
                        }
                   }
                   foreach (var sequence in _availableSequences)
                   {
                       sequence.AllSequencesLoaded();
                   }
                   SetBaseManagementStep(LoadBaseManagementStep.SSInitDidStartSequences);
                   AllSequencesLoaded();
                   SetBaseManagementStep(LoadBaseManagementStep.SSInitComplete);
                   LoadingToken.Succeed();
               }
               else
               {
                   if (_logger.IsEnabled(LogMessageLevel.Error))
                   {
                       _logger.Error("Failed to load Scripted Sequences: " + response.Error);
                   }
                   LoadingToken.Fail(response.Error);
               }
           });

            return token.Simplify();
        }

        private void OnNodeActivated(ScriptedSequenceNode scriptedSequenceNode)
        {
            if (NodeActivated != null)
            {
                NodeActivated(scriptedSequenceNode);
            }
        }

        public void TouchHandlerAdd(UnityEngine.Events.UnityAction handler)
        {
            ++_touchCatcherRefCount;

            if (_touchCatcher != null)
            {
                _touchCatcher.GetComponent<Button>().onClick.AddListener(handler);
                _touchCatcher.transform.SetAsLastSiblingFast();
                _touchCatcher.SetActive(true);
                UGUIInputDisabler.DisableInteractionForAllExcept(_touchCatcher);
            }
        }

        public void TouchHandlerRemove(UnityEngine.Events.UnityAction handler)
        {
            if (_touchCatcher != null)
            {
                _touchCatcher.GetComponent<Button>().onClick.RemoveListener(handler);
            }

            if (_touchCatcherRefCount > 0)
            {
                _touchCatcherRefCount--;
            }

            if (_touchCatcherRefCount == 0 && _touchCatcher != null)
            {
                _touchCatcher.SetActive(false);
                UGUIInputDisabler.RemoveExceptionFromDisabledInteraction(_touchCatcher);
            }
        }

        public void TouchHandlerClick()
        {
            if (_touchCatcher != null)
            {
                _touchCatcher.GetComponent<Button>().onClick.Invoke();
            }
        }

        /// <summary>
        /// Returns true if the touch catcher is active and waiting to catch a touch.
        /// </summary>
        public bool TouchHandleIsActive()
        {
            return _touchCatcherRefCount > 0;
        }

        private bool _interactionDisabled;

        public bool UiInteractionDisabled { get { return _interactionDisabled; } }

        public bool LevelUpModalBypassShowConditions { get; set; }

        private bool _hasWMTutorialStarted = false;
        public bool HasWMTutorialStarted
        {
            get { return _hasWMTutorialStarted; }
            set { _hasWMTutorialStarted = value; }
        }
        private bool _hasWMTutorialFinished = false;
        public bool HasWMTutorialFinished
        {
            get { return _hasWMTutorialFinished; }
            set { _hasWMTutorialFinished = value; }
        }

        /// <summary>
        /// Disables UI events, with an optional exception for one UI element.
        /// </summary>
        /// <param name="exceptThis">A UI Element that will be excepted from the disable</param>
        public void DisableUI(GameObject exceptThis = null)
        {
            if (_interactionDisabled)
            {
                ReEnableUI();
            }

            if (exceptThis == null)
            {
                UGUIInputDisabler.DisableInteraction();
            }
            else
            {
                if (_touchCatcherRefCount > 0 && _touchCatcher != null)
                {
                    UGUIInputDisabler.DisableInteractionForAllExcept(_touchCatcher);
                }
                UGUIInputDisabler.DisableInteractionForAllExcept(exceptThis);
            }
            _interactionDisabled = true;
        }

        public void AddDisalbedUIException(GameObject exception)
        {
            UGUIInputDisabler.DisableInteractionForAllExcept(exception);
            _interactionDisabled = true;
        }

        /// <summary>
        /// Re-enables UI events if they have been disabled.
        /// </summary>
        public void ReEnableUI()
        {
            if (_interactionDisabled)
            {
                UGUIInputDisabler.EnableInteraction();
                _interactionDisabled = false;
            }
        }

        public void ForceReEnableUI()
        {
            UGUIInputDisabler.EnableInteraction();
            SSActionSetUIElementsVisible.ForceAllUIElementsVisible(this);
            _interactionDisabled = false;
        }

        /// <summary>
        /// Gets our JSON serializer settings and creates them if we havn't
        /// created them yet.
        /// </summary>
        /// <returns>The json settings.</returns>
        static public JsonSerializerSettings GetJsonSettings()
        {
            if (_jsonSettings == null)
            {
                _jsonSettings = new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                    DefaultValueHandling = DefaultValueHandling.Ignore,
                    TypeNameHandling = TypeNameHandling.All,
                    SerializationBinder = new WCMJsonSerializationBinder(),
                };
                _jsonSettings.Converters.Add(new StringEnumConverter());
            }
            return _jsonSettings;
        }

        /// <summary>
        /// Activates the sequence indicated by the name.
        /// </summary>
        /// <returns>
        /// True if the sequence was found and activated.   This bypasses all conditions and repetition limits.
        /// </returns>
        /// <param name='sequenceName'>
        /// The name of the sequence to activate.
        /// </param>
        /// <param name="leaveEnabled">if true, start conditions will be left enabled even if we had to force the sequence to start.</param>
        public bool ActivateSequenceByName(string sequenceName)
        {
            ScriptedSequence sequence = GetSequenceByName(sequenceName);
            if (sequence != null)
            {
                sequence.Reset(LocalPlayerDetails, ResetReason.ManualEnable);
                // Enable the sequence, then activate it if it didn't start automatically.
                if (!sequence.Enable())
                {
                    if (!sequence.AutoStart)
                    {
                        DisableStartConditions(sequence);
                    }

                    sequence.Activate();
                }
                return true;
            }
            return false;
        }

        private static void DisableStartConditions(ScriptedSequence sequence)
        {
            if (sequence.HasStartCondition)
            {
                foreach (var condition in sequence.Conditions)
                {
                    condition.Reset();
                    condition.Enabled = false;
                }
            }
            else if (sequence.NodeCount > 0)
            {
                foreach (var condition in sequence.Nodes.First().Conditions)
                {
                    condition.Reset();
                    condition.Enabled = false;
                }
            }
        }

        /// <param name="sequenceName">the name of the sequence to enable</param>
        /// <param name="leaveEnabled">If the sequence doesn't start now, it will start later when its conditions become met if it is left enabled.</param>
        /// <returns>true if the named sequence exists and is now executing (that is, its start conditions were met when it was enabled).</returns>
        public bool EnableSequenceByName(string sequenceName, bool leaveEnabled)
        {
            ScriptedSequence sequence = GetSequenceByName(sequenceName);
            if (sequence != null)
            {
                if (sequence.PlayerCanComplete(LocalPlayerDetails))
                {
                    sequence.Reset(LocalPlayerDetails, ResetReason.ManualEnable);
                    if (sequence.Enable())
                    {
                        return true;
                    }
                    if (!leaveEnabled)
                    {
                        sequence.Reset(LocalPlayerDetails, ResetReason.SequenceDisabled);
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Attempt to reload the Controller to a clean state.
        /// This resets all sequences to an active state - that the player hasn't already fully completed or,
        /// if the player isn't loaded, those sequences will be disabled OnLocalPLayerSet.
        /// </summary>
        public void Reset(ResetReason reason)
        {
            // remember reason for future use (see PlayerManger for details)
            WasResetByAppResume = (reason == ResetReason.ApplicationResume);
            _logger.Debug(null, "@@@ ScriptedSequences.Reset sets WasResetByAppResume to {0}", WasResetByAppResume);

            // Turn off the touch catcher completely
            _touchCatcherRefCount = 0;
            if (_touchCatcher != null)
            {
                _touchCatcher.SetActive(false);
            }

            // turn the UI on if it was disabled
            ReEnableUI();

            ClearIndicators();
            ClearHighlightElements();

            // Hide any open dialogue
            HideOpenedDialog(canBeShownLater: false);

            LetterboxWidget letterbox = SSActionLetterbox.GetLetterboxWidget();
            if (letterbox != null)
            {
                letterbox.gameObject.SetActive(false);
            }

            ResetSequences(reason);
        }

        /// <summary>
        /// Get rid of all indicators
        /// </summary>
        public void ClearIndicators()
        {
            for (int i = 0; i < Indicators.Count; i++)
            {
                ScriptedSequenceIndicator indicator = Indicators[i];
                if (!string.IsNullOrEmpty(indicator.PoolingPrefabName))
                {
                    WCMObjectPoolPreloader.DespawnObject(indicator.gameObject, indicator.PoolingPrefabName);
                }
            }
            Indicators.Clear();
        }

        // <summary>
        /// Get rid of all indicators
        /// </summary>
        public void ClearHighlightElements()
        {
            HighlightElementGameObjects.Clear();
        }

        /// <summary>
        /// Get rid of NPC dialog
        /// </summary>
        public void HideOpenedDialog(bool canBeShownLater)
        {
            // Hide opened dialog
            var uiController = UIController.Instance;
            if (uiController != null)
            {
                DialogOverlayWidget overlay = uiController.GetDialogOverlayInstance;
                if (overlay != null)
                {
                    overlay.HideDialogs(!canBeShownLater);
                }
            }
        }

        /// <summary>
        /// Open hidden NPC dialog
        /// </summary>
        public void ShowOpenedDialog()
        {
            var uiController = UIController.Instance;
            if (uiController != null)
            {
                // Show any open dialog not hidded by scripted sequences
                DialogOverlayWidget overlay = uiController.GetDialogOverlayInstance;
                if (overlay != null)
                {
                    overlay.ShowLastDialog();
                }
            }
        }

        /// <summary>
        /// Deactivates all active sequences.
        /// </summary>
        public void DeactivateAllActiveSequences()
        {
            foreach (ScriptedSequence sequence in _availableSequences)
            {
                sequence.Deactivate();
            }
        }

        /// <summary>
        /// Reset all sequences.
        /// 
        /// This is a suspicious operation: it runs while sequences are halfway
        /// done and might not leave things quite the way they are at startup.
        /// </summary>
        public void ResetSequences(ResetReason reason)
        {
            for (int i = 0, count = _availableSequences.Count; i < count; ++i)
            {
                var sequence = _availableSequences[i];
                try
                {
                    sequence.Reset(LocalPlayerDetails, reason);
                }
                catch (Exception exception)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(null, "Error resetting sequence {0} for {1}:\n{2}", sequence.Name, reason, exception);
                    }
                }
            }
        }

        /// <summary>
        /// Spawns a game object from a prefab, attaches it the the ui root, and returns the
        /// component of a specified type.
        /// The object's transform is set as if the new object were attached to the UI Root.
        /// </summary>
        /// <returns>The component attached to the UI root.</returns>
        /// <param name="prefab">The prefab to spawn.</param>
        /// <param name="exception">An error which occoured in the process.</param>
        /// <typeparam name="T">The type of component to return</typeparam>
        public static T SpawnComponentAndAttachToUIRoot<T>(GameObject prefab, out Exception exception) where T : MonoBehaviour
        {
            GameObject instantiatedObject = SpawnGameObjectAndAttachToNGUIPanelRoot(prefab, out exception);
            if (exception != null)
            {
                return null; // exception has already been set by SpawnGameObjectAndAttachToUIRoot.
            }

            T component = instantiatedObject.GetComponent<T>();
            if (component == null)
            {
                UnityEngine.Object.Destroy(instantiatedObject);
                exception = new Exception("Prefab doesn't contain needed component");
                return null;
            }

            return component;
        }

        /// <summary>
        /// Spawns a game object from a prefab, attaches it the the NGUI panel root,  
        /// and returns the game object.
        /// The object's transform is set as if the new object were attached to the 
        /// NGUI panel root.
        /// </summary>
        /// <returns>The component attached to the NGUI panel root.</returns>
        /// <param name="prefab">The prefab to spawn.</param>
        /// <param name="exception">An error which occoured in the process.</param>
        /// <typeparam name="T">The type of component to return</typeparam>
        public static GameObject SpawnGameObjectAndAttachToNGUIPanelRoot(GameObject prefab, out Exception exception)
        {
            if (prefab == null)
            {
                exception = new Exception("Prefab was null");
                return null;
            }
            GameObject instantiatedObject = UnityEngine.Object.Instantiate(prefab) as GameObject;
            if (instantiatedObject == null)
            {
                exception = new Exception("Failed to instantiate prefab: " + prefab.name);
                return null;
            }
            GameObject nguiPanelRoot = GameObject.FindGameObjectWithTag(Tags.NGUIPanelRoot);
            if (nguiPanelRoot == null)
            {
                UnityEngine.Object.Destroy(instantiatedObject);
                exception = new Exception("Couldn't find UI Root");
                return null;
            }

            exception = null;

            // Change the local position to the prefab's stored position, so it's as if
            // it was instantiated directly on the UI Root.
            var instantiatedObjectTransform = instantiatedObject.transform;
            Vector3 position = instantiatedObjectTransform.position;
            Vector3 scale = instantiatedObjectTransform.localScale;
            Quaternion rotation = instantiatedObjectTransform.rotation;
            instantiatedObjectTransform.SetParent(nguiPanelRoot.transform);
            instantiatedObjectTransform.localPosition = position;
            instantiatedObjectTransform.localScale = scale;
            instantiatedObjectTransform.localRotation = rotation;

            return instantiatedObject;
        }

        /// <summary>
        /// Spawns a game object from a prefab, attaches it the the ui canvas, and returns the
        /// component of a specified type.
        /// The object's transform is set as if the new object were attached to the UI canvas.
        /// </summary>
        /// <returns>The component attached to the UI canvas.</returns>
        /// <param name="prefab">The prefab to spawn.</param>
        /// <param name="exception">An error which occoured in the process.</param>
        /// <typeparam name="T">The type of component to return</typeparam>
        public static T SpawnComponentAndAttachToUICanvas<T>(GameObject prefab, out Exception exception) where T : MonoBehaviour
        {
            GameObject instantiatedObject = SpawnGameObjectAndAttachToUGUICanvas(prefab, out exception);
            if (exception != null)
            {
                return null; // exception has already been set by SpawnGameObjectAndAttachToUIRoot.
            }

            T component = instantiatedObject.GetComponent<T>();
            if (component == null)
            {
                UnityEngine.Object.Destroy(instantiatedObject);
                exception = new Exception("Prefab doesn't contain needed component");
                return null;
            }

            return component;
        }

        /// <summary>
        /// Spawns a game object from a prefab, attaches it the the UGUI canvas,
        /// and returns the game object.
        /// The object's transform is set as if the new object were attached to the 
        /// UGUI canvas.
        /// </summary>
        /// <returns>The component attached to the UGUI canvas.</returns>
        /// <param name="prefab">The prefab to spawn.</param>
        /// <param name="exception">An error which occoured in the process.</param>
        /// <typeparam name="T">The type of component to return</typeparam>
        public static GameObject SpawnGameObjectAndAttachToUGUICanvas(GameObject prefab, out Exception exception, Transform parentRoot = null)
        {
            if (prefab == null)
            {
                exception = new Exception("Prefab was null");
                return null;
            }
            GameObject instantiatedObject = UnityEngine.Object.Instantiate(prefab) as GameObject;
            if (instantiatedObject == null)
            {
                exception = new Exception("Failed to instantiate prefab: " + prefab.name);
                return null;
            }

            if (parentRoot == null && WCMApplicationDirector.Instance.UI != null)
            {
                parentRoot = WCMApplicationDirector.Instance.UI.PanelRoot;
            }

            if (parentRoot == null)
            {
                UnityEngine.Object.Destroy(instantiatedObject);
                exception = new Exception("Couldn't find UGUI Canvas");
                return null;
            }

            exception = null;

            instantiatedObject.transform.SetParent(parentRoot);

            RectTransform rectTransform = instantiatedObject.GetComponent<RectTransform>();
            if (rectTransform != null)
            {
                rectTransform.localScale = Vector3.one;
                rectTransform.localPosition = Vector3.zero;
                rectTransform.offsetMin = new Vector2();
                rectTransform.offsetMax = new Vector2();
            }

            return instantiatedObject;
        }

        /// <summary>
        /// Adds a sound effect with the given tag to the tagged sound effects dictionary.
        /// </summary>
        public void AddSoundEffectWithTag(ISoundEffect effect, string tag)
        {
            List<ISoundEffect> effects;
            if (!_taggedSoundEffects.TryGetValue(tag, out effects))
            {
                effects = new List<ISoundEffect>();
                _taggedSoundEffects.Add(tag, effects);
            }
            effects.Add(effect);
        }

        /// <summary>
        /// Removes the sound effect with the given tag from the tagged sound effects dictionary.
        /// </summary>
        public void RemoveSoundEffectWithTag(ISoundEffect effect, string tag)
        {
            List<ISoundEffect> effects;
            if (!_taggedSoundEffects.TryGetValue(tag, out effects))
            {
                return;
            }
            effects.Remove(effect);
        }

        /// <summary>
        /// Removes all sound effects with the given tag from the tagged sound effects dictionary.
        /// </summary>
        public void RemoveAllSoundEffectsWithTag(string tag)
        {
            _taggedSoundEffects.Remove(tag);
        }

        /// <summary>
        /// Returns all sound effects with the given tag.
        /// </summary>
        public IEnumerable<ISoundEffect> GetSoundEffectsWithTag(string tag)
        {
            List<ISoundEffect> effects;
            if (!_taggedSoundEffects.TryGetValue(tag, out effects))
            {
                return System.Linq.Enumerable.Empty<ISoundEffect>();
            }
            return effects;
        }

        /// <summary>
        /// Helper function to get a named prefab.
        /// </summary>
        /// <returns>
        /// The prefab gameObject.
        /// </returns>
        /// <param name='prefabName'>
        /// Prefab name.
        /// </param>
        static public UnityEngine.GameObject LoadPrefab(string prefabName)
        {
            string prefabLocation = RELATIVE_RESOURCE_DIRECTORY + "/" + prefabName;
            GameObject go = Resources.Load(prefabLocation) as GameObject;
            if (go == null)
            {
                Log.GetLoggerForType(typeof(ScriptedSequence)).Error("Failed to load prefab " + prefabLocation);
            }
            return go;
        }

        /// <summary>
        /// Gets Dialog Overlay from UI prefab
        /// </summary>
        /// <returns></returns>
        public static IAsyncToken<GameObject> GetDialogOverlay()
        {
            if (WCMApplicationDirector.Instance.UI == null)
                return null;

            return WCMApplicationDirector.Instance.UI.GetDialogOverlay();
        }

        /// <summary>
        /// Logs the specified message to the scripted sequence log.
        /// </summary>
        /// <param name='message'>
        /// the message to log.
        /// </param>
        static public void AppendLineToScriptedSequenceLog(string message)
        {
            _internalLog.AppendLine(message);
        }

        /// <summary>
        /// Gets the current conents of the Scripted Sequence log.
        /// </summary>
        static public string GetCurrentLog()
        {
            return _internalLog.ToString();
        }

        /// <summary>
        /// Clears the Scripted Sequence log.
        /// </summary>
        static public void ClearLog()
        {
            _internalLog.Length = 0;
        }

        public void CompleteSequence(ScriptedSequence sequence)
        {
            var completions = GetSequenceCompletionCountByName(sequence.Name);
            var newCompletions = sequence.NumberOfTimesRepeatable;
            WCMApplicationDirector.Instance.PlayerProcessor.MarkScriptedSequenceComplete(sequence.Name, newCompletions - completions);
        }

        public void UncompleteSequence(ScriptedSequence sequence)
        {
            var completions = GetSequenceCompletionCountByName(sequence.Name);
            WCMApplicationDirector.Instance.PlayerProcessor.MarkScriptedSequenceComplete(sequence.Name, -completions);
        }

        public void RemoveSequence(ScriptedSequence sequence)
        {
            if (_availableSequences.Contains(sequence))
            {
                sequence.Deactivate();
                _availableSequences.Remove(sequence);
            }
        }

        /// <summary>
        /// Returns the available sequence with the given name.
        /// Returns null if the sequence doesn't exist or isn't available.
        /// </summary>
        public ScriptedSequence GetSequenceByName(string name, bool ignoreMissingSequence = false)
        {
            for (int i = 0, count = _availableSequences.Count; i < count; ++i)
            {
                if (_availableSequences[i].Name == name)
                {
                    return _availableSequences[i];
                }
            }
            if (!ignoreMissingSequence)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn("Unable to find sequence " + name);
                }
            }
            return null;
        }

        /// <summary>
        /// Returns the available sequence with the given name.
        /// Returns null if the sequence doesn't exist or isn't available.
        /// </summary>
        public int GetSequenceCompletionCountByName(string name)
        {
            if (LocalPlayerDetails == null)
            {
                return 0;
            }
            int value;
            LocalPlayerDetails.CompletedSequences.TryGetValue(name, out value);
            return value;
        }

        public void OnScriptedSequenceCompleted(PlayerDataProcessorScriptedSequenceCompletedEvent eventData)
        {
            ScriptedSequence sequence = GetSequenceByName(eventData.Name);

            if (sequence != null && LocalPlayerDetails != null)
            {
                sequence.OnSequenceMarkedCompleted(eventData.TimesCompleted, LocalPlayerDetails);
            }
        }

        #endregion

        #region Private methods

        public bool PlayerReloadTriggeredBySequence { get; set; }

        private void OnLocalPlayerSet(PlayersOnLocalPlayerSetEvent eventData)
        {
            OnLocalPlayerSet(eventData.LocalPlayer);
        }

        /// <summary>
        /// Callback for when the global local player is set.  Caches a reference to the details because getting them is slow.
        /// </summary>
        private void OnLocalPlayerSet(Player localPlayer)
        {
            _localPlayer = localPlayer;

            if (localPlayer != null)
            {
                if (!PlayerReloadTriggeredBySequence)
                {
                    SetBaseManagementStep(LoadBaseManagementStep.SSLocalPlayerSetWait);
                    LoadingToken.Ready(_ =>
                        {
                            // init the WM tutorial started/finished settings
                            _hasWMTutorialStarted = false;
                            _hasWMTutorialFinished = true;
                            bool skipIncompleteWorldMapNux = WCMApplicationDirector.Instance.GameData.TuningValueAsBool(TuningDefinitionType.SkipIncompleteWorldMapNux);
                            foreach (var s in _availableSequences)
                            {
                                if (_logger.IsEnabled(LogMessageLevel.Debug))
                                {
                                    _logger.Debug("Completion count for sequence " + s.Name + " is " + GetSequenceCompletionCountByName(s.Name));
                                }

                                // if at least one WM Tutorial sequence is available and complete then the WM Tutorial is started
                                if (!_hasWMTutorialStarted && s.IsWorldMapJavelinTutorialSequence && s.TimesPlayerHasCompleted(LocalPlayerDetails) > 0)
                                {
                                    _hasWMTutorialStarted = true;
                                }

                                // if at least one WM Tutorial sequence is available and incomplete then the WM Tutorial is not finished
                                if (_hasWMTutorialFinished && s.IsWorldMapJavelinTutorialSequence && s.TimesPlayerHasCompleted(LocalPlayerDetails) < 1)
                                {
                                    // if the player did not complete the WM NUX on the first play through but we are auto-completing it on the server, that doesn't actually happen
                                    // until after this runs on the client the first time the player logs in afterwards (on subsequent loads it's fine). So catch that case and 
                                    // don't mark the WMNUX tutorial as unfinished (keep finished = true)
                                    if (_hasWMTutorialStarted && skipIncompleteWorldMapNux) 
                                    {
                                        if (_logger.IsEnabled(LogMessageLevel.Debug))
                                        {
                                            _logger.Debug("SkipIncompleteWorldMapNux is true and the WM tutorial has started so we are considering the WM tutorial finished");
                                        }
                                        continue;
                                    }
                                    
                                    if (_logger.IsEnabled(LogMessageLevel.Debug))
                                    {
                                        _logger.Debug("Marking the the WM tutorial as not finished.");
                                    }
                                    _hasWMTutorialFinished = false;
                                }
                            }
                            SetBaseManagementStep(LoadBaseManagementStep.SSLocalPlayerSetWillReset);
                            Reset(ResetReason.LocalPlayerChanged);
                            SetBaseManagementStep(LoadBaseManagementStep.SSLocalPlayerSetDidReset);
                        });
                }
                else
                {
                    SetBaseManagementStep(LoadBaseManagementStep.SSLocalPlayerSetIgnored);
                }
            }
        }

        /// <summary>
        /// Verifies that all the types of Scripted Sequence components are register for proper serialization.
        /// </summary>
        private void VerifyTypes(ScriptedSequence sequence)
        {
            WCMJsonSerializationBinder binder = WCMApplicationDirector.Instance.Config.JsonSerializerSettings.SerializationBinder as WCMJsonSerializationBinder;
            if (binder == null)
            {
                Log.Error(this, "Could not find JsonSerializationBinder to verify types");
                return;
            }
            foreach (ScriptedSequenceNode node in sequence.Nodes)
            {
                foreach (ScriptedSequenceComponent component in node.Components)
                {
                    Type type = component.GetType();
                    string name = type.Namespace + "." + type.Name;
                    if (!binder.IsTypeInMap(name, type))
                    {
                        Log.Error(this, "Scritped Sequence type " + name + " is not properly registered in WCMJsonSerializationBinder!");
                    }
                }
            }
        }

        private void DeactivateCompletedSequences()
        {
            for (int i = 0, count = _availableSequences.Count; i < count; ++i)
            {
                if (!_availableSequences[i].PlayerCanComplete(LocalPlayerDetails))
                {
                    _availableSequences[i].Deactivate();
                }
            }
        }

        #endregion

        [System.Diagnostics.Conditional("DEBUG")]
        public void SetBaseManagementStep(LoadBaseManagementStep step)
        {
            if (WCMApplicationDirector.Instance != null && WCMApplicationDirector.Instance.Events != null)
            {
                WCMApplicationDirector.Instance.Events.HandleEvent(WCMGameStateController.LoadBaseManagementEvent.GetInstance(step));
            }
        }
    }
}
