using System;
using GameTypes;
using UnityEngine;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Describes a IUITarget.
    /// </summary>
    [Serializable]
    public class UITargetDesignator
    {
        /// <summary> 
        /// Defines ways to define a target.
        /// </summary>
        public enum TouchType
        {
            WorldPosition,
            UIPosition,
            Building,
            Squad
        }

        /// <summary>
        /// A IUITarget for the last set position.
        /// </summary>
        private IUITarget _positionTarget;

        /// <summary>
        /// The last set position. This is backing.
        /// </summary>
        private PositionData _position;


        /// <summary>
        /// The serialized backing field for position
        /// </summary>
        [JsonProperty("Position")]
        [ProtoMember(2)]
        public PositionData Position
        {
            get
            {
                return _position;
            }
            set
            {
                CreateUITarget();
                _position = value;
            }
        }

        /// <summary>
        /// The type of IUITarget designated.
        /// </summary>
        private TouchType _type;

        [JsonProperty("Type")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(1)]
        public TouchType Type
        {
            get
            {
                return _type;
            }
            set
            {
                if(_type != value)
                {
                    _type = value;
                    CreateUITarget();
                }
            }
        }

        /// <summary>
        /// A squad designator if this UITarget is a squad.
        /// </summary>
        [JsonProperty("Squad")]
        [ProtoMember(3)]
        public SquadDesignator Squad
        {
            get { return _squad; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _squad = new SquadDesignator();


        /// <summary>
        /// A building designator if this UITarget is a building.
        /// </summary>
        [JsonProperty("Building")]
        [ProtoMember(4)]
        public BuildingDesignator Building
        {
            get { return _building; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _building = new BuildingDesignator();

        /// <summary>
        /// Returns a IUITarget based on this designator.
        /// </summary>
        /// <returns>The target.</returns>
        public IUITarget GetTarget()
        {
            switch(Type)
            {
            case TouchType.UIPosition:
            case TouchType.WorldPosition:
                return _positionTarget;

            case TouchType.Building:
                Building building = Building.GetBuilding();
                if(building != null)
                {
                    return building;
                }
                break;

            case TouchType.Squad:
                Squad squad = Squad.GetSquad();
                if(squad != null)
                {
                    return squad;
                }
                break;
            }
            return null;
        }

        /// <summary>
        /// Factory for creating the cached IUITarget, based on the last set position
        /// and the current type.
        /// </summary>
        private void CreateUITarget()
        {
            if(_type == TouchType.UIPosition)
            {
                _positionTarget = new UITarget(_position);
            }
            else
            {
                _positionTarget = new WorldPositionTarget(_position);
            }
        }

    }
}

