using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using GameTypes;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SquadDesignator
    {
        public enum PlayerOwner
        {
            Local,
            Opponent,
        }

        #region Serialized properties

        /// <summary>
        /// The player the squad belongs to
        /// </summary>
        [Newtonsoft.Json.JsonProperty("PlayerOwningSquad")]
        [ProtoMember(1)]
        public PlayerOwner PlayerOwningSquad;

        /// <summary>
        /// DEPRECATED.  This remains to convert old data.  Used to be the platoon containing the squad.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Platoon")]
        [ProtoMember(2)]
        public int OldPlatoonIndex = 0;
        
        /// <summary>
        /// The squad to be selected.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Squad")]
        [ProtoMember(3)]
        public int SquadIndex = 0;

        /// <summary>
        /// Which platoon within the given type (e.g. Ground Platoon #2 would be... well 1 because it's zero-based).
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("PlatoonNumber")]
        [ProtoMember(4)]
        public int PlatoonNumber = 0;

        public enum PlatoonSearchType
        {
            GroundPlatoon,
            AirPlatoon,
            StoragePlatoon,
            FirstViableSquad,
            NearestViableSquad,
            Any,
            ArtilleryPlatoon,
            AnyNonCivilian,
            SelectedGroundPlatoon,
            BuildingPlatoon,
            DesignerPlatoon,
        }

        /// <summary>
        /// The type of platoon designated
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfPlatoon")]
        [ProtoMember(5)]
        public PlatoonSearchType TypeOfPlatoon;

        /// <summary>
        /// Which rally point to select.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BuildingDesignator")]
        [ProtoMember(6)]
        public BuildingDesignator BuildingDesignator;

        [DataMember(Order = 7)]
        public int MigrationVersion;

        [OnSerializing, Obsolete("For serialization only.")]
        public void OnSerializing(StreamingContext streamingContext)
        {
            MigrationVersion = 1;
        }

        [OnDeserialized, Obsolete("For serialization only.")]
        public void OnDeserialized(StreamingContext streamingContext)
        {
            if (MigrationVersion < 1)
            {
                if (PlayerOwningSquad == PlayerOwner.Local &&
                    TypeOfPlatoon == PlatoonSearchType.GroundPlatoon &&
                    PlatoonNumber > 0)
                {
                    TypeOfPlatoon = PlatoonSearchType.DesignerPlatoon;
                }
            }
        }
        #endregion

        #region public variables

        [JsonIgnore]
        [NonSerialized]
        public int StorageUnitType = UnitTypeConstant.Invalid;

        #endregion

        #region constants

        public const int STORAGE_SQUAD = -1;
        public const int FIRST_VIABLE_SQUAD = -2;

        #endregion

        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SquadDesignator));
        
        #region Public methods

        public override string ToString()
        {
            if (TypeOfPlatoon == PlatoonSearchType.BuildingPlatoon)
            {
                return "{0} {1} #{2}".FormatWith(
                    PlayerOwningSquad,
                    BuildingDesignator,
                    SquadIndex);
            }
            return "{0} {1} {2}/{3}".FormatWith(
                PlayerOwningSquad,
                TypeOfPlatoon.ToString().Replace("Platoon", ""),
                PlatoonNumber,
                SquadIndex);
        }

        public Squad GetSquad()
        {
            Platoon platoon;
            Player player;
            return GetSquad(out player, out platoon);
        }

        /// <summary>
        /// Gets the nearest squad to the specified position.
        /// </summary>
        /// <param name="position">Position to use as a reference.</param>
        /// <returns></returns>
        public Squad GetNearestSquadToPosition(PositionData position)
        {
            if (TypeOfPlatoon != PlatoonSearchType.NearestViableSquad)
            {
                if (_logger.IsEnabled(LogMessageLevel.Error))
                {
                    _logger.Error("Invalid platoon type specified.");
                }
                return null;
            }

            AttackData attackData = null;
            IState currentState = WCMApplicationDirector.Instance.GameStates.CurrentState;
            if (currentState is AttackingState)
            {
                attackData = (currentState as AttackingState).AttackData;
                if (attackData == null)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error("Tried to get the nearest viable squad when not in an Attacking state.");
                    }
                    return null;
                }
            }

            if (PlayerOwningSquad != PlayerOwner.Local)
            {
                if (_logger.IsEnabled(LogMessageLevel.Error))
                {
                    _logger.Error("Tried to get the nearest viable squad for the non-local player.  This is not supported yet.");
                }
                return null;
            }

            Platoon owningPlatoon = attackData.GroundPlatoon;
            if (owningPlatoon == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Error))
                {
                    _logger.Error( "Attacking Ground Platoon could not be found for the indicated player.");
                }
                return null;
            }

            // get the nearest viable squad
            float nearestSquadDistanceSqr = float.MaxValue;
            float distanceSqr = 0f;
            Squad nearestSquad = null;
            for (int i = 0, count = owningPlatoon.Squads.Count; i < count; ++i)
            {
                Squad curSquad = owningPlatoon.Squads[i];
                if (!curSquad.IsDead && !curSquad.IsEmpty && curSquad.IsDeployed)
                {
                    distanceSqr = (position - curSquad.Position).sqrMagnitude;
                    if (distanceSqr < nearestSquadDistanceSqr)
                    {
                        nearestSquadDistanceSqr = distanceSqr;
                        nearestSquad = curSquad;
                    }
                }
            }

            return nearestSquad;
        }

        public Squad GetSquad(out Player owningPlayer, out Platoon owningPlatoon)
        {
            // get the player that owns the squad to be selected
            owningPlayer = null;
            owningPlatoon = null;

            AttackData attackData = null;
            IState currentState = WCMApplicationDirector.Instance.GameStates.CurrentState;
            if (currentState is AttackingState)
            {
                attackData = (currentState as AttackingState).AttackData;
            }

            if (PlayerOwningSquad == PlayerOwner.Local)
            {
                owningPlayer = GetPlayer(PlayerOwningSquad);
            }
            else
            {
                if (attackData == null)
                {
                    return null;
                }
                owningPlayer = attackData.AttackTargetData.DefendingPlayer;
            }

            if (owningPlayer == null)
            {
                return null;
            }
            if (owningPlayer.Army == null)
            {
                return null;
            }

            // get the squad
            Squad squad = null;
            if (TypeOfPlatoon == PlatoonSearchType.Any || TypeOfPlatoon == PlatoonSearchType.AnyNonCivilian)
            {
                if (_logger.IsEnabled(LogMessageLevel.Error))
                {
                    _logger.Error("Cannot use Any type if the script needs to retrieve a single squad");
                }
                return null;
            }
            if (TypeOfPlatoon == PlatoonSearchType.StoragePlatoon)
            {
                if (StorageUnitType == UnitTypeConstant.Invalid)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error("Must specify a unit type to get the proper storage squad.");
                    }
                    return null;
                }
                owningPlatoon = owningPlayer.Headquarters.StoragePlatoon;
                squad = owningPlayer.Headquarters.GetStorageSquad(StorageUnitType, false);
            }
            else if (TypeOfPlatoon == PlatoonSearchType.FirstViableSquad ||
                     TypeOfPlatoon == PlatoonSearchType.SelectedGroundPlatoon)
            {
                if (PlayerOwningSquad != PlayerOwner.Local)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error("Tried to get the first viable squad for the non-local player.  This is not supported yet.");
                    }
                    return null;
                }
                if (attackData == null)
                {
                    return null;
                }
                owningPlatoon = attackData.GroundPlatoon;
                if (owningPlatoon == null)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error("Attacking Ground Platoon could not be found for the indicated player.");
                    }
                    return null;
                }
                if (TypeOfPlatoon == PlatoonSearchType.FirstViableSquad)
                {
                    for (int i = 0, count = owningPlatoon.Squads.Count; i < count; ++i)
                    {
                        Squad curSquad = owningPlatoon.Squads[i];
                        if (!curSquad.IsDead && !curSquad.IsEmpty)
                        {
                            return curSquad;
                        }
                    }
                    return null;
                }
                else if (SquadIndex < 0 || SquadIndex >= owningPlatoon.Squads.Count)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(string.Format("Squad {0} could not be found in the given platoon. It may be created later.", SquadIndex));
                    }
                    return null;
                }
                squad = owningPlatoon.Squads[SquadIndex];
            }
            else if(TypeOfPlatoon == PlatoonSearchType.BuildingPlatoon)
            {
                var buildings = BuildingDesignator.GetBuildings(owningPlayer.ActiveBase).ToArrayAvoidClone();
                if (buildings.IsNullOrEmpty())
                {
                    _logger.Error(null, "Could not find building with tag [{0}].", BuildingDesignator);
                    return null;
                }
                if (buildings.Length > 1)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(null, "Multiple buildings matched {0}: {1}", BuildingDesignator, buildings.Join());
                    }
                }
                var building = buildings[0];
                owningPlatoon = building.Platoon;
                if (owningPlatoon == null)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error(null, null, "Building has no platoon:  {0} (tag: {1})", building, BuildingDesignator);
                    }
                    return null;
                }
                if (SquadIndex < 0 || SquadIndex >= owningPlatoon.Squads.Count)
                {
                    if (_logger.IsEnabled(LogMessageLevel.Error))
                    {
                        _logger.Error(null, "Squad {0} could not be found in the platoon of {1} (tag: {2}).", SquadIndex, building, BuildingDesignator);
                    }
                    return null;
                }
                squad = owningPlatoon.Squads[SquadIndex];
                return squad;
            }
            else
            {
                // get the requested platoon
                if (TypeOfPlatoon == PlatoonSearchType.AirPlatoon)
                {
                    if (PlatoonNumber >= 0 && PlatoonNumber < owningPlayer.Army.AirforcePlatoons.Count)
                    {
                        owningPlatoon = owningPlayer.Army.AirforcePlatoons[PlatoonNumber];
                    }
                }
                else if (TypeOfPlatoon == PlatoonSearchType.ArtilleryPlatoon)
                {
                    if (owningPlayer.Army.ArtilleryPlatoon == null) // we should force the system to add Artillery Platoon if there's not such thing
                    {
                        var artilleryPlatoon = new PlatoonData() { ID = owningPlayer.NextAvailableGameItemIndex, Type = GameTypes.PlatoonType.Artillery };
                        artilleryPlatoon.SquadList.Add(new SquadData() { ID = owningPlayer.NextAvailableGameItemIndex });
                        owningPlayer.Army.SetArtilleryPlatoon(combatBuffsPlatoonData: artilleryPlatoon);
                    };
                    owningPlatoon = owningPlayer.Army.ArtilleryPlatoon;
                }
                else if (TypeOfPlatoon == PlatoonSearchType.DesignerPlatoon)
                {
                    while (PlatoonNumber >= owningPlayer.Army.DesignerPlatoons.Count)
                    {
                        var platoonData = new PlatoonData { Name = "Designer Platoon", ID = owningPlayer.Army.DesignerPlatoons.Count, Type = PlatoonType.Designer };
                        for (int i = 0; i < Constants.MAX_SQUADS_PER_PLATOON; ++i)
                        {
                            platoonData.SquadList.Add(new SquadData { ID = i });
                        }
                        owningPlayer.Army.AddDesignerPlatoon(platoonData);
                    }
                    owningPlatoon = owningPlayer.Army.DesignerPlatoons[PlatoonNumber];
                }
                else
                {
                    if (PlatoonNumber >= 0 && PlatoonNumber < owningPlayer.Army.GroundPlatoons.Count)
                    {
                        owningPlatoon = owningPlayer.Army.GroundPlatoons[PlatoonNumber];
                    }
                }

                if (owningPlatoon == null)
                {
                    string platoonTypeName;
                    switch (TypeOfPlatoon)
                    {
                        case PlatoonSearchType.AirPlatoon:
                            platoonTypeName = "Air Platoon";
                            break;
                        case PlatoonSearchType.ArtilleryPlatoon:
                            platoonTypeName = "Artillery Platoon";
                            break;
                        case PlatoonSearchType.GroundPlatoon:
                        default:
                            platoonTypeName = string.Format("{0} {1}", TypeOfPlatoon, PlatoonNumber);
                            break;
                    }

                    if (PlayerOwningSquad == PlayerOwner.Local)
                    {
                        if (_logger.IsEnabled(LogMessageLevel.Error))
                        {
                            _logger.Error(string.Format("{0} could not be found for the local player.", platoonTypeName));
                        }
                    }
                    else if (_logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(string.Format("{0} could not be found for the opposing player, but it is about to be created.", platoonTypeName));
                    }
                    return null;
                }

                if (SquadIndex < 0 || SquadIndex >= owningPlatoon.Squads.Count)
                {
                    if (PlayerOwningSquad == PlayerOwner.Local)
                    {
                        if (_logger.IsEnabled(LogMessageLevel.Warn))
                        {
                            _logger.Warn(string.Format("Squad {0} could not be found in the given platoon. It may be created later.", SquadIndex));
                        }
                    }
                    return null;
                }
                squad = owningPlatoon.Squads[SquadIndex];
            }

            return squad;
        }

        /// <summary>
        /// Checks if this squad designator would designate the given squad.
        /// </summary>
        /// <param name="squad">The squad to check.</param>
        public bool IsSquad(Squad squad)
        {
            if (TypeOfPlatoon == PlatoonSearchType.Any)
            {
                return squad.Player.IsLocal == (PlayerOwningSquad == PlayerOwner.Local);
            }

            if (TypeOfPlatoon == PlatoonSearchType.AnyNonCivilian)
            {
                return (squad.Player.IsLocal == (PlayerOwningSquad == PlayerOwner.Local)) && (squad.PerformingPlayerCommand);
            }

            try
            {
                return squad == GetSquad();
            }
            catch (ApplicationException)
            {
                return false;
            }
        }

        /// <summary>
        /// Returns the player opposing the owner of the designated squad.
        /// </summary>
        /// <returns>
        /// The opposing player.
        /// </returns>
        public Player GetOpposingPlayer()
        {
            return GetPlayer(PlayerOwningSquad == PlayerOwner.Local ? PlayerOwner.Opponent : PlayerOwner.Local);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Gets the player specified by the enum.
        /// </summary>
        private Player GetPlayer(PlayerOwner playerToGet)
        {
            if (playerToGet == PlayerOwner.Local)
            {
                return WCMApplicationDirector.Instance.Players.LocalPlayer;
            }
            else
            {
                AttackData attackData = null;
                IState currentState = WCMApplicationDirector.Instance.GameStates.CurrentState;
                if (currentState is AttackingState)
                {
                    attackData = (currentState as AttackingState).AttackData;
                }

                if (attackData == null)
                {
                    throw new ApplicationException("Could not find AttackData to get opponent.  Is the game in an attack or defend state?");
                }

                return attackData.AttackTargetData.DefendingPlayer;
            }
        }

        #endregion
    }
}