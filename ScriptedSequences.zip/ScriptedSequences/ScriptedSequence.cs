using System;
using System.Linq;
using System.Collections.Generic;
using GameTypes;
using Kixeye.Core.Analytics.Funnel;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;
using Kixeye.WCM.GameData;
using Ninject;
using ProtoBuf;
using Kixeye.Core.Analytics;

namespace Kixeye.WCM.ScriptedSequences
{
    public enum ComparisonType
    {
        Equals,
        GreaterThan,
        LessThan,
    }

    /// <summary>
    /// Scripted Sequences are designed to be used whenever we need to interrupt the normal flow of gameplay 
    /// whether it be to present new information or story, or to teach the user a new feature such as in the 
    /// introduction tutorial or ongoing throughout the game.  A scripted sequence consists of conditions that when 
    /// met will start the sequence and series of actions that will be executed when the sequence starts.
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    public class ScriptedSequence : UnityEngine.ScriptableObject, IScriptedSequenceComponentParent, ISaveAsset
    {
        private const int CurrentMigrationVersion = 2;

        [Flags]
        [Serializable]
        public enum Group
        {
            Legacy = 1 << 0,

            ContestableBase = 1 << 8,
            Campaign = 1 << 9,

            Tutorial = 1 << 16,
            Combat = 1 << 17,
            WorldMap = 1 << 18,
            BaseManagement = 1 << 19,
            Crafting = 1 << 20,
            Javelin = 1 << 21,
        }

        #region Serialized Properties
        /// <summary>
        /// Unique name of the sequence.  Based on the filename.
        /// </summary>
        [JsonProperty("Name")]
        [ProtoMember(1)]
        public string Name;

        /// <summary>
        /// The parts of this sequence
        /// </summary>
        [JsonProperty("NodeList")]
        [ProtoMember(2)]
        public List<ScriptedSequenceNode> _nodes = new List<ScriptedSequenceNode>();

        /// <summary>
        /// The number of times this scripted sequence can execute.  0 means any amount.
        /// </summary>
        [JsonProperty("NumberOfTimesRepeatable")]
        [ProtoMember(3)]
        public int NumberOfTimesRepeatable;

        /// <summary>
        /// If true this sequence will be thrown out on load.  Useful for test sequences or examples.
        /// </summary>
        [JsonProperty("Disabled")]
        [ProtoMember(4)]
        public bool Disabled = false;

        /// <summary>
        /// If true, calling <see cref="Enable"/> will have no effect.
        /// </summary>
        [JsonIgnore]
        public bool RuntimeDisabled;

        /// <summary>
        /// After logging in (choosing to connect to social or as a guest) the player will (temporarily) be given the
        /// option to skip the in-base tutorial.  If this is true then this sequence will be identified as one of the ones
        /// to skip.
        /// </summary>
        [JsonProperty("SkippablePostLogin")]
        [ProtoMember(5)]
        [Obsolete("Use Group.Tutorial instead.")]
        public bool SkippablePostLogin = false;

        /// <summary>
        /// The conditions that must be met for this sequence to activate.
        /// </summary>
        [JsonProperty("Conditions")]
        [ProtoMember(7)]
        public List<ScriptedSequenceCondition> Conditions
        {
            get
            {
                if (_conditions == null)
                {
                    _conditions = new List<ScriptedSequenceCondition>();
                }
                return _conditions;
            }
            set
            {
                _conditions = value;
            }
        }
        [UnityEngine.SerializeField]
        private List<ScriptedSequenceCondition> _conditions = null;

        /// <summary>
        /// The actions that are executed when this sequence activates.
        /// </summary>
        [JsonProperty("Actions")]
        [ProtoMember(8)]
        public List<ScriptedSequenceAction> Actions
        {
            get
            {
                if (_actions == null)
                {
                    _actions = new List<ScriptedSequenceAction>();
                }
                return _actions;
            }
            set
            {
                _actions = value;
            }
        }
        [UnityEngine.SerializeField]
        private List<ScriptedSequenceAction> _actions = null;

        /// <summary>
        /// If true this sequence will have a start condition which must be met for the sequence to start.
        /// </summary>
        [JsonProperty("HasStartCondition")]
        [ProtoMember(9)]
        public bool HasStartCondition = false;

        /// <summary>
        /// Sequences with this flag set get the opportunity to run in place of the normal transition to base view.
        /// Only one script with this flag should be runnable at a time.
        /// </summary>
        [JsonProperty("EvaluateAtGameLoad")]
        [ProtoMember(10)]
        public bool EvaluateAtGameLoad;

        [JsonProperty("MigrationVersion")]
        [ProtoMember(11)]
        public int MigrationVersion;

        /// <summary>
        /// "AutoStart" sequences are always active and ready-to-run.  Other sequences are only activated explicitly by other sequences or game s
        /// </summary>
        [JsonProperty("AutoStart")]
        [ProtoMember(12)]
        public bool AutoStart;

        [JsonProperty("Description")]
        [ProtoMember(13)] // No need to distribute to clients, but if we don't serializa here we lose descriptions when live-editing in-game.
        public string Description;

        /// <summary>
        /// Groups are used to organize sequences so we can provide features like "skip worlmap nux" to QA.
        /// </summary>
        [JsonProperty("Groups")]
        [ProtoMember(14)]
        public Group Groups;

        ///// <summary>
        ///// While useful for missions, this feature is almost always wrong for
        ///// any other script and causes hard-to-understand bugs.  This flag
        ///// lets us change the default for nodes, which for historical reasons
        ///// defaulted to true
        ///// </summary>
        //[JsonProperty("AllowDisableOnReplay")]
        //[ProtoMember(15)]
        //public bool AllowDisableOnReplay;
        #endregion

#if UNITY_EDITOR
        public void WriteTo(AssetSaver saver)
        {
            _nodes.ForAll(it => it.WriteTo(saver));
            Actions.ForAll(it => it.WriteTo(saver));
            Conditions.ForAll(it => it.WriteTo(saver));
            saver.Save(this, isMaster: true);
        }
#endif

        /// <summary>
        /// Provides a way to iterate over the nodes while not allowing the list to be modified.
        /// </summary>
        [JsonIgnore]
        public IEnumerable<ScriptedSequenceNode> Nodes
        {
            get { return _nodes as IEnumerable<ScriptedSequenceNode>; }
        }

#if UNITY_EDITOR
        /// <summary>
        /// TEMP: Remove this once drag/drop is implemented and we don't provide a generic list to DrawSequenceNode
        /// </summary>
        public List<ScriptedSequenceNode> TempNodesAccessor
        {
            get { return _nodes; }
        }
#endif

        /// <summary>
        /// Gets the number of nodes in the sequence.
        /// </summary>
        public int NodeCount
        {
            get { return _nodes.Count; }
        }

        public bool IsTutorialSequence
        {
            get
            {
                var desired = Group.Tutorial;
                return desired == (Groups & desired);
            }
        }

        public bool IsWorldMapTutorialSequence
        {
            get
            {
                var desired = Group.Tutorial | Group.WorldMap;
                return desired == (Groups & desired);
            }
        }

        public bool IsWorldMapJavelinTutorialSequence
        {
            get
            {
                var desired = Group.Tutorial | Group.WorldMap | Group.Javelin;
                return desired == (Groups & desired);
            }
        }

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        public ScriptedSequencesController ScriptedSequences { get; private set; }

        ScriptedSequence IScriptedSequenceComponent.ScriptedSequence { get { return this; } }

        /// <summary>
        /// Used to keep track of the last node in the sequence, for sequence completion.
        /// </summary>
        private ScriptedSequenceNode _exitNode = null;

        /// <summary>
        /// Occurs when a sequence is completed, passing through the count of times the script has been completed
        /// </summary>
        public event Action<int> SequenceCompleted = delegate { };

        private const string CombatNuxLoad = "CombatNuxIntoBaseLoad";

        private const string CombatNux = "CombatNUX";

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(ScriptedSequence));

        #region Constructor
        public ScriptedSequence()
        {
        }
        #endregion

        #region IScriptedSequenceComponentParent
        /// <summary>
        /// Called whenever a start condition's status has changed.
        /// </summary>
        /// <param name="conditionThatChanged">Condition that changed.</param>
        public void OnConditionMetChanged(ScriptedSequenceCondition conditionThatChanged)
        {
            ScriptedSequenceNode.EnableNextCondition(Conditions, conditionThatChanged);
            if (AreTheStartConditionsMet())
            {
                Enable();
            }
        }

        public string GetDebugName()
        {
            return Name;
        }

        public string GetDebugNameFull()
        {
            return Name;
        }
        #endregion IScriptedSequenceComponentParent Implementation

        #region Public methods
        public void LogDebug(string format, params object[] args)
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                var message = format.FormatWith(args);
                message = "{0}: {1}".FormatWith(Name, message);
                _logger.Debug(message);
                ScriptedSequencesController.AppendLineToScriptedSequenceLog(message);
            }
        }

        public void LogError(string format, params object[] args)
        {
            if (_logger.IsEnabled(LogMessageLevel.Error))
            {
                var message = format.FormatWith(args);
                message = "{0}: {1}".FormatWith(Name, message);
                _logger.Error(message);
                ScriptedSequencesController.AppendLineToScriptedSequenceLog(message);
            }
        }

        public void Migrate(bool onCreate)
        {
            if (onCreate)
            {
                MigrationVersion = CurrentMigrationVersion;
            }
            else
            {
                if (MigrationVersion < 1)
                {
                    // The old "convention" was that nodes without conditions 
                    // would never run unless explicitly activated.
                    var firstNode = _nodes.FirstOrDefault();
                    if (firstNode != null)
                    {
                        if (firstNode.Conditions.Any())
                        {
                            AutoStart = true;
                        }
                    }
                    MigrationVersion = 1;
                }
                if (MigrationVersion < 2)
                {
#pragma warning disable 0618, 0612 // deprecated field
                    if (SkippablePostLogin)
#pragma warning restore 0618, 0612 // deprecated field
                    {
                        // These are all part of the old Base NUX.
                        Disabled = true;
                    }
                    if (Disabled)
                    {
                        // We haven't disabled any modern scripts yet.
                        Groups |= Group.Legacy;
                    }
                    if (EvaluateAtGameLoad)
                    {
                        Groups |= Group.Tutorial;
                    }
                    if (string.IsNullOrEmpty(Name))
                    {
                        if (_logger.IsEnabled(LogMessageLevel.Warn))
                        {
                            _logger.Warn("Sequence has no name!");
                        }
                        Name = "";
                    }
                    if (Name.StartsWith("Tutorial") || Name == "Unit parade")
                    {
                        Groups |= Group.Tutorial;
                        Groups |= Group.Combat;
                    }
                    if (Name.StartsWith("WMNUX_"))
                    {
                        Groups |= Group.Tutorial;
                        Groups |= Group.WorldMap;
                    }
                    if (Name.StartsWith("CB"))
                    {
                        Groups |= Group.ContestableBase;
                    }
                    if (Name.StartsWith("CP"))
                    {
                        Groups |= Group.Campaign;
                    }
                    MigrationVersion = 2;
                }
                if (MigrationVersion != CurrentMigrationVersion)
                {
                    throw new ApplicationException("Please update CurrentMigrationVersion!");
                }
            }
            this.MigrateConditionsAndActions(onCreate);
            for (int i = 0, count = _nodes.Count; i < count; i++)
            {
                _nodes[i].Migrate(onCreate);
            }
        }

        /// <summary>
        /// Initializes the sequence.
        /// </summary>
        public void InitializeSequence(ScriptedSequencesController controller, Action<ScriptedSequenceNode> onNodeActivated)
        {
            Migrate(onCreate: false);
            if (controller == null)
            {
                Log.Error(this, "controller parameter cannot be null");
                return;
                //throw new ArgumentNullException("controller");
            }
            ScriptedSequences = controller;
            if (onNodeActivated != null)
            {
                NodeActivated += onNodeActivated;
            }
            _exitNode = null;

            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                ScriptedSequenceNode node = _nodes[i];
                if (i == count - 1)
                {
                    _exitNode = node;
                }
                node.Initialize(this, OnNodeActivated);
            }

            if (HasStartCondition)
            {
                // if we have start conditions, initialize them
                foreach (var condition in Conditions)
                {
                    condition.Initialize(this);
                }
            }
        }

        public void AllSequencesLoaded()
        {
            if (AutoStart)
            {
                Enable();
            }
        }

        public bool Enable()
        {
            if (RuntimeDisabled)
            {
                return false;
            }

            if (HasStartCondition && !AreTheStartConditionsMet())
            {
                // Start the condition chain
                Conditions[0].Enabled = true;
            }
            else
            {
                // Enable all nodes, then activate the first if it has no
                // conditions.  (If it had conditions, the conditions would be
                // responsible for activating it.)
                foreach (var node in Nodes)
                {
                    node.Enable(ScriptedSequences.LocalPlayerData);
                }
                var firstNode = _nodes.FirstOrDefault();
                if (firstNode != null && firstNode.Conditions.IsNullOrEmpty())
                {
                    firstNode.Activate();
                    // Don't need to check for satisfied conditions below.
                    return true;
                }
            }

            if (HasStartCondition)
            {
                return AreTheStartConditionsMet();
            }

            if (NodeCount == 0)
            {
                return true;
            }

            // Returning the first node's state lets ActivateSequenceByName() know it has to bypass start conditions.
            return _nodes[0].AllConditionsMet;
        }

        /// <summary>
        /// Sets the parent properties of every component and node.
        /// </summary>
        public void SetParents()
        {
            SetParentsForConditions(Conditions, this);
            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                ScriptedSequenceNode node = _nodes[i];
                node.Parent = this;

                for (int j = 0, count2 = node.Actions.Count; j < count2; ++j)
                {
                    node.Actions[j].Parent = node;
                }

                SetParentsForConditions(node.Conditions, node);
            }
        }

        /// <summary>
        /// Sets the parent properties of every condition.
        /// </summary>
        public void SetParentsForConditions(List<ScriptedSequenceCondition> conditions, IScriptedSequenceComponentParent parent)
        {
            for (int j = 0, count2 = conditions.Count; j < count2; ++j)
            {
                SSConditionLogicalOperatorBase logicalConditions = conditions[j] as SSConditionLogicalOperatorBase;
                if (logicalConditions != null)
                {
                    IScriptedSequenceComponentParent parentCondition = conditions[j] as IScriptedSequenceComponentParent;
                    if (parentCondition != null)
                    {
                        SetParentsForConditions(logicalConditions.Conditions, parentCondition);
                    }
                }
                conditions[j].Parent = parent;
            }
        }

        /// <summary>
        /// Checks if the start conditions for this sequence are met.
        /// </summary>
        /// <returns>Return true if the conditions are met, false otherwise.</returns>
        public bool AreTheStartConditionsMet()
        {
            if (HasStartCondition)
            {
                foreach (var condition in Conditions)
                {
                    if (condition.Met == false)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Activates the first node of the sequence.
        /// </summary>
        public void Activate()
        {
            if (_nodes.Count > 0 && _nodes[0] != null)
            {
                _nodes[0].Activate();
            }
        }

        /// <summary>
        /// Deactivate this sequence by disabling all its conditions.
        /// </summary>
        public void Deactivate()
        {
            if (_conditions != null)
            {
                for (int i = 0, count = _conditions.Count; i < count; ++i)
                {
                    _conditions[i].Enabled = false;
                }
            }

            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                ScriptedSequenceNode node = _nodes[i];
                for (int j = 0, count2 = node.Conditions.Count; j < count2; ++j)
                {
                    node.Conditions[j].Enabled = false;
                }
            }
        }

        /// <summary>
        /// Activates the node after the specified node.
        /// </summary>
        /// <param name='node'>
        /// The node in this sequence before the one to be activated.
        /// </param>
        public void ActivateNodeAfter(ScriptedSequenceNode node)
        {
            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                if (_nodes[i] == node && i < count - 1)
                {
                    _nodes[i + 1].Activate();
                    return;
                }
            }

            LogError("Couldn't find node to activate after " + node.GetDebugNameFull());
        }

        /// <summary>
        /// Returns true if the given player can still complete the sequence.
        /// </summary>
        /// <param name='thePlayer'>
        /// The data for the player (that stores which sequences have been completed).
        /// </param>
        public bool PlayerCanComplete(PlayerDetailsData thePlayer)
        {
            if (NumberOfTimesRepeatable > 0)
            {
                if (thePlayer == null ||
                    TimesPlayerHasCompleted(thePlayer) >= NumberOfTimesRepeatable)
                {
                    // Can't be triggered any more.  Alas.
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Gets a new ID for a node to be added to this sequence.
        /// </summary>
        public int GetNewNodeID()
        {
            int highestID = -1;
            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                if (_nodes[i].NodeID > highestID)
                {
                    highestID = _nodes[i].NodeID;
                }
            }

            return highestID + 1;
        }

        /// <summary>
        /// Adds a node to this sequence
        /// </summary>
        /// <param name='node'>
        /// The node to be added.
        /// </param>
        public void AddNode(ScriptedSequenceNode node)
        {
            AddNodeAt(_nodes.Count, node);
        }

        /// <summary>
        /// Adds a node to this sequence
        /// </summary>
        /// <param name='index'>
        /// The index at which the node will be added.  Any nodes currently at that index or past will be moved back one.
        /// </param>
        /// <param name='node'>
        /// The node to be added.
        /// </param>
        public void AddNodeAt(int index, ScriptedSequenceNode node)
        {
            if (node.Parent != null)
            {
                node.Parent.RemoveNode(node);
            }
            node.NodeID = GetNewNodeID();
            if (node.Name == null || node.Name.Substring(0, 5) == "Node ")
            {
                node.Name = "Node " + node.NodeID;
            }
            else
            {
                int nameCount = 0;
                // find the number of nodes with the same name
                for (int i = 0, count = _nodes.Count; i < count; ++i)
                {
                    if (_nodes[i].Name == node.Name)
                    {
                        nameCount++;
                    }
                }
                if (nameCount > 0)
                {
                    node.Name = node.Name + " (" + nameCount + ")";
                }
            }
            node.Parent = this;
            _nodes.Insert(index, node);
        }

        /// <summary>
        /// Adds a given node to this sequence after another node in the sequence's list.
        /// </summary>
        /// <param name='nodeToMove'>
        /// Node to add.
        /// </param>
        /// <param name='nodeToMoveAfter'>
        /// Node to put the other node after.
        /// </param>
        public void AddNodeAfter(ScriptedSequenceNode nodeToMove, ScriptedSequenceNode nodeToMoveAfter)
        {
            int prevNodeID = -1;
            if (nodeToMove.Parent == this)
            {
                // preserve the node id if we're moving inside the sequence
                prevNodeID = nodeToMove.NodeID;
            }
            if (nodeToMove.Parent != null)
            {
                nodeToMove.Parent.RemoveNode(nodeToMove);
            }
            int index = Nodes.IndexOf(nodeToMoveAfter);
            AddNodeAt(index + 1, nodeToMove);
            if (prevNodeID > -1)
            {
                nodeToMove.NodeID = prevNodeID;
            }
        }

        /// <summary>
        /// Removes the given node from this sequence.
        /// </summary>
        /// <returns>
        /// Whether a node was removed or not
        /// </returns>
        /// <param name='node'>
        /// The node to remove.
        /// </param>
        public bool RemoveNode(ScriptedSequenceNode node)
        {
            if (node.Parent != this)
            {
                Log.Error(this, "Cannot remove: Node " + node.ToString() + " is not contained by this sequence.");
                return false;
            }
            node.Parent = null;
            return _nodes.Remove(node);
        }

        /// <summary>
        /// Returns the node with the given ID.
        /// </summary>
        /// <param name='nodeID'>
        /// The ID of the node to return.
        /// </param>
        /// NOTE: This is a little slow since it just iterates through looking, but it shouldn't be called much.
        /// The list can easily be converted to a dictionary if necessary.
        public ScriptedSequenceNode GetNodeByID(int nodeID)
        {
            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                if (_nodes[i].NodeID == nodeID)
                {
                    return _nodes[i];
                }
            }

            return null;
        }

        // TODO: This is temporary.  This will eventually use the stats system
        /// <summary>
        /// Returns the number of times the player has completed this sequence.
        /// </summary>
        /// <param name='forPlayer'>
        /// The player data to check against.
        /// </param>
        public int TimesPlayerHasCompleted(PlayerDetailsData forPlayer)
        {
            if (forPlayer == null)
            {
                return 0;
            }

            int timesCompleted;
            if (!forPlayer.CompletedSequences.TryGetValue(Name, out timesCompleted))
            {
                return 0;
            }

            return timesCompleted;
        }

        /// <summary>
        /// Forces the completion of a sequence. 
        /// If the deactivate parameter is false, it only marks the sequence as completed, without deactivating it.
        /// </summary>
        /// <param name="disable">True if the sequence is to be deactivated.</param>
        public void ForceCompletion(bool disable)
        {
            if (disable)
            {
                RuntimeDisabled = true;
            }
            MarkPlayerHasCompleted();
        }

        #endregion

        #region Private methods

        public event Action<ScriptedSequenceNode> NodeActivated;

        /// <summary>
        /// The callback for when a node has met its conditions and been activated.
        /// </summary>
        /// <param name='node'>
        /// The node that has activated.
        /// </param>
        private void OnNodeActivated(ScriptedSequenceNode node)
        {
            if (WCMApplicationDirector.Instance.Players == null ||
                WCMApplicationDirector.Instance.Players.LocalPlayer == null ||
                WCMApplicationDirector.Instance.Players.LocalPlayer.Data == null ||
                WCMApplicationDirector.Instance.Players.LocalPlayer.Data.PlayerDetails == null)
            {
                Log.Error(this, "ScriptedSequence " + Name + " is completing but there is no local player to mark completion for.");
                return;
            }

            if (NodeActivated != null)
            {
                // Temporarily disable quality manager's zoom scalar for any enabled sequence (or cinemas pop at the end).
                // UGLY hack in order to ensure this dummy SS doesn't break zoom scalar stuff on the Scouting Screen.
                if (!WCMApplicationDirector.Instance.ZoomScalarDisabled && !Name.Equals("Audio_Campaign_Load_Banks"))
                {
                    WCMApplicationDirector.Instance.ZoomScalarDisabled = true;
                }
                NodeActivated(node);
            }

            if (node == _exitNode)
            {
                MarkPlayerHasCompleted();
            }
        }

        /// <summary>
        /// Resets condition enabled states so the node can be re-executed properly
        /// or deactivates it if the player has completed it too many times.
        /// </summary>
        public void Reset(PlayerDetailsData localPlayerDetails, ResetReason reason)
        {
            if (RuntimeDisabled)
            {
                LogDebug("Deactivating sequence at runtime.");
                Deactivate();
                return;
            }

            // Sequences that aren't auto-start shouldn't stay enabled, instead
            // they should wait to be triggered through code or by another sequence.
            // They also should not reset on battle complete, which is intended
            // to reset sequences that are part of combat missions.
            if (!AutoStart && reason != ResetReason.BattleComplete && reason != ResetReason.ManualEnable)
            {
                LogDebug("Deactivating sequence since it isn't auto-start.");
                Deactivate();
                return;
            }

            if (!PlayerCanComplete(localPlayerDetails) && reason != ResetReason.ManualEnable)
            {
                LogDebug("Deactivating sequence at it reached maximum repeats.");
                Deactivate();
                return;
            }

            LogDebug("Resetting sequence {0}", reason);

            for (int i = 0, count = _nodes.Count; i < count; ++i)
            {
                ScriptedSequenceNode node = _nodes[i];
                node.Reset();
                // There used to be very few sequences with start conditions
                // so the bug caused by skipping the enable on reset wasn't visible.
                // Sequences that have start conditions should be triggered when we enable them below.
                if (!HasStartCondition || i != 0)
                {
                    node.Enable(localPlayerDetails);
                }
            }

            // reset the start conditions, must be the same as the logic in nodes
            // TODO: Push all the condition stuff into shared code! This is mostly identical to Node.Reenable()
            if (HasStartCondition)
            {
                for (int i = 0, count = Conditions.Count; i < count; ++i)
                {
                    var condition = Conditions[i];
                    condition.Reset(); // Met -> false
                    condition.Enabled = false;
                }
                if (AutoStart)
                {
                    if (Conditions.Count > 0)
                    {
                        Conditions[0].Enabled = true;
                    }
                    else
                    {
                        Activate();
                    }
                }
            }
        }

        // TODO: This is temporary.  This will eventually use the stats system
        /// <summary>
        /// Marks that the player has completed this sequence.
        /// </summary>
        /// <param name='forPlayer'>
        /// The player data to save completion in.
        /// </param>
        private void MarkPlayerHasCompleted()
        {
            SendFunnelStopMessage();
            if (WCMApplicationDirector.Instance.PlayerProcessor != null)
            {
                WCMApplicationDirector.Instance.PlayerProcessor.MarkScriptedSequenceComplete(Name, 1);
            }
        }

        public void OnSequenceMarkedCompleted(int timesCompleted, PlayerDetailsData localPlayerDetails)
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("OnSequenceMarkedCompleted " + Name + " - Completion #" + timesCompleted);
            }
            // let watchers on this sequence know that it's been completed
            SequenceCompleted(timesCompleted);

            // reset the sequence for another run (or deactivate it)
            Reset(localPlayerDetails, ResetReason.SequenceComplete);
        }
        #endregion

        #region Funnel-related
        public void SendFunnelStepMessage(string nodeName)
        {
            if (FunnelLog.State != FunnelState.Started)
            {
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("Funnel for sequence '" + Name + "' auto-activated by first node step '" + nodeName + "'");
                }
                SendFunnelStartMessage();
            }

            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("Funnel for sequence '" + Name + "' takes step for node '" + nodeName + "'");
            }
            FunnelLog.LogStep(nodeName);
        }

        private IFunnelLog _funnelLog;
        private IFunnelLog FunnelLog
        {
            get
            {
                if (_funnelLog == null)
                {
                    _funnelLog = WCMApplicationDirector.Instance.Analytics.GetFunnel(Name);
                }

                if (_funnelLog == null)
                {
                    throw new Exception("Failed to create funnel for scripted sequence '" + Name + "'");
                }

                return _funnelLog;
            }
        }

        private void SendFunnelStartMessage()
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("Funnel starts for sequence '" + Name + "'");
            }
            FunnelLog.LogStart(Name);
        }

        private void SendFunnelStopMessage()
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("Funnel stops for sequence '" + Name + "'");
            }
            FunnelLog.LogStop(Name);
        }
        #endregion
    }

    public enum ResetReason
    {
        SequenceComplete,
        BattleComplete,
        SequenceDisabled,
        ApplicationResume,
        LocalPlayerChanged,
        LoadScoutingStateFromCampaignProgress,
        ManualEnable
    }
}

