﻿using System;
using GameTypes;
using GameTypes.GameDefinitions;
using I2.Loc;
using Kixeye.Common;
using Kixeye.WCM.ui;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionShowDivisionRankChangePopup : ScriptedSequenceAction
    {
        public override ISimpleAsyncToken Act()
        {
            Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
            WorldEventSchedule currentSchedule = WCMApplicationDirector.Instance.WorldEventTracker
                .GetCurrentLeaderboardSeason();
            MatchmakingRank rank = currentSchedule != null
                ? localPlayer.Data.PlayerDetails.GetMatchmakingRank((int) currentSchedule.Id)
                : null;
            if (rank == null)
            {
                return new SimpleAsyncToken(new Exception("Player not ranked"));
            }

            SimpleAsyncToken returnToken = new SimpleAsyncToken();
            IAsyncToken<int> leaderboardRankForBadgeToken = localPlayer.GetLeaderboardRankForBadge();
            leaderboardRankForBadgeToken.OnSuccessUnity(value =>
            {
                DivisionRankChangePanelController.DivisionRankChangeContext context =
                    new DivisionRankChangePanelController.DivisionRankChangeContext
                    {
                        Tier = rank.Tier,
                        Division = rank.Division,
                        Rank = value,
                        ExitText = ScriptLocalization.AttackUI.Localizations.ATTACK_SCREEN_EXIT,
                        HideExitButton = false,
                    };

                WCMApplicationDirector.Instance.UI.OpenPanel<DivisionRankChangePanelController>(context);
                returnToken.Succeed();
            });
            leaderboardRankForBadgeToken.OnFailUnity(e => returnToken.Fail(e));
            return returnToken;
        }
    }
}
