using System;
using System.Collections.Generic;
using System.Linq;
using Kixeye.WCM.GameData;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Selects a building. 
    /// </summary>
    [Serializable]
    public class SSActionSelectBuilding : ScriptedSequenceAction
    {
        #region Serialized properties
        /// <summary>
        /// Whether to select a building or deselect all.
        /// </summary>
        [JsonProperty("Select")]
        [ProtoMember(3)]
        public bool Select;
        
        /// <summary>
        /// Which building to select.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(4)]
        public BuildingDesignator Designator
        {
            get { return _building; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _building = new BuildingDesignator();

        #endregion

        #region Public methods

        public override ISimpleAsyncToken Act()
        {
            if (!Select)
            {
                WCMApplicationDirector.Instance.PlayerInput.TrySelectBuilding(null, true);
            }
            else
            {
                Building buildingToSelect = Designator.GetBuilding();
                
                if (buildingToSelect != null)
                {
                    WCMApplicationDirector.Instance.PlayerInput.TrySelectBuilding(buildingToSelect, true);
                }
                else
                {
                    return new SimpleAsyncToken(new Exception("Could not find building to select"));
                }
            }

            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

