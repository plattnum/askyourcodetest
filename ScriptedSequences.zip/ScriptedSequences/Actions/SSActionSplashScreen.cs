using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSplashScreen : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// Whether to show or hide the splash screen.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Show")]
        [ProtoMember(3)]
        public bool Show = true;

        [Newtonsoft.Json.JsonProperty("AutoLoad")]
        [ProtoMember(4)]
        public bool AutoLoad = false;

        [Newtonsoft.Json.JsonProperty("LoadLength")]
        [ProtoMember(5)]
        public float LoadLength = 0;

        #endregion
        
         #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (Show)
            {
                WCMApplicationDirector.Instance.Events.HandleEvent(LoadTimerEvent.GetInstance(WCMApplicationDirector.Instance.GetLoadEventName(), LoadTimerEvent.LoadTimerState.Resume));
                if(SplashScreenManager.Instance != null)
                {
                    SplashScreenManager.Show();
                }
                else
                {
                    WCMApplicationDirector.Instance.UI.SpawnLoadScreen();
                }
                RealtimeLoadingSource.AddTemporaryLoadTime(LoadLength);
            }
            else
            {
                WCMApplicationDirector.Instance.Events.HandleEvent(LoadTimerEvent.GetInstance(WCMApplicationDirector.Instance.GetLoadEventName(), LoadTimerEvent.LoadTimerState.Pause));
                SplashScreenManager.Destroy();
            }

            return new SimpleAsyncToken(true);
        }
        
        #endregion    
    }
}

