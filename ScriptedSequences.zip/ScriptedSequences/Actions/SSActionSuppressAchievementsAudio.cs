﻿using System;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSuppressAchievementsAudio : ScriptedSequenceAction
    {
        /// <summary>
        /// Whether to suppress or un-suppress the achievement related sound notifications.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Suppress")]
        [ProtoMember(3)]
        public bool Suppress;

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            IGameAudio gameAudio = WCMApplicationDirector.Instance.GameAudio;
            if (gameAudio != null)
            {
                FMODGameAudio fmodAudio = gameAudio as FMODGameAudio;
                if (fmodAudio != null)
                {
                    fmodAudio.SuppressAchivementsAudio = Suppress;
                }
            }

            return new SimpleAsyncToken(true);
        }
    }
}
