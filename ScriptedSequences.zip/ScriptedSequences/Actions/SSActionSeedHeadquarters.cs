using Assets.Source.Scripts.Core;
using Assets.Source.Scripts.UI.ZoneSelect;
using Gameplay.ChannelMessages;
using Gameplay.Contracts;
using Kixeye.Common;
using Model;
using Source.Scripts.Core;

namespace Kixeye.WCM.ScriptedSequences
{
    public class SSActionSeedHeadquarters : ScriptedSequenceAction
    {
        public override ISimpleAsyncToken Act()
        {
            WaitForChannelMessageTask<HeadquartersRelocatedMessage> waitingTask = 
                new WaitForChannelMessageTask<HeadquartersRelocatedMessage>(ZoneSelectPanelV2.PollHeadquartersRelocationStatus);

            IAsyncToken<WaitForChannelMessageTask<HeadquartersRelocatedMessage>.Result> resultToken = waitingTask.TriggerAndWait(SendSeedHeadquartersRequest);
            ISimpleAsyncToken simpleToken = resultToken.Simplify();
            // we need to pause this until seeding has completed
            WCMApplicationDirector.Instance.PausePlayerProcessor(
                simpleToken,
                PlayerDataProcessor.PauseReason.SeedHeadquarters,
                openLoadingBlocker: true);

            resultToken.Ready(
                _ =>
                {


                    if (_.Success)
                    {
                        WaitForChannelMessageTask<HeadquartersRelocatedMessage>.Result result = _.Value;
                        if (result.TriggerResult)
                        {
                            HeadquartersRelocatedMessage relocatedMessage = result.ChannelMessage;
                            Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
                            if (localPlayer != null)
                            {
                                localPlayer.ApplyPlayerDataChanges(relocatedMessage.PlayerDataCollection);
                            }
                        }
                    }
                    else
                    {
                        ErrorHandler.ShowPopup(_.Error, "Seeding headquarters encountered exception", logContext: this);
                    }
                });

            return simpleToken;
        }

        // return true if we are waiting for server, otherwise false
        private IAsyncToken<bool> SendSeedHeadquartersRequest()
        {
            var result = new AsyncToken<bool>();
            var requestToken =
                WCMApplicationDirector.Instance.CreateAsyncTokenWithPDIMutex<SeedHeadquartersRequest, SeedHeadquartersResponse>(new SeedHeadquartersRequest());

            requestToken.Ready(
                _ =>
                {
                    if (_.Success)
                    {
                        SeedHeadquartersResponse response = _.Value;
                        bool waitForServer = response.Headquarters == null;
                        result.Succeed(waitForServer);
                    }
                    else
                    {
                        result.Fail(_.Error);
                    }
                });

            return result;
        }

    }
}

