using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Input;
using System;
using ProtoBuf;
using Kixeye.WCM.WorldMap;
using Ninject;
using UnityEngine;
using WorldMap;
using WorldMap.Model;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetInputRestrictions : ScriptedSequenceAction, ISaveAsset
    {
        public enum ToggleActions
        {
            KeepUnchanged,
            On,
            Off,
        }

        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("BuildingSelectionEnabled")]
        [ProtoMember(3)]
        [Obsolete]
        public bool BuildingSelectionEnabled = true;

        [Newtonsoft.Json.JsonProperty("CanScroll")]
        [ProtoMember(4)]
        [Obsolete]
        public bool CanScroll = true;

        [Newtonsoft.Json.JsonProperty("CanZoom")]
        [ProtoMember(5)]
        [Obsolete]
        public bool CanZoom = true;

        [Newtonsoft.Json.JsonProperty("CanCommandSquad")]
        [ProtoMember(6)]
        [Obsolete]
        public bool CanCommandSquad = true;

        [Newtonsoft.Json.JsonProperty("SelectionLocked")]
        [ProtoMember(7)]
        [Obsolete]
        public bool SelectionLocked = false;

        [Newtonsoft.Json.JsonProperty("CanMoveBuildings")]
        [ProtoMember(8)]
        [Obsolete]
        public bool CanMoveBuildings = true;

        [Newtonsoft.Json.JsonProperty("ZoomMin")]
        [ProtoMember(9)]
        public int ZoomMin = 0;

        [Newtonsoft.Json.JsonProperty("ZoomMax")]
        [ProtoMember(10)]
        public int ZoomMax = 0;

        [Newtonsoft.Json.JsonProperty("ZoneAreaDefinitionId")]
        [ProtoMember(11)]
        public string ZoneAreaDefinitionId = string.Empty;

        [Newtonsoft.Json.JsonProperty("PermitHexSelection")]
        [ProtoMember(12)]
        [Obsolete]
        public bool PermitHexSelection = true;

        [Newtonsoft.Json.JsonProperty("AlwaysVisible3DEntities")]
        [ProtoMember(13)]
        public ToggleActions AlwaysVisible3DEntities = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("MigrationVersion")]
        [ProtoMember(14)]
        public int MigrationVersion;

        [Newtonsoft.Json.JsonProperty("BuildingSelectionEnabledNew")]
        [ProtoMember(15)]
        public ToggleActions BuildingSelectionEnabledNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("CanScrollNew")]
        [ProtoMember(16)]
        public ToggleActions CanScrollNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("CanZoomNew")]
        [ProtoMember(17)]
        public ToggleActions CanZoomNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("CanCommandSquadNew")]
        [ProtoMember(18)]
        public ToggleActions CanCommandSquadNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("SelectionLockedNew")]
        [ProtoMember(19)]
        public ToggleActions SelectionLockedNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("CanMoveBuildingsNew")]
        [ProtoMember(20)]
        public ToggleActions CanMoveBuildingsNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("PermitHexSelectionNew")]
        [ProtoMember(21)]
        public ToggleActions PermitHexSelectionNew = ToggleActions.KeepUnchanged;

        [Newtonsoft.Json.JsonProperty("HexSelectionRestriction")]
        [ProtoMember(22)]
        public HexDesignator HexSelectionRestriction;

        #endregion

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            saver.Save(HexSelectionRestriction);
            saver.Save(this);
#endif
        }

        #region Private variables
        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionSetInputRestrictions));

        [Inject]
        private PlayerInput PlayerInput { get; set; }

        [Inject]
        private WCMCameraController CameraController { get; set; }

        [Inject]
        private WorldMapController WorldMapController { get; set; }

        #endregion

        #region Public methods

        public override void Migrate(bool onCreate)
        {
            base.Migrate(onCreate);
            if (onCreate)
            {
                MigrationVersion = 1;
                return;
            }
            if (MigrationVersion < 1)
            {
#pragma warning disable 0618, 0612 // deprecated field
                BuildingSelectionEnabledNew = BuildingSelectionEnabled ? ToggleActions.On : ToggleActions.Off;
                CanScrollNew = CanScroll ? ToggleActions.On : ToggleActions.Off;
                CanZoomNew = CanZoom ? ToggleActions.On : ToggleActions.Off;
                CanCommandSquadNew = CanCommandSquad ? ToggleActions.On : ToggleActions.Off;
                SelectionLockedNew = SelectionLocked ? ToggleActions.On : ToggleActions.Off;
                CanMoveBuildingsNew = CanMoveBuildings ? ToggleActions.On : ToggleActions.Off;
                PermitHexSelectionNew = PermitHexSelection ? ToggleActions.On : ToggleActions.Off;
#pragma warning restore 0618, 0612 // deprecated field
                MigrationVersion = 1;
            }
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (PlayerInput == null)
            {
                _logger.Error("Could not get PlayerInput.");
            }
            else
            {
                if (BuildingSelectionEnabledNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.BuildingSelectionEnabled = BuildingSelectionEnabledNew == ToggleActions.On;
                }
                if (CanScrollNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.CanScroll = CanScrollNew == ToggleActions.On;
                }
                if (CanZoomNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.CanZoom = CanZoomNew == ToggleActions.On;
                }
                if (CanCommandSquadNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.CanCommandSquad = CanCommandSquadNew == ToggleActions.On;
                }
                if (SelectionLockedNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.SelectionLocked = SelectionLockedNew == ToggleActions.On;
                }
                if (CanMoveBuildingsNew != ToggleActions.KeepUnchanged)
                {
                    PlayerInput.CanMoveBuildings = CanMoveBuildingsNew == ToggleActions.On;
                }
            }

            if (CameraController == null)
            {
                _logger.Error("Could not get WCMCameraController.");
            }
            else
            {
                if (ZoomMin != 0)
                {
                    CameraController.Data.ForceMinDistance = ZoomMin;
                }
                if (ZoomMax != 0)
                {
                    CameraController.Data.ForceMaxDistance = ZoomMax;
                }

                if (WorldMapController == null)
                {
                    if (!string.IsNullOrEmpty(ZoneAreaDefinitionId) || !(PermitHexSelectionNew == ToggleActions.On))
                    {
                        _logger.Error("Could not get WorldMapController.");
                    }
                }
                else
                {
                    if (AlwaysVisible3DEntities != ToggleActions.KeepUnchanged)
                    {
                        if (WorldMapController.HexController != null &&
                            WorldMapController.HexController.EntityController != null)
                        {
                            if (AlwaysVisible3DEntities == ToggleActions.On)
                            {
                                // Set always visible
                                WorldMapController.HexController.EntityController.ForceMeshVisibleAtZoom = -1f;
                            }
                            else
                            {
                                // Reset always visible
                                WorldMapController.HexController.EntityController.ForceMeshVisibleAtZoom = null;
                            }
                        }
                        else
                        {
                            _logger.Error("Could not set visibility of 3D objects on WM.");
                        }
                    }

                    if (PermitHexSelectionNew != ToggleActions.KeepUnchanged)
                    {
                        WorldMapController.PermitHexSelection(PermitHexSelectionNew == ToggleActions.On, HexSelectionRestriction);
                    }

                    if (!string.IsNullOrEmpty(ZoneAreaDefinitionId))
                    {
                        var restrictToZoneArea = WorldMapController.FindZoneAreaByDefinitionId(ZoneAreaDefinitionId);
                        if (restrictToZoneArea == null)
                        {
                            _logger.Error("Could not find zone area: " + ZoneAreaDefinitionId);
                        }
                        else
                        {
                            WorldMapController.SetupCameraConstrainedTo(true, restrictToZoneArea);
                        }
                    }
                    else
                    {
                        WorldMapController.ReturnCameraToDefaultConstraints();
                    }
                }
            }
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

