using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using Ninject;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that waits for a given ammount of time before being complete.
    /// </summary>
    [Serializable]
    public class SSActionDelay : ScriptedSequenceAction
    {
        #region Private Fields

        [Inject]
        private ScriptedSequencesController ScriptedSequences { get; set; }

        #endregion

        #region Public Fields

        /// <summary>
        /// The ammount of seconds to delay.
        /// </summary>
        [JsonProperty("Duration")]
        [ProtoMember(3)]
        public float Duration;

        [JsonProperty("Skipable")]
        [ProtoMember(4)]
        public bool Skipable;

        #endregion

        [Inject]
        private ScaledTimeScheduler Scheduler { get; set; }

        #region Public Methods

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            var token = Scheduler.Delay(Duration);

             //Check if we need to spawn the touch catcher
            if (Skipable)
            {
                if (ScriptedSequences != null)
                {
                    UnityEngine.Events.UnityAction handler = null;
                    handler = () =>  
                    {
                        ScriptedSequences.TouchHandlerRemove(handler);
                        token.Succeed();
                    };
                    ScriptedSequences.TouchHandlerAdd(handler);

                    token.ReadyUnity(_ =>
                    {
                        ScriptedSequences.TouchHandlerRemove(handler);
                    });
                }
            }
            return token;
        }
        #endregion
    }
}

