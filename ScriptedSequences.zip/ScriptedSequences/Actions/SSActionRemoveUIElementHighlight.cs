﻿using System;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using GameTypes.GameDefinitions;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ProtoBuf;
using UnityEngine;
using UnityEngine.AddressableAssets;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionRemoveUIElementHighlight : ScriptedSequenceAction
    {
        /// <summary>
        /// UI elements which will have the highlight
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UIElement")]
        [ProtoMember(3)]
        public UIElementDesignator UIElement = new UIElementDesignator();

        /// <summary>
        /// The name of the prefab to instantiate for this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("HighlightPrefabReference")]
        [ProtoMember(4)]
        public AssetRef HighlightPrefabReference = new AssetRef();
        
        [Newtonsoft.Json.JsonProperty("HighlightPrefabAssetReference")]
        [ProtoMember(5)]
        public PrefabTierAssetReference HighlightPrefabAssetReference = new PrefabTierAssetReference();

        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionRemoveUIElementHighlight));

        public override ISimpleAsyncToken Act()
        {
            GameObject uiElementGO = UIElement.GetUIElement();
            if (uiElementGO == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find UI Element designated by [" + UIElement.GetDescription() + "]"));
            }

            if (uiElementGO.activeInHierarchy == false && _logger.IsEnabled(LogMessageLevel.Warn))
            {
                _logger.Warn(GetDebugNameFull() + " showing an indicator on " +
                             UIElement.GetDescription() + " (" + uiElementGO + ") " +
                             " which is not currently active.");
            }

            SimpleAsyncToken returnToken = new SimpleAsyncToken();
            
            IAsyncToken<GameObject> asyncToken = null;
#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
            if (TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
            {
                asyncToken = HighlightPrefabAssetReference.Load();
            }
            else
#endif
            {
                asyncToken = WCMApplicationDirector.Instance.DataManager.Get<GameObject>(HighlightPrefabReference);
            }
            
            asyncToken.ReadyUnity(response =>
            {
                if (response.Success && response.Value != null)
                {
                    GameObject highlightGameObject;
                    if (WCMApplicationDirector.Instance.ScriptedSequences.HighlightElementGameObjects.TryGetValue(UIElement.Tag, out highlightGameObject))
                    {
                        WCMObjectPoolPreloader.DespawnObject(highlightGameObject, response.Value.name);
                        WCMApplicationDirector.Instance.ScriptedSequences.HighlightElementGameObjects.Remove(UIElement.Tag);
                    }

                    returnToken.Succeed();
                }
                else
                {
                    returnToken.Fail(response.Error);
                }
            });
            
            return returnToken;
        }

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            for (int i = 0; i < HighlightPrefabAssetReference.GUIDs.Length; i++)
            {
                string guid = HighlightPrefabAssetReference.GUIDs[i];
                if (!string.IsNullOrEmpty(guid))
                {
                    HighlightPrefabAssetReference.AssetReferencesByTier[i] = new AssetReference(guid);
                }
            }

            base.WriteTo(saver);
#endif
        }

    }
}
