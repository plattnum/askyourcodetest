﻿using System;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDisableDefaultWinCondition : ScriptedSequenceAction
    {
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met. Disables default win condition ("all enemy buildings destroyed").
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            WCMApplicationDirector.Instance.Battle.shouldFinishBattleWhenLastBuildingDestroyed = false;
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

