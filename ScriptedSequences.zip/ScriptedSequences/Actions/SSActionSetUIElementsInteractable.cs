﻿using System;
using System.Collections.Generic;
using Kixeye.Common;
using ProtoBuf;
using UnityEngine;
using UnityEngine.UI;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetUIElementsInteractable : ScriptedSequenceAction
    {
        #region Serialized properties
        /// <summary>
        /// Set the UI elements interactable or not.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Interactable")]
        [ProtoMember(3)]
        public bool Interactable = false;

        /// <summary>
        /// UI elements which will have the interactable flag set.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UIElements")]
        [ProtoMember(4)]
        public List<UIElementDesignator> UIElementDesignators = new List<UIElementDesignator>();
        #endregion

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionSetUIElementsInteractable));

        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            // UI elements excepted from the disable interaction rule
            if (UIElementDesignators != null)
            {
                foreach (var uiElementDesignator in UIElementDesignators)
                {
                    GameObject uiElement = uiElementDesignator.GetUIElement();
                    if (uiElement == null)
                    {
                        return new SimpleAsyncToken(new Exception("Could not find UI Element designated by [" + uiElementDesignator.GetDescription() + "]"));
                    }

                    if (!uiElement.activeInHierarchy && _logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(GetDebugNameFull() + " setting the interactable flag to " + Interactable.ToString() + " for " + uiElement.name + " which is not currently active.");
                    }

                    var selectableComponents = uiElement.GetComponents<Selectable>();
                    int count = selectableComponents.Length;
                    if (count == 0)
                    {
                        return new SimpleAsyncToken(new Exception("The element designated by [" + uiElementDesignator.GetDescription() + "] has no interactable property."));
                    }
                    for (int i = 0; i < count; i++)
                    {
                        selectableComponents[i].interactable = Interactable;
                    }

                    var canvasGroup = uiElement.GetComponent<CanvasGroup>();
                    if (canvasGroup != null)
                    {
                        canvasGroup.interactable = Interactable;
                    }
                }
            }

            return new SimpleAsyncToken(true);
        }
        #endregion
    }
}
