using System;
using GameTypes;
using Kixeye.Common;
using Kixeye.WCM.GameData;
using ProtoBuf;
using Ninject;
using System.Collections.Generic;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionCreateUnitAtlas : ScriptedSequenceAction
    {
        #region Serialized properties

        // skip 3

        /// <summary>
        /// The tech levels at which the unit portrait will be created.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TechLevels")]
        [ProtoMember(4)]
        public List<int> TechLevels = new List<int>();

        /// <summary>
        /// The id of unit whose portrait we need to add to our atlas.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IdsOfUnits")]
        [ProtoMember(5)]
        public List<int> IdsOfUnits = new List<int>();

        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's game data manager.
        /// </summary>
        [Inject]
        private WCMGameDataManager _dataManager { get; set; }


        [Inject]
        private ActorPortraitManager _portraitManager { get; set; }
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (IdsOfUnits.Count != TechLevels.Count)
            {
                throw new ApplicationException("types of units and levels must match");
            }

            return CreateAtlas();
        }
        
        #endregion    
        
        #region private methods
        
        /// <summary>
        /// Create an atlas for the units that have been added to the list
        /// </summary>
        /// <returns></returns>
        private ISimpleAsyncToken CreateAtlas()
        {
            // TODO: Remove this 
            return new SimpleAsyncToken(true);
        }
        
        #endregion
    }
}

