﻿using System;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using GameTypes.GameDefinitions;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ProtoBuf;
using UnityEngine;
using UnityEngine.AddressableAssets;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionAddUIElementHighlight : ScriptedSequenceAction
    {
        /// <summary>
        /// UI elements which will have the highlight
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UIElement")]
        [ProtoMember(3)]
        public UIElementDesignator UIElement = new UIElementDesignator();

        /// <summary>
        /// The name of the prefab to instantiate for highlighting.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("HighlightPrefabReference")]
        [ProtoMember(4)]
        public AssetRef HighlightPrefabReference = new AssetRef();

        /// <summary>
        /// Screen offset on X
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ScreenOffsetX")]
        [ProtoMember(5)]
        public float ScreenOffsetX;

        /// <summary>
        /// Screen offset on Y
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ScreenOffsetY")]
        [ProtoMember(6)]
        public float ScreenOffsetY;

        /// <summary>
        /// Screen offset on Z
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ScreenOffsetZ")]
        [ProtoMember(7)]
        public float ScreenOffsetZ;
        
        [Newtonsoft.Json.JsonProperty("HighlightPrefabAssetReference")]
        [ProtoMember(8)]
        public PrefabTierAssetReference HighlightPrefabAssetReference = new PrefabTierAssetReference();

        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionAddUIElementHighlight));

        public override ISimpleAsyncToken Act()
        {
            GameObject uiElementGO = UIElement.GetUIElement();
            if (uiElementGO == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find UI Element designated by [" + UIElement.GetDescription() + "]"));
            }

            if (uiElementGO.activeInHierarchy == false && _logger.IsEnabled(LogMessageLevel.Warn))
            {
                _logger.Warn(GetDebugNameFull() + " showing highlight on " +
                             UIElement.GetDescription() + " (" + uiElementGO + ") " +
                             " which is not currently active.");
            }

            SimpleAsyncToken returnToken = new SimpleAsyncToken();

            if (WCMApplicationDirector.Instance.ScriptedSequences.HighlightElementGameObjects
                .ContainsKey(UIElement.Tag))
            {
                returnToken.Fail(new Exception(
                    string.Format("Highlight for UIElement {0} already added", UIElement.Tag)));
            }
            else
            {
                IAsyncToken<GameObject> asyncToken = null;
#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
                if (TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
                {
                    asyncToken = HighlightPrefabAssetReference.Load();
                }
                else
#endif
                {
                    asyncToken = WCMApplicationDirector.Instance.DataManager.Get<GameObject>(HighlightPrefabReference);
                }
                
                asyncToken.ReadyUnity(response=>
                {
                    if (response.Success && response.Value != null)
                    {
                        GameObject highlightPrefabInstance = WCMObjectPoolPreloader.SpawnObject(response.Value).SpawnVal
                            .gameObject;
                        highlightPrefabInstance.SetActive(true);

                        WCMApplicationDirector.Instance.ScriptedSequences.HighlightElementGameObjects.Add(
                            UIElement.Tag,
                            highlightPrefabInstance);
                        RectTransform rectTransform = uiElementGO.GetComponent<RectTransform>();
                        ScriptedSequenceIndicator scriptedSequenceIndicator =
                            highlightPrefabInstance.GetComponent<ScriptedSequenceIndicator>();
                        scriptedSequenceIndicator.SetIndicateTarget(rectTransform,
                            ScriptedSequenceIndicator.UIElementOffsetType.Middle,
                            0, new Vector3(ScreenOffsetX/100, ScreenOffsetY/100, ScreenOffsetZ/100), uiElementGO.name);

                        returnToken.Succeed();
                    }
                    else
                    {
                        returnToken.Fail(response.Error);
                    }
                });
            }
            return returnToken;
        }
        
        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            for (int i = 0; i < HighlightPrefabAssetReference.GUIDs.Length; i++)
            {
                string guid = HighlightPrefabAssetReference.GUIDs[i];
                if (!string.IsNullOrEmpty(guid))
                {
                    HighlightPrefabAssetReference.AssetReferencesByTier[i] = new AssetReference(guid);
                }
            }
            
            base.WriteTo(saver);
#endif
        }
    }
}
