﻿using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDeploymentGrid : ScriptedSequenceAction
    {
        public enum EnableType
        {
            Enable,
            Disable
        }
        
        #region Serialized properties
        
        /// <summary>
        /// Whether to hide or show the grid.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfEnable")]
        [ProtoMember(3)]
        public EnableType TypeOfFade;
        
        #endregion
        
         #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            var response = new SimpleAsyncToken();
            ApplicationDirector.Instance.Bootstrapper.BootstrapCoroutine(Run(response));
            return response;
        }

        private System.Collections.IEnumerator Run( SimpleAsyncToken response )
        {

            BattleHUD battleHUD = null;
            ScoutingHUD scoutHud = null;

            while ((battleHUD = WCMApplicationDirector.Instance.UI.CurrentHUD as BattleHUD) == null &&
                   (scoutHud = WCMApplicationDirector.Instance.UI.CurrentHUD as ScoutingHUD) == null)
            {
                yield return null;
            }

            if (battleHUD != null)
            {
                while (battleHUD.FinishedEnterBattleMode == false)
                {
                    yield return null;
                }

                battleHUD.SetDeploymentGridEnabled(TypeOfFade == EnableType.Enable);
                response.Succeed();
            }
            else if (scoutHud != null)
            {
                //Check if we are scouting
                scoutHud.SetupDeploymentRenderers();
                response.Succeed();
            }
            yield return null;
        }
        
        #endregion    
    }
}

