using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;
using System.ComponentModel;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Activates another node in this sequence
    /// </summary>
    [Serializable]
    public class SSActionActivateNode : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The node to activate.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("NodeID")]
        [ProtoMember(3), DefaultValue(-1)]
        public int NodeID = -1;

        [Newtonsoft.Json.JsonProperty("ResetEntireSequence")]
        [ProtoMember(4)]
        public bool ResetSequence = false;

        [Newtonsoft.Json.JsonProperty("OnlyEnableDoNotActivate")]
        [ProtoMember(5)]
        public bool OnlyEnableDoNotActivate = false;
        #endregion


        /// <summary>
        /// The game's player manager
        /// </summary>
        [Inject]
        public PlayerManager Players { private get; set; }

        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            ScriptedSequenceNode parentNode = Parent as ScriptedSequenceNode;
            if (parentNode == null)
            {
                throw new ApplicationException("Node with ID " + NodeID + " has null parent!");
            }

            ScriptedSequenceNode node = parentNode.Parent.GetNodeByID(NodeID);
            if (node == null)
            {
                throw new ApplicationException("Can't find node with ID " + NodeID);
            }

            if (ResetSequence)
            {
                Parent.ScriptedSequence.Reset(Players.LocalPlayer.Data.PlayerDetails, ResetReason.ManualEnable);
            }

            if (OnlyEnableDoNotActivate)
            {
                node.Reset();
                node.Enable(Players.LocalPlayer.Data.PlayerDetails);
            }
            else
            {
                node.Activate();
            }

            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

