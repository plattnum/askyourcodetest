using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Ninject;
using UnityEngine.UI;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionUIInputDisable : ScriptedSequenceAction
    {
        public enum DisableType
        {
            DisableAll,
            DisableExcept,
            DisableScrollRectInChildren,
            DisableDraggableInChildren,
        }
        
        #region Serialized properties
        
        /// <summary>
        /// Whether to disable all UI input or all except one element
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfUIDisable")]
        [ProtoMember(3)]
        public DisableType TypeOfUIDisable = DisableType.DisableAll;
        
        /// <summary>
        /// [DEPRECATED] The sole exception to the disabled UI elements.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UIElementToLeaveEnabled")]
        [ProtoMember(4)]
        public string UIElementToLeaveEnabled = "";

        /// <summary>
        /// The sole exception to the disabled UI elements.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ElementToLeaveEnabled")]
        [ProtoMember(5)]
        public UIElementDesignator ElementToLeaveEnabled = new UIElementDesignator();
        
        #endregion

        #region private variables

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionUIInputDisable));

        #endregion
        
        #region Public methods

        public override string GetDebugName()
        {
            var result = "UI Input " + TypeOfUIDisable.ToString().Replace("Disable", "Disable ");
            if (TypeOfUIDisable == DisableType.DisableAll) return result;
            result += " " + ElementToLeaveEnabled.GetDescription(brief: true);
            return result;
        }

        /// <summary>
        /// Sets up the condition.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            // version the old style that just had a button name
            if (!String.IsNullOrEmpty(UIElementToLeaveEnabled))
            {
                ElementToLeaveEnabled.TypeOfDesignation = UIElementDesignator.DesignationType.ByName;
                ElementToLeaveEnabled.ElementName = UIElementToLeaveEnabled.Replace('.', '/');
                // replace analytics-style dot separator with Unity slash separator
                UIElementToLeaveEnabled = null;
            }
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (TypeOfUIDisable == DisableType.DisableAll)
            {
                _ssController.DisableUI();
            }
            else
            {
                //GameObject UIElement = GameObject.Find( UIElementToLeaveEnabled );
                GameObject UIElement = ElementToLeaveEnabled.GetUIElement();
                if (UIElement == null)
                {
                    _ssController.ReEnableUI();
                    return new SimpleAsyncToken(new Exception("Could not find UI Element designated by [" + ElementToLeaveEnabled.GetDescription() + "]"));
                }

                if (!UIElement.activeInHierarchy && _logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn(GetDebugNameFull() + " disabling all UI except for " + UIElement.name + " which is not currently active.");
                }

                if (TypeOfUIDisable == DisableType.DisableExcept)
                {
                    _ssController.DisableUI(UIElement);
                    return new SimpleAsyncToken(true);
                }

                Behaviour component = null;
                if (TypeOfUIDisable == DisableType.DisableDraggableInChildren)
                {
                    component = UIElement.GetComponent<DraggableGameItem>();
                }
                else if (TypeOfUIDisable == DisableType.DisableScrollRectInChildren)
                {
                    component = UIElement.GetComponent<ScrollRect>();
                }

                if (component != null)
                {
                    component.enabled = false;
                }
            }
            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

