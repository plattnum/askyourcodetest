﻿using System;
using ProtoBuf;
using Kixeye.Common;
using Kixeye.WCM.WorldMap;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionResetWorldMapSelection : ScriptedSequenceAction
    {

        #region private variables

         [Inject]
         public WorldMapController Controller { get; private set; }
        
        #endregion        

        /// <summary>
        /// Called when a sequence node's conditions are met.  
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Controller.ClearSelectedLocation();

            _asyncToken =  new SimpleAsyncToken(true);

            return _asyncToken;
        }

    }
}

