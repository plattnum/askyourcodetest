using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSquadChangeOwner : ScriptedSequenceAction
    {
        #region Serialized properties

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToChange")]
        [ProtoMember(3)]
        public SquadDesignator SquadToChange = new SquadDesignator();

        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            throw new NotImplementedException("This Action is not used.  If it is needed it will need to be redesigned. - Brennan");
            //base.Act();
            
            //Player thePlayer;
            //Platoon platoon;
            //Squad squad = SquadToChange.GetSquad(out thePlayer, out platoon);

            //if (squad == null)
            //{
            //    return new SimpleAsyncToken( new ApplicationException( "Cannot get squad to change owner" ) );
            //}
            //else
            //{
            //    Player newPlayer = SquadToChange.GetOpposingPlayer();
            //    squad.ChangeOwner(newPlayer, null);
            //}
            
            //return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

