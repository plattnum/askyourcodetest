using System;
using System.Collections.Generic;
using GameTypes;
using GameTypes.GameDefinitions;
using Kixeye.WCM.Commands;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using Model;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSpawnSquad : ScriptedSequenceAction
    {
        #region Serialized properties

        // skip 3

        /// <summary>
        /// The tech level at which the unit will be created.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TechLevel")]
        [ProtoMember(4)]
        public int TechLevel = 1;

        /// <summary>
        /// The number of units to be spawned with this action.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Number")]
        [ProtoMember(5)]
        public int Number = 1;

        /// <summary>
        /// If > 0, spawns SpawnsPerInterval units every interval time
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SpawnIntervalTime")]
        [ProtoMember(6)]
        public float SpawnIntervalTime = 0f;

        /// <summary>
        /// If spawning at intervals, this is the number to spawn every interval, until Number is reached.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SpawnsPerInterval")]
        [ProtoMember(7)]
        public int SpawnsPerInterval = 1;

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToSpawn")]
        [ProtoMember(8)]
        public SquadDesignator SquadToSpawn = new SquadDesignator();

        /// <summary>
        /// The serialized backing data for spawn position. only to be modified by the serializer!
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SpawnPosition")]
        [ProtoMember(9)]
        public PositionData SpawnPosition = new PositionData();

        /// <summary>
        /// The behavior of the squad.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SquadBehavior")]
        [ProtoMember(10)]
        public UnitBehaviorType SquadBehavior = UnitBehaviorType.Aggressive;

        /// <summary>
        /// Whether the squad can be selected after it is spawned.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Selectable")]
        [ProtoMember(101)]
        public bool Selectable = true;

        /// <summary>
        /// Whether to show the selection graphic for the squad.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ShowSelection")]
        [ProtoMember(102)]
        public bool ShowSelection = true;

        [Newtonsoft.Json.JsonProperty("DontSpawn")]
        [ProtoMember(103)]
        public bool DontSpawn = false;

        /// <summary>
        /// The id of unit to spawn.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IdOfUnit")]
        [ProtoMember(104)]
        public int IdOfUnit = UnitTypeConstant.Rifleman;

        #endregion

        #region Private variables

        /// <summary>
        /// When spawning over a time span, tracks how many more units are to be spawned
        /// </summary> 
        private int _spawnsRemaining = 0;

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        public EventManager Events { get; set; }

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            return "Spawn Squad: {0}x{1} in {2}".FormatWith(
                IdOfUnit,
                Number,
                SquadToSpawn);
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (IdOfUnit == UnitTypeConstant.Invalid)
            {
                throw new ApplicationException("Invalid UnitType");
            }

            _spawnsRemaining = Number;

            Events.AddEventHandler<SquadRecalledEvent>(OnSquadRecalled);
            ISimpleAsyncToken token = SpawnUnits();
            token.ReadyUnity(_ => {
                Events.RemoveEventHandler<SquadRecalledEvent>(OnSquadRecalled);
            });
            return token;
        }

        #endregion

        #region private methods

        /// <summary>
        /// Spawns the units specified in the serialized members.
        /// </summary>
        /// <returns>A token that will finish when all units are fully loaded and spawned.</returns>
        private ISimpleAsyncToken SpawnUnits()
        {
            // retrive the static definition of this type
            IGameDefinitionProvider definitionProvider = WCMApplicationDirector.Instance.GameData;
            UnitDefinition definition = definitionProvider.GetUnitDefinition(IdOfUnit, TechLevel);
            SquadToSpawn.StorageUnitType = IdOfUnit;

            if (definition == null)
            {
                throw new ApplicationException(string.Format("Definition could not be found for {0} tech level {1}", IdOfUnit, TechLevel));
            }

            Player thePlayer;
            Platoon platoon;
            Squad squad = SquadToSpawn.GetSquad(out thePlayer, out platoon);

            if (thePlayer == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find owning player for squad."));
            }

            if (squad == null)
            {
                // If this isn't the local player, this won't be saved so just create the requested platoon and squad.
                // I don't love doing this.  The alternative is to version all the saved RF bases to make sure they
                // have enough platoons and squads.
                if (platoon == null)
                {
                    PlatoonType type = definition.ArmorType == ArmorType.Air ? PlatoonType.Air : PlatoonType.Ground;
                    PlatoonData data = thePlayer.Data.CreateNewPlatoonData( definitionProvider, type );
                    if (data == null)
                    {
                        return new SimpleAsyncToken(new Exception("Failed to create new Platoon Data"));
                    }

                    if (type == PlatoonType.Ground && SquadToSpawn.PlatoonNumber > thePlayer.Army.GroundPlatoons.Count)
                    {
                        // fill in any empty platoons between the start and the one we want
                        var platoonsToAdd = SquadToSpawn.PlatoonNumber - thePlayer.Army.GroundPlatoons.Count;
                        for (int i = 0; i < platoonsToAdd; ++i)
                        {
                            thePlayer.Army.AddPlatoon(data);
                        }
                    }
                    platoon = thePlayer.Army.AddPlatoon(data);

                    if (platoon == null)
                    {
                        return new SimpleAsyncToken(new Exception("Failed to create a new platoon!"));
                    }
                }

                for (int i = platoon.Squads.Count; i <= SquadToSpawn.SquadIndex; ++i)
                {
                    SquadData squadData = new SquadData { UnitList = new List<UnitData>() };
                    Squad newSquad = new Squad(platoon, 
                                                i, 
                                                WCMApplicationDirector.Instance.GameData, 
                                                WCMApplicationDirector.Instance.SquadSelectionSpawner, 
                                                WCMApplicationDirector.Instance.UnitHealthbarSpawner, 
                                                squadData);
                    if (SquadToSpawn.PlayerOwningSquad == SquadDesignator.PlayerOwner.Local)
                    {
                        newSquad.IsSaveDisabled = true;
                    }
                    platoon.Squads.Add(newSquad);
                }
                squad = platoon.Squads[SquadToSpawn.SquadIndex];
            }

            if (squad == null || platoon == null)
            {
                string msg = string.Format("Cannot find squad {0} {1} Squad:{2} for {3} to spawn {4}",
                    SquadToSpawn.TypeOfPlatoon, SquadToSpawn.PlatoonNumber, SquadToSpawn.SquadIndex, SquadToSpawn.PlayerOwningSquad, definition.Type);
                Log.Error(this, msg);
                return new SimpleAsyncToken(new Exception(msg));
            }

            squad.BehaviorType = SquadBehavior;

            int spawnCount = Number;
            if (SpawnIntervalTime > 0f)
            {
                spawnCount = Math.Min(SpawnsPerInterval, _spawnsRemaining);
                _spawnsRemaining -= spawnCount;
            }
            if (spawnCount <= 0)
            {
                return new SimpleAsyncToken(true);
            }

            squad.IsSaveDisabled = true;

            for (int count = 0; count < spawnCount; ++count)
            {
                thePlayer.CreateNewUnit(IdOfUnit, squad, SpawnPosition, false, TechLevel);
            }

            ISimpleAsyncToken spawnToken = new SimpleAsyncToken(true);

            if (platoon.IsAirforcePlatoon && !definition.AirPlatoonUnit)
            {
                string msg = string.Format("Attempting to assign NON-air unit to AIR platoon  Platoon:{0} Squad:{1} for {2} to spawn {3}",
                    platoon.PlatoonIndex, SquadToSpawn.SquadIndex, SquadToSpawn.PlayerOwningSquad, definition.Type);
                Log.Error(this, msg);
                return new SimpleAsyncToken(new Exception(msg));
            }
            else if (!platoon.IsAirforcePlatoon && !platoon.IsArtilleryPlatoon && !squad.IsDeployed && 
                     !(DontSpawn && SquadToSpawn.PlayerOwningSquad == SquadDesignator.PlayerOwner.Local))
            {
                var token = new SimpleAsyncToken();

                var deployToken = squad.Deploy(SpawnPosition, ShowSelection);

                deployToken.AddDependent(token).ReadyUnity(deployResult =>
                {
                    // set the command after deploy
                    if (squad.Brain != null)
                    {
                        switch (squad.BehaviorType)
                        {
                            case UnitBehaviorType.Aggressive:
                                squad.Brain.Attack(squad.Brain.FindTarget(float.MaxValue));
                                break;
                            case UnitBehaviorType.HoldPosition:
                                squad.Brain.Defend();
                                break;
                            case UnitBehaviorType.Unleashed:
                                squad.Brain.Attack(squad.Brain.FindTarget(float.MaxValue));
                                break;
                            default:
                                squad.Brain.Leash();
                                break;
                        }
                    }
                    token.Set(deployResult);
                });

                spawnToken = token;
            }
            else if (squad.IsDeployed && squad.Brain.Command != null)
            {
                // reset the current command so that the new unit follows it
                squad.Brain.Command.Enter(squad.Brain.Command);
            }

            if (thePlayer.IsLocal)
            {
                squad.Selectable = Selectable;

                if (Selectable)
                {
                    // if the attack hud is displayed, update it with the new squad
                    BattleHUD battleHUD = WCMApplicationDirector.Instance.UI.CurrentHUD as BattleHUD;
                    if (battleHUD != null)
                    {
                        battleHUD.RefreshSquadWidgets();

                        if (platoon.IsAirforcePlatoon)
                        {
                            battleHUD.RefreshAirforceWidgets(platoon);
                        }

                        if (platoon.IsArtilleryPlatoon)
                        {
                            battleHUD.RefreshArtilleryWidgets(platoon);
                        }
                    }
                }
            }
            else
            {
                // set the defending squad to defend
                if (squad.Brain != null)
                {
                    squad.Brain.Leash();
                }
            }

            if (SpawnIntervalTime > 0f && _spawnsRemaining > 0)
            {
                // schedule the next spawn                    
                // Ignore the AsyncToken that it returns.  This scripted sequence action
                // is "complete" after the first squad is spawned.
                WCMApplicationDirector.Instance.Scheduler.PushCallback(SpawnIntervalTime, () => SpawnUnits());
            }

            return spawnToken;
        }

        /// <summary>
        /// Event handler for when the squad is recalled.
        /// </summary>
        private void OnSquadRecalled(SquadRecalledEvent recallEvent)
        {
            if (recallEvent.Squad == SquadToSpawn.GetSquad())
            {
                // Don't spawn any more units for a recalled squad.  This action will 
                // have to be repeated if we want to spawn more.
                Events.RemoveEventHandler<SquadRecalledEvent>(OnSquadRecalled);
                _spawnsRemaining = 0;
            }
        }

        #endregion
    }
}