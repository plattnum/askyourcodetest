using System;
using Kixeye.Common;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Ninject;
using WorldMap;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Starts/stops Actor glow
    /// </summary>
    [Serializable]
    public class SSActionWorldMapActorGlow : ScriptedSequenceAction, ISerializationCallbackReceiver
    {
        public enum GlowAction {StartGlow, StopGlow};
        public enum SelectionType { ActorSpawner, ZoneArea, SingleZoneArea };

        #region Serialized properties

        /// <summary>
        /// Every World Map Actor has a named spawner; that's how we identify Actors.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ActorSpawnerName")]
        [ProtoMember(3)]
        public string TargetName;

        /// <summary>
        /// What do we actually do - start glow or stop glow?
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Action")]
        [ProtoMember(4)]
        public GlowAction Action;

        [Newtonsoft.Json.JsonProperty("OffsetDirection")]
        [ProtoMember(5)]
        public HexDirection OffsetDirection;

        [Newtonsoft.Json.JsonProperty("OffsetDistance")]
        [ProtoMember(6)]
        public int OffsetDistance;

        [Newtonsoft.Json.JsonProperty("TypeSelection")]
        [ProtoMember(7)]
        public SelectionType TargetType;

        [Newtonsoft.Json.JsonProperty("Zoom")]
        [ProtoMember(8)]
        public float? Zoom;

        [Newtonsoft.Json.JsonProperty("RestrictSelection")]
        [ProtoMember(9)]
        public bool RestrictSelection;

        #endregion


        #region Unity Serialization Support

        [SerializeField]
        protected NullableSerializedFloat _zoom;

        public void OnBeforeSerialize()
        {
            _zoom = new NullableSerializedFloat
            {
                Value = Zoom,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_zoom != null)
            {
                Zoom = _zoom.Value;
            }
            _zoom = null;
        }

        #endregion

        [Inject]
        private WorldMapController WorldMapController { get; set; }

        #region Public methods

        public override string GetDebugName()
        {
            string prefix = Action == GlowAction.StartGlow
                ? "Show Glow Effect on "
                : "Remove Glow Effect from ";

            string name = string.IsNullOrEmpty(TargetName) ? "<NONE SELECTED>" : TargetName;

            string suffix = OffsetDistance == 0 ? "" : (" " + OffsetDirection + (OffsetDistance == 1 ? "" : "x" + OffsetDistance));

            return prefix + name + suffix;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            switch (Action)
            {
                case GlowAction.StartGlow:
                    StartGlow();
                    break;

                case GlowAction.StopGlow:
                    StopGlow();
                    break;
            }

            return new SimpleAsyncToken(true);
        }

        private void StartGlow()
        {
            switch (TargetType)
            {
                case SelectionType.ActorSpawner:
                    WorldMapController.StartActorGlow(TargetName, OffsetDirection, OffsetDistance, RestrictSelection);
                    break;

                case SelectionType.SingleZoneArea:
                    WorldMapController.StopAllZoneGlow();
                    goto case SelectionType.ZoneArea;

                case SelectionType.ZoneArea:
                    WorldMapController.StartZoneGlow(TargetName, Zoom, RestrictSelection);
                    break;
            }
        }

        private void StopGlow()
        {
            
            switch (TargetType)
            {
                case SelectionType.ActorSpawner:
                    WorldMapController.StopActorGlow(TargetName);
                    break;

                case SelectionType.SingleZoneArea:
                case SelectionType.ZoneArea:
                    WorldMapController.StopZoneGlow(TargetName);
                    break;
            }
        }

        #endregion
    }
}