using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetSquadCombatFlags : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The squad to modify the combat flags for.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToModify")]
        [ProtoMember(3)]
        public SquadDesignator SquadToModify = new SquadDesignator();
        
        /// <summary>
        /// If true, the game item cannot be selected and targeted by AI or players.  Does not affect how the item takes damage.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnTargetable")]
        [ProtoMember(4)]
        public bool UnTargetable = false;
        
        /// <summary>
        /// If true, won't take any damage.  Does not affect the ability to target it.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnDamageable")]
        [ProtoMember(5)]
        public bool UnDamageable = false;
        
        /// <summary>
        /// If true, the game item won't be killed or stop functioning if its health reaches zero.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnKillable")]
        [ProtoMember(6)]
        public bool UnKillable = false;
        
        #endregion
        
        #region Public methods

        public override string GetDebugName()
        {
            return "Set Combat Flags: {0}: {1}, {2}, {3}".FormatWith(
                SquadToModify,
                UnTargetable ? "Untargetable" : "Targetable",
                UnDamageable ? "Undamageable" : "Damageable",
                UnKillable ? "Unkillable" : "Killable");
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Player thePlayer;
            Platoon platoon;
            Squad squad = SquadToModify.GetSquad(out thePlayer, out platoon);

            if (squad == null)
            {
                Log.Error(this, "Cannot find squad to modify combat flags.");
            }
            else
            {
                foreach (Unit unit in squad.Units)
                {
                    unit.IsUndamageable = UnDamageable;
                    unit.IsUnkillable = UnKillable;
                    unit.IsUntargetable = UnTargetable;
//                    Log.Error(this, unit + " UnDamageable " + unit.IsUndamageable);
//                    Log.Error(this, unit + " UnKillable " + unit.IsUnkillable);
//                    Log.Error(this, unit + " UnTargetable " + unit.IsUntargetable);
                }
            }
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

