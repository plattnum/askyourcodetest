using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using GameTypes.GameDefinitions;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Sets certain stats of a designated building.
    /// </summary>
    [Serializable]
    public class SSActionSetSSUITab : ScriptedSequenceAction
    {
        /// <summary>
        /// Designates the building which should be modified.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(3)]
        public BuildingGroup BuildingGroup;

        [Ninject.Inject]
        private UIController UI { get; set; }

        public override string GetDebugName()
        {
            return "Set SSUI Tab: " + BuildingGroup;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if (UI == null)
            {
                LogError("UIController is null");
                return new SimpleAsyncToken(false);
            }

            PanelContext history = new PanelContext
            {
                SelectedBuildingGroup = BuildingGroup
            };

            UI.SetSSUINavigationHistory(SSUINavigationHistoryType.BuildingsSSUI, history);

            return new SimpleAsyncToken(true);
        }
    }
}

