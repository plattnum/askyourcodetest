﻿using System;
using Kixeye.Common;
using Kixeye.WCM.Events;
using Ninject;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionLoadFMODBank : ScriptedSequenceAction
    {
        /// <summary>
        /// The applicaton's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private IAudioBankManager _bankManager
        {
            get;
            set;
        }

        
        /// <summary>
        /// What type of music to play.
        /// </summary>
        [JsonProperty("Name")]
        [ProtoMember(3)]
        public string Name;
        
        /// <summary>
        /// What to do with the music.
        /// </summary>
        [JsonProperty("Load")]
        [ProtoMember(4)]
        public bool Load;
        
        
        public SSActionLoadFMODBank ()
        {
        }
        
        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            SimpleAsyncToken token = new SimpleAsyncToken();
            if(_bankManager == null)
            {
                token.Fail(new Exception("Failed to inject Game Audio to SSActionPlayMusic."));
            }
            else
            {
                if(Load)
                {
                    _bankManager.LoadBank(Name).ReadyUnity(result =>
                    {
                        token.Set(result);
                    });
                }
                else
                {
                    _bankManager.UnloadBank(Name).ReadyUnity(result =>
                    {
                        token.Set(result);
                    });
                }
            }
            
            return token;
        }
        
        
    }
}

