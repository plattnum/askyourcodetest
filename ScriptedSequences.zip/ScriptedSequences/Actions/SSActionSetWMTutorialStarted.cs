﻿using System;
using UnityEngine;
using System.Collections;
using Kixeye.Common;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetWMTutorialStarted : ScriptedSequenceAction
    {
        #region private variables

        [Newtonsoft.Json.JsonProperty("WMTutorialStarted")]
        [ProtoMember(3)]
        public bool WMTutorialStarted = false;

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        #endregion

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            _ssController.HasWMTutorialStarted = WMTutorialStarted;

            return new SimpleAsyncToken(true);
        }

    }
}
