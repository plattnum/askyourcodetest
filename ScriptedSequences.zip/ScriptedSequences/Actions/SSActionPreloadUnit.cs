using System;
using GameTypes;
using Kixeye.WCM.Actor;
using Kixeye.Common;
using Kixeye.WCM.GameData;
using ProtoBuf;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPreloadUnit : ScriptedSequenceAction
    {
        #region Serialized properties

        // skip 3

        /// <summary>
        /// The id of unit to load.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IdOfUnit")]
        [ProtoMember(4)]
        public int IdOfUnit = UnitTypeConstant.Rifleman;

        #endregion

        /// <summary>
        /// The game data with all of the unit definitions
        /// </summary>
        [Inject]
        public WCMGameDataManager GameData { private get; set; }
        
        #region Private variables
        
        /// <summary>
        /// The application's actor manager.
        /// </summary>
        [Inject]
        private ActorManager _actorManager {get; set;}
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (IdOfUnit == UnitTypeConstant.Invalid)
            {
                throw new ApplicationException("Invalid UnitType");
            }

            SimpleAsyncToken returnToken = new SimpleAsyncToken();

            IAsyncToken<ActorDefinition> loadToken = _actorManager.Load(
                ActorSerializer.ConstructActorPath( "Unit_" + GameData.GetUnitNameByUnitId(IdOfUnit), 1));

            loadToken.ReadyUnity(response =>
            {
                if (!response.Success)
                {
                    returnToken.Fail(response.Error);
                }
                else
                {
                    returnToken.Succeed();
                }
            });
            
            return returnToken;
        }

        #endregion    
        
    }
}

