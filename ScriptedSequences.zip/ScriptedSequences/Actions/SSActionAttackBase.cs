using System;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using GameTypes.GameDefinitions;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using UnityEngine.Serialization;
using UIMode = Kixeye.WCM.ui.BattleHUD.UIMode;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionAttackBase : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The name (location) of the base to load.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BaseName")]
        [ProtoMember(3)]
        public string BaseName;

        /// <summary>
        /// When true, use the minimalist NUX UI
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("DisplayMode")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(4)]
        public UIMode DisplayMode;

        #endregion

        #region Private variables
        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionAttackBase));
        #endregion
        
        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (BaseName == null)
            {
                throw new ApplicationException("BaseName is null");
            }

            SimpleAsyncToken actReturnToken = new SimpleAsyncToken();

            IAsyncToken<Player> playerToken = null;

#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
            if(TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
            {
                playerToken = WCMApplicationDirector.Instance.Players.LoadMissionPlayerByAddressable(BaseName);
            }
            else
#endif
            {
                playerToken = WCMApplicationDirector.Instance.Players.LoadMissionPlayer(BaseName);
            }
            
            playerToken.ReadyUnity( response => 
            {
                if (response.Success)
                {
                    WCMApplicationDirector.Instance.Players.OpponentPlayer = response.Value;
                    Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
                    
                    Platoon attackingPlatoon = (localPlayer != null ? localPlayer.Army.Platoons[0] : null);
                    Platoon airPlatoon = (localPlayer != null ? localPlayer.Army.AirforcePlatoons[0] : null);
        
                    AttackData attackData = new AttackData(
                        AttackTargetData.CreateFirstTutorialTargetData( localPlayer, response.Value),    // TODO: Rename this or make another static function
                        attackingPlatoon,
                        airPlatoon,
                        artilleryPlatoon:null,
                        interfaceMode:DisplayMode);
                    
                    WCMApplicationDirector.Instance.GameStates.LoadAttackingState(attackData, new NullBattleOutcomeDelegate());
                    
                    if (attackingPlatoon.Player != localPlayer)
                    {
                        _logger.Error("Attacking platoon doesn't belong to the local player?!");
                    }
                    
                    actReturnToken.Succeed();
                }
                else
                {
                    _logger.Error("Failed to load base [" + BaseName + "] : " + (response.Error.Message != null ? response.Error.Message : "<no exception>"));
                    actReturnToken.Fail(response.Error);
                }
            });

            return actReturnToken;
        }
        #endregion    
    }
}

