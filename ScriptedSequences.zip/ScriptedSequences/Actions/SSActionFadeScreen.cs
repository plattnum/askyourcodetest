using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionFadeScreen : ScriptedSequenceAction
    {
        public enum FadeType
        {
            FadeOut,
            FadeIn
        }
        
        #region Serialized properties
        
        /// <summary>
        /// Whether to fade out to black or fade in to visibility.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfFade")]
        [ProtoMember(3)]
        public FadeType TypeOfFade = FadeType.FadeOut;
        
        /// <summary>
        /// The amount of time the fade will take to complete.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Duration")]
        [ProtoMember(4)]
        public float Duration = 1.0f;
        
        #endregion
        
         #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (TypeOfFade == FadeType.FadeOut)
            {
                return WCMApplicationDirector.Instance.UI.FadeOut(Duration);
            }
            else
            {
                return WCMApplicationDirector.Instance.UI.FadeIn(Duration);
            }            
        }
        
        #endregion    
    }
}

