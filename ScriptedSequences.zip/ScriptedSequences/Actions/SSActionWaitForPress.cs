using System;
using Kixeye.Common;
using Ninject;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that is completed when the screen is touched.
    /// </summary>
    [Serializable]
    public class SSActionWaitForPress : ScriptedSequenceAction
    {
        /// <summary>
        /// The application's scripted sequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        /// <summary>
        /// The token representing the current act.
        /// </summary>
        private SimpleAsyncToken _actToken;
            
        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {    
            if (_ssController == null)
            {
                return new SimpleAsyncToken(new Exception("Failed to inject Scripted Sequences controller"));
            }

            if (_actToken != null)
            {
                _actToken.ClearCallbacks();
            }

            _ssController.TouchHandlerAdd(HandleCatcherTouched);
            _actToken = new SimpleAsyncToken();

            return _actToken;
        }
    
        /// <summary>
        /// Handles the touch catcher being touched.
        /// </summary>
        /// <param name="sender">Sender.</param>
        private void HandleCatcherTouched()
        {
            _ssController.TouchHandlerRemove(HandleCatcherTouched);

            if (_actToken != null)
            {
                _actToken.Succeed();
            }
        }

    }
}

