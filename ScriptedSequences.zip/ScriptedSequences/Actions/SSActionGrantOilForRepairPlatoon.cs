using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using Model;
using GameTypes.Costing;
using GameTypes;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Grant oil to the player for repairing his platoon.
    /// </summary>
    [Serializable]
    public class SSActionGrantOilForRepairPlatoon : ScriptedSequenceAction
    {
        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            WCMApplicationDirector.Instance.PlayerProcessor.GrantOilForRepairPlatoon();
            return new SimpleAsyncToken(true);
        }

    }
}

