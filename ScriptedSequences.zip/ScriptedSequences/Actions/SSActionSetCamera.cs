using System;
using GameTypes;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetCamera : ScriptedSequenceAction
    {
        public enum AdjustmentType
        {
            Position,
            Zoom,
            PositionAndZoom,
            Absolute,
        }
        
        public enum EasingType
        {
            InOut,
            In,
            Out,
            QuadraticIn,
            QuadraticOut,
            QuadraticInOut,
            None,
        }
        
        #region Serialized properties

        /// <summary>
        /// Whether to move the camera, zoom it or both.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfAdjustment")]
        [ProtoMember(3)]
        public AdjustmentType TypeOfAdjustment;
        
        /// <summary>
        /// The amount of time for the camera to interpolate to the position/zoom.  If 0 it will snap.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("InterpolateTime")]
        [ProtoMember(4)]
        public float InterpolateTime;
        
        /// <summary>
        /// The type of easing that will be used for the interpolation.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfEasing")]
        [ProtoMember(5)]
        public EasingType TypeOfEasing = EasingType.InOut;
        
        /// <summary>
        /// The position to move the camera to.
        /// </summary>        
        [Newtonsoft.Json.JsonIgnore]
        public Vector3 LookAtPosition 
        { 
            get
            {
                return new Vector3(_lookAtPosition.x, _lookAtPosition.y, _lookAtPosition.z);
            }
            set
            {
                _lookAtPosition.x = value.x;
                _lookAtPosition.y = value.y;
                _lookAtPosition.z = value.z;
            }
        }
        
        /// <summary>
        /// The backing position data for this position
        /// </summary>
        [Newtonsoft.Json.JsonProperty("LookAtPosition")]
        [ProtoMember(6)]
        public PositionData _lookAtPosition = new PositionData();

        
        /// <summary>
        /// The amount of zoom to apply to the camera.  0.0 is zoomed out to the widest view and 1.0 is zoomed in to our maximum zoom level.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ZoomPercent")]
        [ProtoMember(7)]
        public float ZoomPercent;
        
        /// <summary>
        /// The spin around the look-at point, in degrees.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Yaw")]
        [ProtoMember(8)]
        public float Yaw = WCMCameraController.DEFAULT_YAW;
        
        /// <summary>
        /// The camera position when using an absolute setting (setting camera position and rotation directly).
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Vector3 AbsolutePosition 
        { 
            get
            {
                return new Vector3(_absolutePosition.x, _absolutePosition.y, _absolutePosition.z);
            }
            set
            {
                _absolutePosition.x = value.x;
                _absolutePosition.y = value.y;
                _absolutePosition.z = value.z;
            }
        }
        
        /// <summary>
        /// The backing position data for this position. Should only be modified by the serializer!
        /// </summary>
        [Newtonsoft.Json.JsonProperty("AbsolutePosition")]
        [ProtoMember(9)]
        public PositionData _absolutePosition = new PositionData();

        
        /// <summary>
        /// The camera rotation when using an absolute setting (setting camera position and rotation directly).
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Quaternion AbsoluteRotation 
        { 
            get
            {
                return new Quaternion(_absoluteRotation.x, _absoluteRotation.y, _absoluteRotation.z, _absoluteRotation.w);
            }
            set
            {
                _absoluteRotation.x = value.x;
                _absoluteRotation.y = value.y;
                _absoluteRotation.z = value.z;
                _absoluteRotation.w = value.w;
            }
        }
        
        /// <summary>
        /// The backing position data for this position. Should only be modified by the serializer!
        /// </summary>
        [Newtonsoft.Json.JsonProperty("AbsoluteRotation")]
        [ProtoMember(101)]
        public QuaternionData _absoluteRotation = new QuaternionData();

        
        /// <summary>
        /// If true then position bounds will be ignored for this camera move.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("IgnoreBounds")]
        [ProtoMember(102)]
        public bool IgnoreBounds = true;
        
        /// <summary>
        /// If true then action won't complete until the camera has reached its destination.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("WaitForMove")]
        [ProtoMember(103)]
        public bool WaitForMove = false;
        
        #endregion

        #region Private variables
        
        /// <summary>
        /// Used to store the token that is return from Act if the action should wait for the interpolate to end.
        /// </summary>
        SimpleAsyncToken _interpolateEndToken = null;

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionSetCamera));
        
        #endregion
        
        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            WCMCameraController camera = WCMApplicationDirector.Instance.Camera;
            if (camera == null)
            {
                return new SimpleAsyncToken( new ApplicationException("The application camera is null") );
            }

            if (_interpolateEndToken != null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn(string.Format("{0} is starting a camera move action while someone else is already waiting on one to finish", GetDebugNameFull()));
                }
                return _interpolateEndToken;
            }
            
            WCMCameraController.EasingFunc easeFunction = null;
            switch (TypeOfEasing)
            {
            case EasingType.In : easeFunction = Easing.Cubic.In; break;
            case EasingType.Out : easeFunction = Easing.Cubic.Out; break;
            case EasingType.InOut : easeFunction = Easing.Cubic.InOut; break;
            case EasingType.QuadraticIn: easeFunction = Easing.Quadratic.In; break;
            case EasingType.QuadraticOut: easeFunction = Easing.Quadratic.Out; break;
            case EasingType.QuadraticInOut: easeFunction = Easing.Quadratic.InOut; break;
            case EasingType.None : easeFunction = (none)=>{ return none; }; break;
            }
            
            if (TypeOfAdjustment == AdjustmentType.Absolute)
            {
                camera.IgnoreBounds = true;
                camera.Interpolate( AbsolutePosition, AbsoluteRotation, InterpolateTime, easeFunction );
            }
            else
            {
                float zoom = camera.Zoom;
                float yaw = camera.Yaw;
                Vector3 position = camera.LookAtPosition;
                if (TypeOfAdjustment == AdjustmentType.Position || TypeOfAdjustment == AdjustmentType.PositionAndZoom)
                {
                    //Log.Error(this, "Looking at position " + LookAtPosition);
                    position = LookAtPosition;
                    yaw = Yaw;
                }
                            
                if (TypeOfAdjustment == AdjustmentType.Zoom || TypeOfAdjustment == AdjustmentType.PositionAndZoom)
                {
                    zoom = (ZoomPercent * (WCMCameraController.ZOOM_NORMAL_MAX - WCMCameraController.ZOOM_NORMAL_MIN)) + WCMCameraController.ZOOM_NORMAL_MIN;
                }
                
                if (IgnoreBounds)
                {
                    camera.IgnoreBounds = true;
                }
                
                camera.Interpolate( position, zoom, yaw, null, InterpolateTime, easeFunction );
            }

            if (InterpolateTime > 0f)
            {
                camera.InterpolateEnded += OnInterpolateEnd;
            }
            else
            {
                if (IgnoreBounds || TypeOfAdjustment == AdjustmentType.Absolute)
                {
                    // reset the bounds
                    camera.IgnoreBounds = false;
                }
            }
            
            if (!WaitForMove || InterpolateTime == 0f)
            {
                return new SimpleAsyncToken(true);
            }
            else
            {
                _interpolateEndToken = new SimpleAsyncToken();
                return _interpolateEndToken;
            }
            
        }
        
        #endregion    
        
        #region Private methods
        
        /// <summary>
        /// Called when the camera is done interpolating
        /// </summary>
        private void OnInterpolateEnd()
        {
            WCMCameraController camera = WCMApplicationDirector.Instance.Camera;
            if (camera == null)
            {
                Log.Error(this, "Camera not found during Set Camera action.");
                return;
            }
            
            if (IgnoreBounds || TypeOfAdjustment == AdjustmentType.Absolute)
            {
                camera.IgnoreBounds = false;
            }
            if (_interpolateEndToken != null)
            {
                _interpolateEndToken.Succeed();
            }
            camera.InterpolateEnded -= OnInterpolateEnd;
            _interpolateEndToken = null;
        }
        
        #endregion
    }
}

