using System;
using Kixeye.Common;
using Kixeye.WCM.GameData;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Removes a building from the base.
    /// </summary>
    [Serializable]
    public class SSActionRemoveBuilding : ScriptedSequenceAction
    {
        /// <summary>
        /// Designates the building to remove.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(3)]
        public BuildingDesignator Designator
        {
            get { return _building; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _building = new BuildingDesignator();


        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            Base currentBase = WCMApplicationDirector.Instance.World.SpawnedBase;
            if (currentBase == null)
            {
                return new SimpleAsyncToken(new Exception("Cannot remove building, currently spawned base is null"));
            }

            Building buildingToRemove = Designator.GetBuilding();

            if (buildingToRemove != null)
            {
                currentBase.RemoveBuilding(buildingToRemove);
            }

            return new SimpleAsyncToken(true);
        }

    }
}

