﻿using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using GameTypes;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetSquadBehaviour : ScriptedSequenceAction
    {
        #region Serialized properties
        /// <summary>
        /// The squad to set the combat behaviour for.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SquadToModify")]
        [ProtoMember(3)]
        public SquadDesignator SquadToModify = new SquadDesignator();

        /// <summary>
        /// The Behaviour type to set for squad.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BehaviourType")]
        [ProtoMember(4)]
        public UnitBehaviorType BehaviourType ;
        #endregion

        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Player thePlayer;
            Platoon platoon;
            Squad squad = SquadToModify.GetSquad(out thePlayer, out platoon);

            if (squad == null)
            {
                Log.Error(this, "Cannot find squad to modify combat behaviour for.");
            }
            else
            {
                squad.BehaviorType = BehaviourType;
                foreach (Unit unit in squad.Units)
                {
                    unit.Data.BehaviorType = BehaviourType;
                }
            }

            return new SimpleAsyncToken(true);
        }
        #endregion    

    }
}
