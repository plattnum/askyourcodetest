using System;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using GameTypes.GameDefinitions;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Ninject;
using UnityEngine.AddressableAssets;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionUIIndicator : ScriptedSequenceAction
    {
        #region Serialized properties

        /// <summary>
        /// [DEPRECATED] The name of the user interface element to show the interface over.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ElementName")]
        [ProtoMember(3)]
        public string UIElementName = "";

        /// <summary>
        /// The user interface element to show the interface over.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UIElement")]
        [ProtoMember(4)]
        public UIElementDesignator UIElement = new UIElementDesignator();

        /// <summary>
        /// The name of the prefab to instantiate for this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IndicatorPrefab")]
        [ProtoMember(5)]
        public PrefabReference IndicatorPrefab = new PrefabReference();
        
        /// <summary>
        /// Where to position the indicator relative to the UI element.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ElementOffset")]
        [ProtoMember(6)]
        public ScriptedSequenceIndicator.UIElementOffsetType ElementOffset = ScriptedSequenceIndicator.UIElementOffsetType.Middle;

        /// <summary>
        /// The amount of rotation to be applied to this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ElementRotation")]
        [ProtoMember(7)]
        public float ElementRotation = 0f;

        // SKIP 8

        [Newtonsoft.Json.JsonProperty("Screen Up Offset")]
        [ProtoMember(9)]
        public float ScreenUpOffset = 0f;

        [Newtonsoft.Json.JsonProperty("Screen Over Offset")]
        [ProtoMember(10)]
        public float ScreenOverOffset = 0f;
        
        /// <summary>
        /// The name of the prefab to instantiate for this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IndicatorPrefabTierAssetReference")]
        [ProtoMember(11)]
        public PrefabTierAssetReference IndicatorPrefabTierAssetReference = new PrefabTierAssetReference();

        #endregion

        #region Private Variables

        /// <summary>
        /// The application's data manager.
        /// </summary>
        [Inject]
        private DataManager _dataManager
        {
            get;
            set;
        }

        /// <summary>
        /// The indicator ScriptedSequenceIndicator
        /// </summary>
        private ScriptedSequenceIndicator _indicatorScript = null;

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionUIIndicator));

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            return "UI Indicator: {0} ({1} @ {2}+{3}\u00b0)".FormatWith(
                UIElement.GetDescription(),
                IndicatorPrefab.GetDebugName(),
                ElementOffset,
                ElementRotation
            );
        }

        /// <summary>
        /// Sets up the action after it's loaded.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            // version the old style that just had a button name
            if (!String.IsNullOrEmpty(UIElementName))
            {
                UIElement.TypeOfDesignation = UIElementDesignator.DesignationType.ByName;
                UIElement.ElementName = UIElementName.Replace('.', '/');
                // replace analytics-style dot separator with Unity slash separator
                UIElementName = null;
            }
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            SimpleAsyncToken returnToken = new SimpleAsyncToken();
            if (IndicatorPrefab.GUID == null)
            {
                return new SimpleAsyncToken(new Exception("No indicator object prefab set"));
            }
            
            if (_dataManager == null)
            {
                return new SimpleAsyncToken(new Exception("No DataManager set"));
            }

            IAsyncToken<GameObject> asyncToken = null;
            
#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
            if(TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
            {
                asyncToken = IndicatorPrefabTierAssetReference.Load();
            }
            else
#endif
            {
                asyncToken = IndicatorPrefab.Load(_dataManager);
            }

            asyncToken.ReadyUnity(response =>
                {
                    if (!response.Success)
                    {
                        returnToken.Fail(response.Error);
                    }
                    else
                    {
                        GameObject prefab = response.Value;
                        if (prefab == null)
                        {
                            returnToken.Fail(new Exception("Could not load prefab."));
                        }
                        else
                        {
                            _indicatorScript = WCMObjectPoolPreloader.SpawnObject<ScriptedSequenceIndicator>(prefab);
                            if (_indicatorScript == null)
                            {
                                returnToken.Fail(new Exception("Could not instantiate new indicator object."));
                            }
                            else
                            {
                                _indicatorScript.PoolingPrefabName = prefab.name;
                                GameObject element = UIElement.GetUIElement();
                                if (element == null)
                                {
                                    if (!string.IsNullOrEmpty(_indicatorScript.PoolingPrefabName))
                                    {
                                        WCMObjectPoolPreloader.DespawnObject(_indicatorScript.gameObject, _indicatorScript.PoolingPrefabName);
                                    }
                                    _indicatorScript = null;
                                    returnToken.Fail(new Exception("Could not find UI Element by [" + UIElement.GetDescription() + "]"));
                                    return;
                                }

                                if (element.activeInHierarchy == false && _logger.IsEnabled(LogMessageLevel.Warn))
                                {
                                    _logger.Warn(GetDebugNameFull() + " showing an indicator on " + UIElement.GetDescription() + " (" + element.gameObject + ") " + " which is not currently active.");
                                }

                                RectTransform rectUGUI = element.GetComponent<RectTransform>();
                                if (rectUGUI == null)
                                {
                                    var transformCache = element.transform;

                                    for (int i = 0, count = transformCache.childCount; i < count; ++i)
                                    {
                                        rectUGUI = transformCache.GetChild(i).gameObject.GetComponent<RectTransform>();
                                        if (rectUGUI != null)
                                        {
                                            break;
                                        }
                                    }

                                    if (rectUGUI == null)
                                    {
                                        if (!string.IsNullOrEmpty(_indicatorScript.PoolingPrefabName))
                                        {
                                            WCMObjectPoolPreloader.DespawnObject(_indicatorScript.gameObject, _indicatorScript.PoolingPrefabName);
                                        }
                                        _indicatorScript = null;
                                        returnToken.Fail(new Exception("UI Element is not derived from RectTransform and has no RectTransform children: [" + UIElementName + "]"));
                                        return;
                                    }
                                }

                                _indicatorScript.SetIndicateTarget(rectUGUI, ElementOffset, ElementRotation, new Vector3(ScreenUpOffset/100, ScreenOverOffset/100, 0), Parent.GetDebugName());
                                WCMApplicationDirector.Instance.ScriptedSequences.Indicators.Add(_indicatorScript);

                                returnToken.Succeed();
                            }
                        }
                    }
                });

            return returnToken;
        }
        
        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            for (int i = 0; i < IndicatorPrefabTierAssetReference.GUIDs.Length; i++)
            {
                string guid = IndicatorPrefabTierAssetReference.GUIDs[i];
                if (!string.IsNullOrEmpty(guid))
                {
                    IndicatorPrefabTierAssetReference.AssetReferencesByTier[i] = new AssetReference(guid);
                }
            }
            
            base.WriteTo(saver);
#endif
        }

        #endregion
    }
}
