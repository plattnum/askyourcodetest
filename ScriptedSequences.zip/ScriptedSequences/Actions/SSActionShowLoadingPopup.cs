﻿using System;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionShowLoadingPopup : ScriptedSequenceAction
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("Show Popup")]
        [ProtoMember(3)]
        public bool ShowPopup;

        #endregion

        [Inject]
        private PopupController PopupController { get; set; }
        
        /// <summary>
        /// Called when we want to show or hide the loading popup
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (PopupController == null)
            {
                return new SimpleAsyncToken(true);
            }
            
            if (ShowPopup)
            {
                // do not cause popup watching events to fire when showing our
                //    loading screen from an SS
                PopupController.OpenLoadingPopup(fireEvents: false);                
            }
            else
            {
                PopupController.CloseLoadingPopup();
            }
            
            return new SimpleAsyncToken(true);
        }        
    }
}