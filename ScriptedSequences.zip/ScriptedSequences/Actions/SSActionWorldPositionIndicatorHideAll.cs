using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.WCM.GameData;
using Kixeye.Common.StateMachine;
using System.Collections.Generic;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionWorldPositionIndicatorHideAll : ScriptedSequenceAction
    {
        #region Private Variables
        
        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionWorldPositionIndicatorHideAll));
        
        #endregion

        #region public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            ScriptedSequencesController controller = WCMApplicationDirector.Instance.ScriptedSequences;
            for (int i = 0; i < controller.Indicators.Count; i++)
            {
                ScriptedSequenceIndicator indicator = controller.Indicators[i];
                if (!string.IsNullOrEmpty(indicator.PoolingPrefabName))
                {
                    WCMObjectPoolPreloader.DespawnObject(indicator.gameObject, indicator.PoolingPrefabName);
                }
            }
            controller.Indicators.Clear();
            
            return new SimpleAsyncToken(true);
        }
        
        #endregion
        
    }
}

