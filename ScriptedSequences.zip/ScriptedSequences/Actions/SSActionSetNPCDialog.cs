using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.WCM.Events;
using Ninject;
using ProtoBuf;
using UnityEngine;
using Newtonsoft.Json;
using I2.Loc;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetNPCDialog : ScriptedSequenceAction
    {
        public enum CloseOption
        {
            TapAnywhere,
            TapOnDialog
        }

        #region Private Fields
        
        private static SimpleAsyncToken _actToken;

        /// <summary>
        /// The application's scripted sequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }
        #endregion

        #region Public Fields

        /// <summary>
        /// If the NPC Dialog overlay should be enabled or not.
        /// </summary>
        [JsonProperty("Enabled")]
        [ProtoMember(3)]
        public bool Enabled;

        /// <summary>
        /// The dialog message key.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("DialogMessageKey")]
        [ProtoMember(4)]
        public string DialogMessageKey;

        /// <summary>
        /// The text used to identify the sprite in the atlas.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SpriteKey")]
        [ProtoMember(6)]
        public string SpriteKey;

        /// <summary>
        /// Whether to show the "continue" ui element in the NPC dialog window.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ShowContinueButton")]
        [ProtoMember(7)]
        public bool ShowContinueButton = false;
        
        /// <summary>
        /// Whether to show the portrait in reverse on the other side of the dialog.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ReversePortrait")]
        [ProtoMember(8)]
        [Obsolete]
        public bool ReversePortrait;

        [Newtonsoft.Json.JsonProperty("PlayAudio")]
        [ProtoMember(9)]
        public bool PlayAudio;

        [Newtonsoft.Json.JsonProperty("AudioEventName")]
        [ProtoMember(10)]
        public string AudioEventName;

        [Newtonsoft.Json.JsonProperty("Delta on Y axis")]
        [ProtoMember(11)]
        [Obsolete]
        public float deltaY = 0.0f;

        [JsonProperty("MigrationVersion")]
        [ProtoMember(12)]
        public int MigrationVersion;

        [Newtonsoft.Json.JsonProperty("Position")]
        [ProtoMember(13)]
        public DialogOverlayWidget.Position Position = DialogOverlayWidget.Position.BottomLeft;

        /// <summary>
        /// The dialog title key.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("DialogTitleKey")]
        [ProtoMember(14)]
        public string DialogTitleKey;

        /// <summary>
        /// The preferred close method for this dialog.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("CloseMethod")]
        [ProtoMember(15)]
        public CloseOption CloseMethod = CloseOption.TapAnywhere;
        #endregion


        #region Public methods

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionSetNPCDialog));

        public override void Migrate(bool onCreate)
        {
            base.Migrate(onCreate);
            if (onCreate)
            {
                MigrationVersion = 1;
                return;
            }
            if (MigrationVersion < 1)
            {
                #pragma warning disable 0618, 0612 // deprecated field
                if (Mathf.Approximately(deltaY, 0))
                {
                    Position = ReversePortrait ? DialogOverlayWidget.Position.BottomRight : DialogOverlayWidget.Position.BottomLeft;
                }
                else
                {
                    Position = ReversePortrait ? DialogOverlayWidget.Position.TopRight : DialogOverlayWidget.Position.TopLeft;
                }
                #pragma warning restore 0618, 0612 // deprecated field
                MigrationVersion = 1;
            }
            if (MigrationVersion < 2)
            {
                if (DialogMessageKey == "<NONE>")
                {
                    DialogMessageKey = null;
                }
                MigrationVersion = 2;
            }
        }

        

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("%%% SSActionSetNPCDialog.Act(" + this.DialogMessageKey + ") started for " + GetDebugNameFull());
            }

            var uiController = UIController.Instance;
            if (uiController == null)
            {
                _logger.Error("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() +
                    " UIController doesn't exist!?");
                return new SimpleAsyncToken(true);
            }

            if (uiController.GetDialogOverlayInstance == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() +
                    " UIController.GetDialogOverlayInstance == null, good");
                }
                var actToken = new SimpleAsyncToken();
                ScriptedSequencesController.GetDialogOverlay().Ready(prefabToken =>
                {
                    if (!prefabToken.Success)
                    {
                        actToken.Fail(prefabToken.Error);
                        return;
                    }
                    var prefab = prefabToken.Value.gameObject;
                    if (prefab == null)
                    {
                        // Failed to load the overlay prefab
                        actToken.Fail(new Exception("Could not load dialog overlay prefab"));
                        return;
                    }
                    Exception exception;
                    uiController.GetDialogOverlayInstance =
                        ScriptedSequencesController.SpawnComponentAndAttachToUICanvas<DialogOverlayWidget>(prefab,
                            out exception);
                    if (exception != null)
                    {
                        actToken.Fail(exception);
                        return;
                    }
                    // Recursively call Act, now with _overlayInstance set.
                    Act().Ready(actToken.Set);
                });
                return actToken;
            }
            else
            {
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() + " UIController.GetDialogOverlayInstance != null, hmmmm?");
                }
            }

            if (Enabled)
            {
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() + " Enabled == true");
                }
                // if there is a dialog audio playing, close it first
                CloseDialogAudio();

                WCMApplicationDirector.Instance.UI.OnShowNpcDialog();

                string title = string.IsNullOrEmpty(DialogTitleKey) ? ScriptLocalization.GlobalUI.Category + SpriteKey : DialogTitleKey;
                uiController.GetDialogOverlayInstance.ShowOverlay(Position, SpriteKey, title, DialogMessageKey, ShowContinueButton);
                WCMApplicationDirector.Instance.Events.HandleEvent(UIElementEvent.GetInstance(UIElementEvent.UIEventType.ShowNPCDialog, 
                    uiController.GetDialogOverlayInstance.gameObject));

                if (PlayAudio && !string.IsNullOrEmpty(AudioEventName))
                {
                    ScriptedSequenceAudioEvent ssAudioEventInstance = ScriptedSequenceAudioEvent.GetInstance(AudioEventName);
                    ssAudioEventInstance.Type = ScriptedSequenceAudioEvent.ActionType.Start;
                    WCMApplicationDirector.Instance.Events.HandleEvent(ssAudioEventInstance);
                }

                if (ShowContinueButton)
                {
                    uiController.GetDialogOverlayInstance.OnTap += HandleOverlayTap;

                    if (CloseMethod == CloseOption.TapOnDialog)
                    {
                        if (_actToken == null)
                        {
                            _actToken = new SimpleAsyncToken();
                        }
                        return _actToken;
                    }
                }
            }
            else
            {
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() + " Enabled == false");
                    _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() + " now UIController.GetDialogOverlayInstance.HideDialogs()");
                }
                uiController.GetDialogOverlayInstance.HideDialogs();

                if (CloseMethod != CloseOption.TapOnDialog)
                {
                    CloseDialogAudio();
                } 
                else if (CloseMethod == CloseOption.TapOnDialog && _actToken != null)
                {
                    CloseDialogAudio();
                    _actToken.Fail(new Exception("NPC dialog closed while waiting for tap."));
                    _actToken = null;
                }
                uiController.GetDialogOverlayInstance.gameObject.SafeDestroy();
                uiController.GetDialogOverlayInstance = null;
            }

            return new SimpleAsyncToken(true);
        }

        public void HandleOverlayTap()
        {
            var uiController = UIController.Instance;
            if ( uiController != null && uiController.GetDialogOverlayInstance )
            {
                uiController.GetDialogOverlayInstance.OnTap -= HandleOverlayTap;

                uiController.GetDialogOverlayInstance.HideDialogs();
            }
            else
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn("I would have crashed here. Please use me to track down why.");
                }
            }

            CloseDialogAudio();

            if ( _actToken != null )
            {
                _actToken.Succeed();
                _actToken = null;
            }

            _ssController.TouchHandlerClick();
        }
        #endregion

        #region Private methods

        private void CloseDialogAudio()
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("%%% SSActionSetNPCDialog.Act() " + GetDebugNameFull() + " now closing audio '" + AudioEventName + "' because we can.");
            }
            ScriptedSequenceAudioEvent ssAudioEventInstance = ScriptedSequenceAudioEvent.GetInstance(AudioEventName);
            ssAudioEventInstance.Type = ScriptedSequenceAudioEvent.ActionType.Stop;
            WCMApplicationDirector.Instance.Events.HandleEvent(ssAudioEventInstance);
        }

        #endregion
    }

    public class ScriptedSequenceAudioEvent : SingletonEvent<ScriptedSequenceAudioEvent, string>
    {
        public enum ActionType
        {
            Start,
            Stop,
        }

        /// <summary>
        /// The action type required by this event (Stop or Start)
        /// </summary>
        public ActionType Type { get; set; }
    }
}

