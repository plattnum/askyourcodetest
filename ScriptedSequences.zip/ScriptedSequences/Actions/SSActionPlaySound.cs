using System;
using Kixeye.Common;
using Ninject;
using Newtonsoft.Json;
using Kixeye.Common.Audio;
using System.Collections.Generic;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Plays a sound effect.
    /// </summary>
    [Serializable]
    public class SSActionPlaySound : ScriptedSequenceAction
    {
        /// <summary>
        /// Defines actions we can do with sounds.
        /// </summary>
        public enum SoundAction
        {
            OneShot,
            Play,
            Stop,
            Pause,
            Resume,
        }    

        /// <summary>
        /// The application's audio controller.
        /// </summary>
        [Inject]
        private IGameAudio _audio
        {
            get;
            set;
        }

        /// <summary>
        /// The application's Scripted Sequences Controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        /// <summary>
        /// The name of the sound to play.
        /// </summary>
        [JsonProperty("SoundName")]
        [ProtoMember(3)]
        public string SoundName;

        /// <summary>
        /// The tag to apply to the sound played or the tag of the sounds to
        /// stop.
        /// </summary>
        [JsonProperty("Tag")]
        [ProtoMember(4)]
        public string Tag;

        /// <summary>
        /// If the action should complete only when the sound has finished.
        /// </summary>
        [JsonProperty("WaitUntilEnd")]
        [ProtoMember(5)]
        public bool WaitUntilEnd;

        /// <summary>
        /// What to do with the sound.
        /// </summary>
        [JsonProperty("Action")]
        [ProtoMember(6)]
        public SoundAction Action;

        /// <summary>
        /// The duration to fade the sound.
        /// </summary>
        [JsonProperty("FadeDuration")]
        [ProtoMember(7)]
        public float FadeDuration = 0.1f;

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if (_audio == null || _ssController == null)
            {
                return new SimpleAsyncToken(new Exception("Not all components were injected sucessfully!"));
            }
                
            switch(Action)
            {
            case SoundAction.OneShot:
                return PlayOneShot();
            case SoundAction.Play:
                return PlaySound();
            case SoundAction.Stop:
                return StopSounds();
            case SoundAction.Pause:
                return PauseSounds();
            case SoundAction.Resume:
                return ResumeSounds();
            }

            return new SimpleAsyncToken(true);
        }

        /// <summary>
        /// Plays the action's sound.
        /// </summary>
        /// <returns>The action's completion token.</returns>
        private SimpleAsyncToken PlayOneShot()
        {
            // Create sound effect.
            _audio.PlayOneShotSoundEffect(SoundName);

            return new SimpleAsyncToken(true);
        }

        /// <summary>
        /// Plays the action's sound.
        /// </summary>
        /// <returns>The action's completion token.</returns>
        private SimpleAsyncToken PlaySound()
        {
            // Create sound effect.
            ISoundEffect effect = _audio.PlayTrackedSoundEffect(SoundName);
            if (effect == null)
            {
                return new SimpleAsyncToken(new Exception("Failed to play sound effect with name " + SoundName));
            }
                
            // Configure sound effect.
            if (Tag != null)
            {
                _ssController.AddSoundEffectWithTag(effect, Tag);
            }

            return new SimpleAsyncToken(true);
        }

        /// <summary>
        /// Stops the action's specified sounds.
        /// </summary>
        /// <returns>The completion token.</returns>
        private SimpleAsyncToken StopSounds()
        {
            if (Tag == null)
            {
                return new SimpleAsyncToken(new Exception("Can't stop sounds without a tag!"));
            }

            IEnumerator<ISoundEffect> soundIterator = _ssController.GetSoundEffectsWithTag(Tag).GetEnumerator();
            while(soundIterator.MoveNext())
            {
                soundIterator.Current.Stop(FadeDuration);
            }
            _ssController.RemoveAllSoundEffectsWithTag(Tag);


            return new SimpleAsyncToken(true);
        }

        /// <summary>
        /// Pauses the action's specified sounds.
        /// </summary>
        /// <returns>The completion token.</returns>
        private SimpleAsyncToken PauseSounds()
        {
            if( Tag == null)
            {
                return new SimpleAsyncToken(new Exception("Can't pause sounds without a tag!"));
            }
            IEnumerator<ISoundEffect> soundIterator = _ssController.GetSoundEffectsWithTag(Tag).GetEnumerator();
            while(soundIterator.MoveNext())
            {
                soundIterator.Current.Pause(true);
            }
            return new SimpleAsyncToken(true);
        }

        /// <summary>
        /// Resume's the action's specified sounds.
        /// </summary>
        /// <returns>The completion token</returns>
        private SimpleAsyncToken ResumeSounds()
        {
            if( Tag == null )
            {
                return new SimpleAsyncToken(new Exception("Can't resume sounds without a tag!"));
            }
            IEnumerator<ISoundEffect> soundIterator = _ssController.GetSoundEffectsWithTag(Tag).GetEnumerator();
            while(soundIterator.MoveNext())
            {
                soundIterator.Current.Pause(false);
            }
            return new SimpleAsyncToken(true);
        }
    }
}

