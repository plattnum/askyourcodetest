﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kixeye.Common;
using Kixeye.WCM;
using Kixeye.WCM.Events;
using Kixeye.WCM.ScriptedSequences;
using Kixeye.WCM.ui;
using Newtonsoft.Json;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDebugPopup : ScriptedSequenceAction
    {
        #region Serialized properties

        [JsonProperty("Show")]
        [ProtoMember(3)]
        public string Message;

        [JsonProperty("WaitForOk")]
        [ProtoMember(4)]
        public bool WaitForOk = true;

        [JsonProperty("AllowCancel")]
        [ProtoMember(5)]
        public bool AllowCancel = false;

        #endregion

        [Inject]
        private ScriptedSequencesController ScriptedSequences { get; set; }

        [Inject]
        private PopupController PopupController { get; set; }

#if DEBUG

        private SimpleAsyncToken _actToken;

        private Action _restoreInteraction;

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            var okayButtonText = WaitForOk ? "Continue" : "OK";
            PopupSettings popupSettings;
            var header = "Scripted Sequence " + Parent.GetDebugNameFull();
            if (AllowCancel)
            {
                popupSettings = PopupSettings.GenericTwoOptionModal(header, Message, okayButtonText, "Cancel", OnOkayClicked, OnCancelClicked);
            }
            else
            {
                popupSettings = PopupSettings.GenericNotification(header, Message, OnOkayClicked, okayButtonText);
            }

            PopupController.OpenPopup(popupSettings);

            if (!WaitForOk)
            {
                return new SimpleAsyncToken(true);
            }

            _actToken = new SimpleAsyncToken();
            return _actToken;
        }

        private void OnOkayClicked()
        {
            if (_restoreInteraction != null)
            {
                _restoreInteraction();
                _restoreInteraction = null;
            }
            if (_actToken != null)
            {
                _actToken.Succeed();
                _actToken = null;
            }
        }

        private void OnCancelClicked()
        {
            if (_actToken != null)
            {
                _actToken.Fail(new Exception("User canceled."));
                _actToken = null;
                ScriptedSequences.ForceReEnableUI();
            }
        }
#else
        public override ISimpleAsyncToken Act()
        {
            return new SimpleAsyncToken(true);
        }
#endif
    }
}
