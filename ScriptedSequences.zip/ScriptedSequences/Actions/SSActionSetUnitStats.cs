using System;
using Kixeye.Common;
using Newtonsoft.Json;
using System.Collections.Generic;
using GameTypes.BattleEvents;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Sets stats of a unit or many units in a squad.
    /// </summary>
    [Serializable]
    public class SSActionSetUnitStats : ScriptedSequenceAction
    {
        /// <summary>
        /// Which stats to set.
        /// </summary>
        [JsonProperty("Flags")]
        [JsonConverter(typeof(FlagEnumConverter))]
        [ProtoMember(3)]
        public UnitStatFlags Flags;
        
        /// <summary>
        /// The squad in which the units reside.
        /// </summary>
        [JsonProperty("Squad")]
        [ProtoMember(4)]
        public SquadDesignator Squad
        {
            get { return _squad; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _squad = new SquadDesignator();

        /// <summary>
        /// Which unit in the squad should have it's stats set.
        /// </summary>
        [JsonProperty("UnitIndex")]
        [ProtoMember(5)]
        public int UnitIndex;
        
        /// <summary>
        /// The value of the health stat to set.
        /// </summary>
        [JsonProperty("Health")]
        [ProtoMember(6)]
        public int Health;
        
        /// <summary>
        /// If the stats of all units in the squad should be set.
        /// </summary>
        [JsonProperty("ApplyToSquad")]
        [ProtoMember(7)]
        public bool ApplyToSquad;


        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            Squad squad;
            try
            {
                squad = Squad.GetSquad();
            }
            catch(ApplicationException e)
            {
                return new SimpleAsyncToken(e);
            }

            if (squad == null)
            {
                return new SimpleAsyncToken(new Exception("Squad specified by designator for SSActionSetUnitStats was null!"));
            }
                
            List<Unit> units = squad.Units;

            if (ApplyToSquad)
            {
                for (int i = 0, count = units.Count; i < count; ++i)
                {
                    ApplyToUnit(units[i]);
                }
            }
            else
            {
                if (UnitIndex < 0 || UnitIndex >= units.Count)
                {
                    throw new ApplicationException( string.Format( "{0}: Invalid unit index: {1}", GetDebugNameFull(), UnitIndex) );
                }
                else
                {
                    ApplyToUnit(units[UnitIndex]);
                }
            }
                
            return new SimpleAsyncToken(true);

        }

        /// <summary>
        /// Applys this action's stats to a unit.
        /// </summary>
        /// <param name="unit">Unit.</param>
        private void ApplyToUnit(Unit unit)
        {
            if (unit == null)
            {
                return;
            }

            if ( (Flags & UnitStatFlags.Health) == UnitStatFlags.Health)
            {
                if (Health < unit.Health)
                {
                    unit.TakeDamage(unit.Health - Health, null, null, 1.0f, null);
                }
                else
                {
                    unit.Health = Health;
                }
            }

        }


    }
}

