using System;
using Kixeye.Common;
using Ninject;
using Newtonsoft.Json;
using Kixeye.Common.Audio;
using System.Collections.Generic;
using Kixeye.Core.Logging;
using Kixeye.WCM.AI;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Plays a sound effect.
    /// </summary>
    [Serializable]
    public class SSActionSetAirStrikeDirection : ScriptedSequenceAction
    {
        /// <summary>
        /// The button game object to listen for a press.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("StrikeFrom")]
        [ProtoMember(3)]
        public WingedBrain.AirStrikeDirection StrikeFrom = WingedBrain.AirStrikeDirection.Optimal;

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            WingedBrain.SetPreferredAirStrikeDirection(StrikeFrom);
            return new SimpleAsyncToken(true);
        }
    }
}

