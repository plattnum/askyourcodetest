using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetSelectionEffectsVisible : ScriptedSequenceAction
    {
        #region Serialized properties

        /// <summary>
        /// Whether to globally enable or disable selection effects (highlighting).
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Disable")]
        [ProtoMember(3)]
        public bool Disable;

        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            GameItem.DisableHighlighting = Disable;
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

