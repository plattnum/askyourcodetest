using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPauseGame : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// Whether to pause or un-pause the game.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Pause")]
        [ProtoMember(3)]
        public bool Pause;

        #endregion
        
         #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            WCMApplicationDirector.Instance.Paused = Pause;

            return new SimpleAsyncToken(true);
        }
        
        #endregion    
    }
}

