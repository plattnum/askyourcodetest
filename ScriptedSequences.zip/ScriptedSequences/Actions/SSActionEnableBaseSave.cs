using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionEnableBaseSave : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// Whether to disable or enable base saving
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("EnableSave")]
        [ProtoMember(3)]
        public bool EnableSave;

        #endregion
        
         #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            // Enabling/disabling base save doesn't mean anything anymore.
            return new SimpleAsyncToken(true);
        }
        
        #endregion    
    }
}

