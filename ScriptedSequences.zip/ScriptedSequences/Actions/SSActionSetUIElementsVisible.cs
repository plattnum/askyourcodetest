using System;
using System.Collections.Generic;
using System.Linq;
using Kixeye.WCM.ui;
using Kixeye.Common;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;
using Ninject;
using System.Text;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetUIElementsVisible : ScriptedSequenceAction
    {
        public static void ForceAllUIElementsVisible(ScriptedSequencesController scriptedSequences)
        {
            foreach (var sequence in scriptedSequences.AvailableSequences)
            {
                foreach (var node in sequence.Nodes)
                {
                    foreach (var action in node.Actions)
                    {
                        var uiAction = action as SSActionSetUIElementsVisible;
                        if (uiAction != null)
                        {
                            foreach (var designator in uiAction.ElementDesignators)
                            {
                                foreach (var uiElement in designator.GetUIElements())
                                {
                                    if (uiElement != null)
                                    {
                                        uiElement.SetActive(true);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        #region Serialized properties
            
        /// <summary>
        /// The string name of the element to show/hide.
        /// </summary>        
        [JsonProperty("ElementName")]
        [ProtoMember(3)]
        public List<string> ElementNames = null;

        /// <summary>
        /// Whether to show or hide the element(s).
        /// </summary>        
        [JsonProperty("Show")]
        [ProtoMember(4)]
        public bool Show = false;

        /// <summary>
        /// The list of UI elements to show/hide.
        /// </summary>
        [JsonProperty("ElementDesignators")]
        [ProtoMember(5)]
        public List<UIElementDesignator> ElementDesignators = new List<UIElementDesignator>();

        [JsonProperty("Force Show regardless of setting")]
        [ProtoMember(6)]
        public bool ForceShow = false;

        #endregion
        
        #region Public methods

        /// <summary>
        /// Sets up the action after it's loaded.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (ElementDesignators == null)
            {
                ElementDesignators = new List<UIElementDesignator>();
            }

            // version the old style that just had a name for the UI element
            if (ElementNames != null)
            {
                for (int i = 0, count = ElementNames.Count; i < count; ++i)
                {
                    // replace any analytics-style dot separator with Unity slash separator
                    string name = ElementNames[i].Replace('.', '/');
                    ElementDesignators.Add( new UIElementDesignator{ ElementName = name, TypeOfDesignation = UIElementDesignator.DesignationType.ByName });
                }

                ElementNames.Clear();
                ElementNames = null;
            }
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            for (int i = 0, count = ElementDesignators.Count; i < count; ++i)
            {
                var uiElementDesignator = ElementDesignators[i];
                var uiElements = uiElementDesignator
                    .GetUIElements()
                    .ToArray();
                if (uiElements.Length == 0)
                {
                    if (string.IsNullOrEmpty(uiElementDesignator.GetDescription(brief: true)))
                    {
                        LogError("Node contains empty designator.");
                    }
                    // Removing log spam to clena up logs for 2.11.1
                    //else
                    //{
                    //    LogError("Could not find the following UI Element: {0}",
                    //        uiElementDesignator.GetDescription());
                    //}
                }
                else
                {
                    foreach (var uiElement in uiElements.Select(_ => _.GetComponent<UIElementTag>()))
                    {
                        LogDebug("{0} {1} ({2}): {3}",
                            Show ? "Show" : "Hide",
                            uiElementDesignator.GetDescription(),
                            uiElementDesignator.Tag,
                            uiElement);
                        uiElement.SetHidden(!Show, InteractionManager.UI_STATE_PRIORITY.SCRIPTED_SEQUENCE, uiElementDesignator.Tag, ForceShow);
                    }
                }
            }
            return new SimpleAsyncToken(true);
        }

        #endregion    
    }
}

