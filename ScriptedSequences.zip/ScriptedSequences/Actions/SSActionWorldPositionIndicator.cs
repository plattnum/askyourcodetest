using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.Common;
using Kixeye.WCM.GameState;
using Kixeye.WCM.GameData;
using Kixeye.Common.StateMachine;
using System.Collections.Generic;
using AddressableManager;
using Assets.Source.Scripts.GameData;
using GameTypes.GameDefinitions;
using Ninject;
using UnityEngine.AddressableAssets;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionWorldPositionIndicator : ScriptedSequenceAction
    {
        public enum PositionType
        {
            AbsolutePosition,
            SquadPosition,
            BuildingPosition,
            ZoneArea,
        }
        
        #region Serialized properties
        
        /// <summary>
        /// How the position of the indicator is specified.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfPosition")]
        [ProtoMember(3)]
        public PositionType TypeOfPosition;

        /// <summary>
        /// The backing position data for this position, only modified by the serializer
        /// </summary>
        [Newtonsoft.Json.JsonProperty("WorldPosition")]
        [ProtoMember(4)]
        public PositionData WorldPosition = new PositionData();

        /// <summary>
        /// The backing position data for this position
        /// </summary>
        [Newtonsoft.Json.JsonProperty("WorldPositionOffset")]
        [ProtoMember(5)]
        public PositionData WorldPositionOffset = new PositionData();
        
        /// <summary>
        /// The squad to show an indicator over.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SquadToIndicate")]
        [ProtoMember(6)]
        public SquadDesignator SquadToIndicate = new SquadDesignator();
        
        /// <summary>
        /// The type of building in the current base to show an indicator over.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BuildingToIndicate")]
        [ProtoMember(7)]
        public BuildingDesignator BuildingToIndicate = new BuildingDesignator();
        
        /// <summary>
        /// The name of the prefab to instantiate for this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IndicatorPrefab")]
        [ProtoMember(8)]
        public PrefabReference IndicatorPrefab = new PrefabReference();
        
        [Newtonsoft.Json.JsonProperty("OffsetDirection")]
        [ProtoMember(9)]
        public HexDirection OffsetDirection;

        [Newtonsoft.Json.JsonProperty("OffsetDistance")]
        [ProtoMember(10)]
        public int OffsetDistance;

        /// <summary>
        /// The amount of rotation to be applied to this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IndicatorElementRotation")]
        [ProtoMember(11)]
        public int IndicatorElementRotation = 0;
        
        /// <summary>
        /// The name of the prefab to instantiate for this indicator.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("IndicatorPrefabTierAssetReference")] 
        [ProtoMember(12)]
        public PrefabTierAssetReference IndicatorPrefabTierAssetReference = new PrefabTierAssetReference();
        
        #endregion
            
        #region Private Variables
        
        /// <summary>
        /// The application's data manager.
        /// </summary>
        [Inject]
        private DataManager _dataManager
        {
            get;
            set;
        }
        
        /// <summary>
        /// Saves the position to indicate.
        /// </summary>
        PositionData _positionToIndicate;
        
        /// <summary>
        /// The indicator ScriptedSequenceIndicator
        /// </summary>
        private ScriptedSequenceIndicator _indicatorScript = null;
        
        #endregion
    
        #region public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            SimpleAsyncToken returnToken = new SimpleAsyncToken();
            if (IndicatorPrefab.GUID == null)
            {
                return new SimpleAsyncToken( new Exception("No indicator object prefab set") );
            }
            
            if (_dataManager == null)
            {
                return new SimpleAsyncToken( new Exception("No DataManager set") );
            }

            IAsyncToken<GameObject> asyncToken = null;
#if USING_ADDRESSABLE_SYSTEM || USING_DUAL_BUNDLES_SYSTEM
            if (TuningHelper.GetTuningAsBool(TuningDefinitionType.EnableAddressableOnScriptedSequences))
            {
                asyncToken = IndicatorPrefabTierAssetReference.Load();
            }
            else
#endif
            {
                asyncToken = IndicatorPrefab.Load(_dataManager);
            }
            
            asyncToken.ReadyUnity( response => 
            {
                try
                {
                    if (!response.Success)
                    {
                        returnToken.Fail(response.Error);
                    }
                    else
                    {
                        GameObject prefab = response.Value;
                        if (prefab == null)
                        {
                            returnToken.Fail( new Exception("Could not load prefab.") );
                        }
                        else
                        {
                            _indicatorScript = WCMObjectPoolPreloader.SpawnObject<ScriptedSequenceIndicator>(prefab);
                            if (_indicatorScript == null)
                            {
                                returnToken.Fail(new Exception("Could not instantiate new indicator object.") );
                            }
                            else
                            {
                                _indicatorScript.PoolingPrefabName = prefab.name;
                                Transform indicatorTransform = _indicatorScript.transform;

                                if (indicatorTransform.GetComponent<RectTransform>() != null && WCMApplicationDirector.Instance.UI != null)
                                {
                                    indicatorTransform.SetParent(WCMApplicationDirector.Instance.UI.WorldPositionUIElementsRoot);
                                    indicatorTransform.SetAsFirstSibling();
                                }

                                indicatorTransform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
                                _indicatorScript.gameObject.SetActive(true);

                                WCMApplicationDirector.Instance.ScriptedSequences.Indicators.Add(_indicatorScript);
                                SetIndicatorPosition();
                                returnToken.Succeed();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogError(ex.ToString());
                    returnToken.Fail(ex);
                }
            });
            
            return returnToken;
        }
        
        /// <summary>
        /// Hides the indicator.
        /// </summary>
        public void HideIndicator()
        {
            if (_indicatorScript != null)
            {
                WCMApplicationDirector.Instance.ScriptedSequences.Indicators.Remove(_indicatorScript);
                if (!string.IsNullOrEmpty(_indicatorScript.PoolingPrefabName))
                {
                    WCMObjectPoolPreloader.DespawnObject(_indicatorScript.gameObject, _indicatorScript.PoolingPrefabName);
                }
                _indicatorScript = null;
            }
        }

        #endregion
        
        #region private methods
        
        /// <summary>
        /// Sets the indicator position.
        /// </summary>
        private void SetIndicatorPosition()
        {
            if (_indicatorScript == null)
            {
                return;
            }
            
            if (TypeOfPosition == PositionType.AbsolutePosition)
            {
                _indicatorScript.SetIndicateTarget(WorldPosition, WorldPositionOffset, Parent.GetDebugName());
                _positionToIndicate = WorldPosition;
            }
            else if (TypeOfPosition == PositionType.SquadPosition)
            {
                Squad squad = SquadToIndicate.GetSquad();
                if (squad == null)
                {
                    return;
                }
                else
                {
                    _indicatorScript.SetIndicateTarget(squad, WorldPositionOffset, Parent.GetDebugName());
                    _positionToIndicate = squad.Position;
                }
            }
            else if (TypeOfPosition == PositionType.BuildingPosition)
            {
                Base theBase = null;
                
                IState currentState = WCMApplicationDirector.Instance.GameStates.CurrentState;
                if (currentState is AttackingState)
                {
                    theBase = (currentState as AttackingState).AttackData.AttackTargetData.DefendingPlayer.ActiveBase;
                }
                else
                {
                    theBase = WCMApplicationDirector.Instance.Players.LocalPlayer.ActiveBase;
                }
                
                if (theBase != null)
                {
                    Building toIndicate = BuildingToIndicate.GetBuilding();

                    if (toIndicate == null)
                    {
                        var currentZone = WCMApplicationDirector.Instance.WorldMap.CurrentZone;

                        if (currentZone != null)
                        {
                            foreach (var zoneActorInfo in currentZone.GetAllActors())
                            {
                                if (zoneActorInfo.SpawnerId == BuildingToIndicate.Tag)
                                {
                                    if (OffsetDistance > 0)
                                    {
                                        var hexCell = zoneActorInfo.HexCell.GetNeighbor(OffsetDirection, OffsetDistance);
                                        PositionData indicatorPosition = new PositionData(hexCell.WorldPosition.X, 0,
                                            hexCell.WorldPosition.Y);
                                        _indicatorScript.SetIndicateTarget(indicatorPosition, WorldPositionOffset, Parent.GetDebugName());
                                    }
                                    else
                                    {
                                        _indicatorScript.SetIndicateTarget(zoneActorInfo, WorldPositionOffset, Parent.GetDebugName());
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    else if (toIndicate != null)
                    {
                        _positionToIndicate = toIndicate.Position;    
                        _indicatorScript.SetIndicateTarget(toIndicate, WorldPositionOffset, Parent.GetDebugName());
                    }
                }
            }
            
            // if this is a UI indicator, set its position in screen space
            Transform indicatorTransform = _indicatorScript.transform;

            if (indicatorTransform.GetComponent<RectTransform>() != null)
            {
                indicatorTransform.localPosition = Utilities.WorldToUGUIScreenPos(_positionToIndicate.ToVector());
                indicatorTransform.localPosition = new Vector3(indicatorTransform.localPosition.x, indicatorTransform.localPosition.y, 0f);
                indicatorTransform.localRotation *= Quaternion.Euler(0f, 0f, IndicatorElementRotation);
            }
            else
            {

                indicatorTransform.position = _positionToIndicate.ToVector();
            }
        }
        
        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            for (int i = 0; i < IndicatorPrefabTierAssetReference.GUIDs.Length; i++)
            {
                string guid = IndicatorPrefabTierAssetReference.GUIDs[i];
                if (!string.IsNullOrEmpty(guid))
                {
                    IndicatorPrefabTierAssetReference.AssetReferencesByTier[i] = new AssetReference(guid);
                }
            }
            
            base.WriteTo(saver);
#endif
        }
        #endregion
    }
}
