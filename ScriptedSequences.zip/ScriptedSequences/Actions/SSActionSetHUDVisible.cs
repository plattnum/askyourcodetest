using System;
using System.Collections.Generic;
using Kixeye.WCM.ui;
using Kixeye.Common;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;
using Ninject;
using ProtoBuf;
using System.ComponentModel;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetHUDVisible : ScriptedSequenceAction
    {
        #region Private Fields

        /// <summary>
        /// The applicaton's UI Controller.
        /// </summary>
        [Inject]
        private UIController _ui
        {
            get;
            set;
        }

        #endregion
        
        #region Serialized properties
        
        /// <summary>
        /// Whether to show or hide the element.
        /// </summary>        
        [JsonProperty("Show")]
        [ProtoMember(3)]
        public bool Show = false;

        /// <summary>
        /// If the action should be completed before the HUD fade has completed.
        /// </summary>
        [JsonProperty("WaitForFade")]
        [ProtoMember(4)]
        public bool WaitForFade = false;

        /// <summary>
        /// If hiding the entire hud, we can specify a fade out time.
        /// </summary>
        [JsonProperty("HUDFadeDuration")]
        [ProtoMember(5), DefaultValue(2f)]
        public float HUDFadeDuration = 2f;

        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            var response = new SimpleAsyncToken();
            ApplicationDirector.Instance.Bootstrapper.BootstrapCoroutine(Run(response));
            return response;
        }

        private System.Collections.IEnumerator Run( SimpleAsyncToken response )
        {
            HUDBase hud;
            while ((hud = _ui.CurrentHUD) == null)
            {
                yield return null;
            }

            if (HUDFadeDuration > 0f)
            {
                ISimpleAsyncToken token = hud.SetOpacity( Show ? 1f : 0f, HUDFadeDuration );

                if (!Show)
                {
                    token.AddDependent(response).ReadyUnity( result => 
                    {
                        hud.TransitionOut();
                        hud.SetOpacity(1f, 0f);
                        response.Succeed();
                    });
                }
                else
                {
                    hud.TransitionIn();
                    response.Succeed();
                }
            }
            else
            {
                hud.SetOpacity( Show ? 1f : 0f, HUDFadeDuration );
                hud.gameObject.SetActive( Show );
                response.Succeed();
            }
        }

        #endregion    
    }
}

