using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using UnityEngine;
using Ninject;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;


namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that marks the sequence as completed and disables all further execution of the sequence.
    /// </summary>
    [Serializable]
    public class SSActionCompleteSequence : ScriptedSequenceAction
    {

        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionCompleteSequence));

        #region Private Fields
        /// <summary>
        /// If true, this sequence will be also disabled, not only marked as completed.
        /// </summary>
        [JsonProperty("DisableSequence")]
        [ProtoMember(3)]
        public bool DisableSequence = true;

        /// <summary>
        /// The name of the sequence to mark complete.  Unset means current sequence.
        /// </summary>
        [JsonProperty("Sequence")]
        [ProtoMember(4)]
        public string SequenceName;

        /// <summary>
        /// Should we uncomplete instead?
        /// </summary>
        [JsonProperty("Uncomplete")]
        [ProtoMember(5)]
        public bool Uncomplete;

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        #endregion

        #region Public Methods

        public override string GetDebugName()
        {
            var result = Uncomplete ? "Uncomplete " : "Complete ";
            if (string.IsNullOrEmpty(SequenceName))
            {
                result += "this sequence";
            }
            else
            {
                result += "'" + SequenceName + "'";
            }
            if (!Uncomplete && DisableSequence)
            {
                result += " and disable it";
            }
            return result;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            ScriptedSequence sequence;
            if (string.IsNullOrEmpty(SequenceName))
            {
                sequence = ScriptedSequence;
            }
            else
            {
                sequence = _ssController.GetSequenceByName(SequenceName);
                if (sequence == null)
                {
                    return new SimpleAsyncToken(new Exception("Sequence not found: " + SequenceName));
                }
            }
            if (Uncomplete)
            {
                _ssController.UncompleteSequence(sequence);
            }
            else
            {
                _logger.Debug(null, "Forcing Completion of sequence {0}", sequence.Name);
                sequence.ForceCompletion(DisableSequence);
            }
            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

