using System;
using System.Linq;
using System.Collections.Generic;

using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSelectSquad : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The squad to select
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SquadToSelect")]
        [ProtoMember(3)]
        public SquadDesignator SquadToSelect = new SquadDesignator();
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            // get the squad
            Squad squad = SquadToSelect.GetSquad();
            
            if (squad == null)
            {
                WCMApplicationDirector.Instance.PlayerInput.SelectedGameItem = null;
            }
            else

            {

                WCMApplicationDirector.Instance.PlayerInput.SelectedGameItem = squad.GetFirstLivingUnit();

            }
            
            //_logger.Error(":::: Selected Game Item = " + WCMApplicationDirector.Instance.PlayerInput.SelectedGameItem);
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

