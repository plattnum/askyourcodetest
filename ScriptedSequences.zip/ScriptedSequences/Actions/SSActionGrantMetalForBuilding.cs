using GameTypes;
using GameTypes.GameDefinitions;
using Kixeye.Common;
using Kixeye.WCM.ui;
using Ninject;
using ProtoBuf;
using System;
using System.Collections.Generic;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Grant metal to the player to build a new building.
    /// </summary>
    [Serializable]
    public class SSActionGrantMetalForBuilding : ScriptedSequenceAction
    {

        /// <summary>
        /// The game's ui controller
        /// </summary>
        [Inject]
        public UIController UI { private get; set; }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            // Find out what building is selected in the panel
            PanelBase currentPanel = UI.CurrentPanel;

            if (currentPanel is SSUI_Building_Construction)
            {
                SSUI_Building_Construction buildingSSUI = (SSUI_Building_Construction)currentPanel;

                BuildingType buildingType = buildingSSUI.Panel.SelectedBuildingType;

                var gameData = WCMApplicationDirector.Instance.GameData;

                IList<BaseGameDefinition<string>> definitions = new List<BaseGameDefinition<string>>();

                BuildingDefinition definition = gameData.GetBuildingDefinition(buildingType, 1);

                definitions.Add(definition);
                WCMApplicationDirector.Instance.PlayerProcessor.GrantMetalForGameDefinitions(definitions);
            }
            else
            {
                return new SimpleAsyncToken(new Exception("Invalid current Panel recevied: " + currentPanel));
            }
            
            return new SimpleAsyncToken(true);
        }

    }
}

