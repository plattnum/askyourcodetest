using System;
using I2.Loc;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Ninject;
using UnityEngine;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetBaseInfoLabels : ScriptedSequenceAction
    {
        #region Private Fields

        public const int NUM_ENTRIES = 2;

        /// <summary>
        /// Backing variable for StringKey
        /// </summary>
        private string[] _stringKey = new string[NUM_ENTRIES];

        #endregion

        #region Public Fields

        /// <summary>
        /// If the NPC Dialog overlay should be enabled or not.
        /// </summary>
        [JsonProperty("Show")]
        [ProtoMember(3,OverwriteList = true)]
        public bool[] Show = new bool[NUM_ENTRIES];


        /// <summary>
        /// The dialog message key. Because we are serializing it with protobufs,
        /// the array cannot contain null, so we fill empy spots with ""
        /// </summary>
        [Newtonsoft.Json.JsonProperty("StringKey")]
        [ProtoMember(4,OverwriteList = true)]
        public string[] StringKey
        {
            get
            {
                for(int i = 0; i < NUM_ENTRIES; i++)
                {
                    if(_stringKey[i] == null)
                    {
                        _stringKey[i] = string.Empty;
                    }
                }
                return _stringKey;
            }
            set
            {
                for(int i = 0; i < NUM_ENTRIES; i++)
                {
                    if(value == null || value.Length <= i)
                    {
                        _stringKey[i] = string.Empty;
                    }
                    else
                    {
                        _stringKey[i] = value[i];
                    }
                }
            }
        }

        #endregion

    
        #region Public methods


        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            BattleHUD battleHUD = WCMApplicationDirector.Instance.UI.CurrentHUD as BattleHUD;
            if (battleHUD != null)
            {
                string[] text = new string[NUM_ENTRIES];
                for (int i =0; i < NUM_ENTRIES; ++i)
                {
                    if (Show[i])
                    {
                        text[i] = LocalizationManager.GetTermTranslation(StringKey[i]);
                    }
                    else
                    {
                        text[i] = "";
                    }
                }

                Kixeye.Core.Logging.Log.Error(this, "UI 2.0 Does not have Info Labels on the Battle HUD!");
                //battleHUD.SetBaseInfoLabels(text);
            }
            else
            {
                return new SimpleAsyncToken( new Exception("Could not set Battle HUD info text because the battle HUD isn't visible."));
            }

            return new SimpleAsyncToken(true);
        }
        #endregion
    }
}

