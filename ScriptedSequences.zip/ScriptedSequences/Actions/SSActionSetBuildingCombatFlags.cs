using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetBuildingCombatFlags : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The squad to modify the combat flags for.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BuildingToModify")]
        [ProtoMember(3)]
        public BuildingDesignator BuildingToModify = new BuildingDesignator();
        
        /// <summary>
        /// If true, the game item cannot be selected and targeted by AI or players.  Does not affect how the item takes damage.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnTargetable")]
        [ProtoMember(4)]
        public bool UnTargetable = false;
        
        /// <summary>
        /// If true, won't take any damage.  Does not affect the ability to target it.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnDamageable")]
        [ProtoMember(5)]
        public bool UnDamageable = false;
        
        /// <summary>
        /// If true, the game item won't be killed or stop functioning if its health reaches zero.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnKillable")]
        [ProtoMember(6)]
        public bool UnKillable = false;
        
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            foreach (Building building in BuildingToModify.GetBuildings())
            {
                building.IsUndamageable = UnDamageable;
                building.IsUnkillable = UnKillable;
                building.IsUntargetable = UnTargetable;
//                Log.Error(this, building.GetName() + " UnDamageable " + building.IsUndamageable);
//                Log.Error(this, building.GetName() + " UnKillable " + building.IsUnkillable);
//                Log.Error(this, building.GetName() + " UnTargetable " + building.IsUntargetable);
            }
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

