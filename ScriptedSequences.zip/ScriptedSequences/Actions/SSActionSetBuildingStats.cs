using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using System.Collections.Generic;
using GameTypes.BattleEvents;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Sets certain stats of a designated building.
    /// </summary>
    [Serializable]
    public class SSActionSetBuildingStats : ScriptedSequenceAction
    {
        /// <summary>
        /// Designates the building which should be modified.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(3)]
        public BuildingDesignator Designator
        {
            get { return _building; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _building = new BuildingDesignator();

        /// <summary>
        /// The flags determining which stats to set.
        /// </summary>
        [JsonProperty("Flags")]
        [JsonConverter(typeof(FlagEnumConverter))]
        [ProtoMember(4)]
        public BuildingStatFlags Flags; 
        
        /// <summary>
        /// The new health value.
        /// </summary>
        [JsonProperty("Health")]
        [ProtoMember(5)]
        public int Health;
        
        /// <summary>
        /// The new stored metal value.
        /// </summary>
        [JsonProperty("StoredMetal")]
        [ProtoMember(6)]
        public int StoredMetal;
        
        /// <summary>
        /// The new stored oil value.
        /// </summary>
        [JsonProperty("StoredOil")]
        [ProtoMember(7)]
        public int StoredOil;
        
        /// <summary>
        /// The new stored thorium value.
        /// </summary>
        [JsonProperty("StoredThorium")]
        [ProtoMember(8)]
        public int StoredThorium;

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            int numFound = 0;
            if (Designator == null)
            {
                LogError("No Building Designator");
                return new SimpleAsyncToken(false);
            }

            IEnumerable<Building> buildingList = Designator.GetBuildings();
            if (buildingList == null)
            {
                LogError("GetBuildings returned NULL");
                return new SimpleAsyncToken(false);
            }
            foreach(Building building in buildingList)
            {
                if (building == null)
                {
                    continue;
                }

                numFound++;

                if (building.IsDead)
                {
                    // If a building is dead, we still want to count it as found,
                    // but then don't actually modify its stats
                    continue;
                }

                if ((Flags & BuildingStatFlags.Health) == BuildingStatFlags.Health)
                {
                    if (Health < building.Health)
                    {
                        building.TakeDamage(building.Health - Health, null, null, 1.0f, null);
                    }
                    else
                    {
                        building.Health = Health;
                    }
                }

                /* TODO: [Processor] Replace this with a cheat instruction sent to the processor.
                if ((Flags & BuildingStatFlags.StoredMetal) == BuildingStatFlags.StoredMetal)
                {
                    building.StoredMetal = StoredMetal;
                }

                if ((Flags & BuildingStatFlags.StoredOil) == BuildingStatFlags.StoredOil)
                {
                    building.StoredOil = StoredOil;
                }

                if ((Flags & BuildingStatFlags.StoredThorium) == BuildingStatFlags.StoredThorium)
                {
                    building.StoredThorium = StoredThorium;
                }
                */
            }

            if (numFound == 0)
            {
                string msg;
                if (Designator.Method == BuildingDesignator.DesignationMethod.ByTag)
                {
                    msg = string.Format("with the tag [{0}]", Designator.Tag);
                }
                else
                {
                    msg = string.Format("of type [{0}]", Designator.Type.ToString());
                }
                LogDebug("Failed to find any buildings: {0}", msg);
            }

            return new SimpleAsyncToken(true);
        }
    }
}

