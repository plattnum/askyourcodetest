﻿using System;
using ProtoBuf;
using Kixeye.Core.Logging;
using Kixeye.Common;
using Ninject;


namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionToggleCameraRotation : ScriptedSequenceAction
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("Toggle Camera Rotation")]
        [ProtoMember(3)]
        public bool EnableCameraRotation;

        #endregion

        public override ISimpleAsyncToken Act()
        {
            if (EnableCameraRotation)
            {
                UIController.IsCameraRotationDisabledByNux = false;
            }
            else
            {
                UIController.IsCameraRotationDisabledByNux = true;
            }
            return new SimpleAsyncToken(true);
        }
    }
}
