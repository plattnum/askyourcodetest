﻿using System;
using System.Collections;
using System.Collections.Generic;
using Kixeye.Common;
using Kixeye.WCM.Events;
using Newtonsoft.Json;
using Ninject;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSendFirebaseEvent : ScriptedSequenceAction
    {
        public enum FirebaseEvent
        {
            StartTutorial = 0,
            
            EndTutorial
        }

        [JsonProperty("Event")]
        [ProtoMember(3)]
        public FirebaseEvent Event;
        
        [Inject]
        public EventManager EventManager { get; set; }
        
        public override ISimpleAsyncToken Act()
        {
            switch (Event)
            {
                case FirebaseEvent.StartTutorial:
                    EventManager.HandleEvent(StartTutorialEvent.GetInstance());
                    break;
                
                case FirebaseEvent.EndTutorial:
                    EventManager.HandleEvent(EndTutorialEvent.GetInstance());
                    break;
            }
            
            return new SimpleAsyncToken(true);
        }
    }
}


