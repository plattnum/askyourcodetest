using System;
using Kixeye.Common;
using ProtoBuf;
using UnityEngine;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSpawnFX : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The prefab FX GameObject to spawn from.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("FXObject")]
        [ProtoMember(3)]
        public PrefabReference FXObject = new PrefabReference();
            
        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's data manager.
        /// </summary>
        [Inject]
        private DataManager _dataManager
        {
            get;
            set;
        }
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            SimpleAsyncToken returnToken = new SimpleAsyncToken();
            if (FXObject == null)
            {
                return new SimpleAsyncToken( new Exception("No FX object prefab set") );
            }
            
            if (_dataManager == null)
            {
                return new SimpleAsyncToken( new Exception("No DataManager set") );
            }
            
            FXObject.Load(_dataManager).ReadyUnity( response => 
            {
                if (!response.Success)
                {
                    returnToken.Fail(response.Error);
                }
                else
                {
                    GameObject prefab = response.Value;
                    if (prefab == null)
                    {
                        returnToken.Fail( new Exception("Could not load prefab.") );
                    }
    
                    GameObject newFX = GameObject.Instantiate( prefab, FXObject.LocalPosition.ToVector(), Quaternion.Euler(FXObject.LocalRotation.ToVector()) ) as GameObject;
                    if (newFX == null)
                    {
                        returnToken.Fail(new Exception("Could not instantiate new game object.") );
                    }
                    else
                    {
                        newFX.SetActive(true);
                        returnToken.Succeed();
                    }
                }
            });
            
            return returnToken;
        }
        #endregion    
    }
}

