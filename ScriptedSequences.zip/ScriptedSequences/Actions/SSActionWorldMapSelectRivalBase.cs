﻿using System;
using GameTypes;
using Kixeye.Common.StateMachine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.WCM.WorldMap;
using Ninject;
using ProtoBuf;


namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionWorldMapSelectRivalBase : ScriptedSequenceAction
    {

        #region public Properties
        
        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        public WCMGameStateController GameStates
        {
            get;
            private set;
        }
        
        /// <summary>
        /// The application player manager.
        /// </summary>
        [Inject]
        private PlayerManager _playerManager { get ; set; }

        #endregion
        
        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}
