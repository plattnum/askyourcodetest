using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;
using Ninject;
using Kixeye.WCM.Input;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDisableSelectionExcept : ScriptedSequenceAction
    {
        public enum SelectLockType
        {
            SquadException,
            BuildingException,
            FreeSelection,
        }

        #region Serialized properties

        /// <summary>
        /// The squad to restrict selection to.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadException")]
        [ProtoMember(3)]
        public SquadDesignator SquadException = new SquadDesignator { PlayerOwningSquad = SquadDesignator.PlayerOwner.Local };

        /// <summary>
        /// The building to restrict selection to.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BuildingException")]
        [ProtoMember(4)]
        public BuildingDesignator BuildingException = new BuildingDesignator();
        
        /// <summary>
        /// Whether we're locking all but a squad, building or freeing the selection.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfSelectionOperation")]
        [ProtoMember(5)]
        public SelectLockType TypeOfSelectionOperation;

        #endregion

        #region private variables
        
        /// <summary>
        /// The application's Input controller.
        /// </summary>
        [Inject]
        private PlayerInput _input
        {
            get;
            set;
        }
        
        #endregion        

        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            _input.ClearGameItemSelectionExceptions();
            if (TypeOfSelectionOperation == SelectLockType.FreeSelection)
            {
                _input.SelectionLocked = false;
            }
            else if (TypeOfSelectionOperation == SelectLockType.SquadException)
            {
                _input.SelectionLocked = true;

                Player thePlayer;
                Platoon platoon;
                Squad squad = SquadException.GetSquad(out thePlayer, out platoon);
                
                if (squad == null)
                {
                    return new SimpleAsyncToken( new Exception("Cannot find squad to restrict selection to"));
                }
                else
                {
                    for(int i=0, count=squad.Count; i<count; ++i)
                    {
                        _input.AddItemToSelectionExceptions(squad.Units[i]);
                    }
                }
            }
            else if (TypeOfSelectionOperation == SelectLockType.BuildingException)
            {
                _input.SelectionLocked = true;
                foreach(Building building in BuildingException.GetBuildings())
                {
                    if (building == null)
                    {
                        continue;
                    }
                    _input.AddItemToSelectionExceptions(building);                    
                }
            }
            else
            {
                return new SimpleAsyncToken(new Exception("Unrecognized select lock type"));
            }

            return new SimpleAsyncToken(true);
        }

        #endregion    
    }
}

