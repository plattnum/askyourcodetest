using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionOrderSquadAttack : ScriptedSequenceAction
    {
        public enum TargetType
        {
            Squad,
            Building,
        }
        
        #region Serialized properties

        /// <summary>
        /// The squad to spawn to order to move.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToOrder")]
        [ProtoMember(3)]
        public SquadDesignator SquadToOrder = new SquadDesignator();

        /// <summary>
        /// The type of target to attack (building or squad).
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfTarget")]
        [ProtoMember(4)]
        public TargetType TypeOfTarget;
        
        /// <summary>
        /// The squad to attack.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TargetSquad")]
        [ProtoMember(5)]
        public SquadDesignator TargetSquad = new SquadDesignator();
        
        /// <summary>
        /// The building to attack.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TargetBuilding")]
        [ProtoMember(6)]
        public BuildingDesignator TargetBuilding = new BuildingDesignator();
        
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Squad squad = SquadToOrder.GetSquad();

            if (squad == null)
            {
                return new SimpleAsyncToken( new ApplicationException("Cannot find squad for attack order."));
            }
            if (squad.IsDeployed == false)
            {
                return new SimpleAsyncToken( new ApplicationException("Squad cannot be ordered to attack because it hasn't been deployed.") );
            }
            if (squad.IsDead || squad.IsEmpty)
            {
                return new SimpleAsyncToken( new ApplicationException("Squad cannot be ordered to attack because it has no living units.") );
            }
            
            GameItem target = null;
            if (TypeOfTarget == TargetType.Squad)
            {
                Squad targetSquad;
                if (TargetSquad.TypeOfPlatoon != SquadDesignator.PlatoonSearchType.NearestViableSquad)
                {
                    targetSquad = TargetSquad.GetSquad();
                }
                else
                {
                    targetSquad = TargetSquad.GetNearestSquadToPosition(squad.Position);
                }

                if (targetSquad == null)
                {
                    return new SimpleAsyncToken( new ApplicationException("Attack order cannot find target squad.") );
                }
                
                target = targetSquad.GetFirstLivingUnit();
            }
            else if (TypeOfTarget == TargetType.Building)
            {
                target = TargetBuilding.GetBuilding();
                if (target == null)
                {
                    return new SimpleAsyncToken( new ApplicationException("Attack order cannot find target building.") );
                }
            }
            squad.Brain.Attack(target);
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

