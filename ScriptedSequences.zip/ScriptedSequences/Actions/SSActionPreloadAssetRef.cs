﻿using System;
using GameTypes;
using Kixeye.WCM.Actor;
using Kixeye.Common;
using Kixeye.WCM.GameData;
using ProtoBuf;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPreloadAssetRef : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The asset ref to preload
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("AssetRef")]
        [ProtoMember(3)]
        public AssetRef AssetRef;

        [Newtonsoft.Json.JsonProperty("WaitForLoad")]
        [ProtoMember(4)]
        public bool WaitForLoad;

        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's actor manager.
        /// </summary>
        [Inject]
        private WCMDataManager DataManager { get; set; }
        
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (AssetRef == null)
            {
                throw new ApplicationException("AssetRef is Null!");
            }

            var token = DataManager.Preload(AssetRef);
            if(WaitForLoad)
            {
                return token;
            }
            else
            {
                return new SimpleAsyncToken(true);
            }
        }
        
        #endregion    
        
    }
}
