﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kixeye.Common;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionReloadPlayerData : ScriptedSequenceAction
    {
        [Inject]
        private ScriptedSequencesController ScriptedSequences { get; set; }

        [Inject]
        private WCMGameStateController GameStates { get; set; }

        public override ISimpleAsyncToken Act()
        {
            ScriptedSequences.PlayerReloadTriggeredBySequence = true;
            var reloadToken = GameStates.ReloadLocalPlayerData();

            // insulate reload token from caller.
            var ret = new SimpleAsyncToken();
            reloadToken.Ready(_ =>
            {
                ScriptedSequences.PlayerReloadTriggeredBySequence = false;
                ret.Set(reloadToken);
            });
            return ret;
        }
    }
}
