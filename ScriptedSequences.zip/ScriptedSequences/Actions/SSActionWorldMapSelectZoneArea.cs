﻿using System;
using GameTypes;
using Kixeye.Common.StateMachine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.WCM.WorldMap;
using Ninject;
using ProtoBuf;


namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionWorldMapSelectZoneArea : ScriptedSequenceAction
    {

        #region Serialized properties
        
        /// <summary>
        /// The Zone Area Definition ID that the camera will center on
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ZoneAreaDefinitionId")]
        [ProtoMember(3)]
        public string ZoneAreaDefinitionId;
        
        #endregion

        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            WorldMapState currentState = WCMApplicationDirector.Instance.GameStates.CurrentState as WorldMapState;
            if (currentState != null) 
            {
                var controller = currentState.Controller;
                if (controller == null) {
                    return new SimpleAsyncToken (new Exception ("Could not get world map controller."));    
                }

                controller.InitialZoneArea = ZoneAreaDefinitionId;
            }

            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}
