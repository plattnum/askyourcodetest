using System;
using System.Collections.Generic;
using System.Linq;
using Kixeye.Common;
using UnityEngine;
using Newtonsoft.Json;
using System.Text;
using Kixeye.Core.Logging;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetUIElementAnimationState : ScriptedSequenceAction
    {
        [JsonProperty("ElementDesignator")]
        [ProtoMember(3)]
        public UIElementDesignator ElementDesignator = null;

        [JsonProperty("EnableAnimator")]
        [ProtoMember(4)]
        public bool EnableAnimator = true;

        [JsonProperty("BoolParameterName")]
        [ProtoMember(5)]
        public string BoolParameterName = null;

        [JsonProperty("BoolParameterValue")]
        [ProtoMember(6)]
        public bool BoolParameterValue = true;

        [JsonProperty("TriggerParameterName")]
        [ProtoMember(7)]
        public string TriggerParameterName = null;

        [JsonProperty("AnimationName")]
        [ProtoMember(8)]
        public string AnimationName = null;

        [Inject]
        private ScaledTimeScheduler ScaledTimeScheduler { get; set; }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            GameObject uiElement = ElementDesignator.GetUIElement();
            if (uiElement == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find the following UI Element:" + ElementDesignator.GetDescription()));
            }

            Animator[] animatorComponents = uiElement.GetComponentsInParent<Animator>(includeInactive: true);
            if (animatorComponents.Length == 0)
            {
                return new SimpleAsyncToken(new Exception("No animators found for designator: " + ElementDesignator.GetDescription()));
            }

            // Filter potential animators by what trigger/animation we want.
            // Doing this allows ui designers to place animators higher in the
            // hierarchy than the tagged element, often needed for glows.
            List<Animator> matchingAnimators = new List<Animator>(1);
            for (int i = 0; i < animatorComponents.Length; ++i)
            {
                var potentialAnimatorComponent = animatorComponents[i];
                if (!string.IsNullOrEmpty(BoolParameterName))
                {
                    if (potentialAnimatorComponent.parameters.All(_ =>
                        _.type != AnimatorControllerParameterType.Bool ||
                        _.name != BoolParameterName))
                    {
                        continue;
                    }
                }
                if (!string.IsNullOrEmpty(TriggerParameterName))
                {
                    if (potentialAnimatorComponent.parameters.All(_ =>
                        _.type != AnimatorControllerParameterType.Trigger ||
                        _.name != TriggerParameterName))
                    {
                        continue;
                    }
                }
                if (!string.IsNullOrEmpty(AnimationName))
                {
                    if (!potentialAnimatorComponent.HasState(0, Animator.StringToHash(AnimationName)))
                    {
                        continue;
                    }
                }
                matchingAnimators.Add(potentialAnimatorComponent);
            }

            if (matchingAnimators.Count == 0)
            {
                return new SimpleAsyncToken(new Exception(GetAmbiguousMatchMessage("No animator with matching trigger or animation found", animatorComponents)));
            }

            if (matchingAnimators.Count > 1 &&
                matchingAnimators[0].gameObject != uiElement.gameObject)
            {
                return new SimpleAsyncToken(new Exception(GetAmbiguousMatchMessage("Multiple animators with matching trigger or animation found", matchingAnimators.ToArray())));
            }

            Animator animatorComponent = matchingAnimators[0];

            if (!EnableAnimator)
            {
                // For explicitly-started animations, we wait for them to end
                // before disabling the animator.  If there are triggers there
                // is usually no need to disable the animator anyway.
                if (!string.IsNullOrEmpty(AnimationName))
                {
                    // Always check to make sure the animation you intend to stop is the one actually playing, we may have started another.
                    var currentAnimatorStateInfo = animatorComponent.GetCurrentAnimatorStateInfo(0);
                    if (currentAnimatorStateInfo.IsName(AnimationName))
                    {
                        var progress = currentAnimatorStateInfo.normalizedTime;
                        // progress doesn't reset to zero after reaching one at the end of a loop, it keeps counting up.
                        progress = progress - Mathf.Floor(progress);
                        if (progress < 1)
                        {
                            ScaledTimeScheduler.PushCallback((1 - progress) * currentAnimatorStateInfo.length, () =>
                            {
                                // Always check to make sure the animation you intend to stop is the one actually playing, we may have started another.
                                currentAnimatorStateInfo = animatorComponent.GetCurrentAnimatorStateInfo(0);
                                if (currentAnimatorStateInfo.IsName(AnimationName))
                                {
                                    animatorComponent.enabled = false;
                                }
                            });
                        }
                        else
                        {
                            animatorComponent.enabled = false;
                        }
                    }
                }
                else
                {
                    animatorComponent.enabled = false;
                }
            }
            else
            {
                if (!animatorComponent.enabled)
                {
                    // Enable animator only if it is disabled
                    animatorComponent.enabled = true;
                }

                if (!string.IsNullOrEmpty(BoolParameterName))
                {
                    animatorComponent.SetBool(BoolParameterName, BoolParameterValue);
                }

                if (!string.IsNullOrEmpty(TriggerParameterName))
                {
                    animatorComponent.SetTrigger(TriggerParameterName);
                }

                if (!string.IsNullOrEmpty(AnimationName))
                {
                    animatorComponent.HasState(0, Animator.StringToHash(AnimationName));
                    animatorComponent.Play(AnimationName, 0);
                }
            }

            return new SimpleAsyncToken(true);
        }

        private string GetAmbiguousMatchMessage(string problem, params Animator[] animatorComponents)
        {
            return "{0}: {1} => {2}".FormatWith(
                problem,
                ElementDesignator.GetDescription(),
                animatorComponents.Select(_ => _.name).Join());
        }
    }
}
