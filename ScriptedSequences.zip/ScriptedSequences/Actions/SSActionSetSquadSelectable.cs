using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetSquadSelectable : ScriptedSequenceAction
    {
        #region Serialized properties

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToChange")]
        [ProtoMember(3)]
        public SquadDesignator SquadToChange = new SquadDesignator { PlayerOwningSquad = SquadDesignator.PlayerOwner.Local };

        /// <summary>
        /// Whether the squad can be selected.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Selectable")]
        [ProtoMember(4)]
        public bool Selectable;

        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Player thePlayer;
            Platoon platoon;
            Squad squad = SquadToChange.GetSquad(out thePlayer, out platoon);

            if (squad == null)
            {
                Log.Error(this, "Missing squad for to set selectable on");
            }
            else
            {
                squad.Selectable = Selectable;
            }
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

