using System;
using Kixeye.Common;
using Kixeye.WCM.Events;
using Ninject;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPlayMusic : ScriptedSequenceAction
    {
        /// <summary>
        /// The applicaton's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events
        {
            get;
            set;
        }

        /// <summary>
        /// The application's audio manager
        /// </summary>
        [Inject]
        private IGameAudio _audio
        {
            get;
            set;
        }

        /// <summary>
        /// What type of music to play.
        /// </summary>
        [JsonProperty("Type")]
        [ProtoMember(3)]
        public MusicEvent.MusicEventType Type;

        /// <summary>
        /// What to do with the music.
        /// </summary>
        [JsonProperty("Action")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(4)]
        public MusicEvent.MusicEventAction Action;


        public SSActionPlayMusic ()
        {
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            SimpleAsyncToken token = new SimpleAsyncToken();
            if(_audio == null)
            {
                token.Fail(new Exception("Failed to inject Game Audio to SSActionPlayMusic."));
            }
            else
            {
                _audio.Initialize().AddDependent(token).ReadyUnity( audioResult =>
                {
                    if(_events == null)
                    {
                        token.Fail(new Exception("Failed to inject events manager to SSActionPlayMusic."));
                    }
                    else
                    {
                        _events.HandleEvent(MusicEvent.GetInstance(Type, Action));
                        token.Succeed();
                    }
                });
            }

            return token;
        }


    }
}

