using System;
using System.Collections.Generic;
using System.Linq;
using Kixeye.WCM.GameData;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Selects a building. 
    /// </summary>
    [Serializable]
    public class SSActionActivateDefensiveWaves : ScriptedSequenceAction
    {
        #region Serialized properties
        /// <summary>
        /// Whether to activate or deactivate defensive waves for building.
        /// </summary>
        [JsonProperty("Enabled")]
        [ProtoMember(3)]
        public bool Enabled;
        
        /// <summary>
        /// Which building to do action for.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(4)]
        public BuildingDesignator Designator
        {
            get { return _designator; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _designator = new BuildingDesignator();

        #endregion

        #region Public methods

        public override ISimpleAsyncToken Act()
        {
            Building buildingToSelect = Designator.GetBuilding();
                
            if (buildingToSelect != null)
            {
                buildingToSelect.Platoon.DefensiveWavesEnabled = Enabled;
            }
            else
            {
                return new SimpleAsyncToken(new Exception("Could not find building"));
            }            

            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

