using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Analytics.Funnel;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Activates another node in this sequence
    /// </summary>
    [Serializable]
    public class SSActionFunnelLog : ScriptedSequenceAction
    {
        public enum FunnelSegment
        {
            Start,
            Step,
            Stop,
        };

        #region Serialized properties
        
        /// <summary>
        /// The title for this funnel
        /// </summary>
        [Newtonsoft.Json.JsonProperty("FunnelTitle")]
        [ProtoMember(3)]
        public string FunnelTitle = "";
        
        /// <summary>
        /// The text for this particular log step
        /// </summary>
        [Newtonsoft.Json.JsonProperty("LogString")]
        [ProtoMember(4)]
        public string LogString = "";

        /// <summary>
        /// The part of the funnel this is logging.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Segment")]
        [ProtoMember(5)]
        public FunnelSegment Segment;
        
        #endregion
        
        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            IFunnelLog funnelLog = WCMApplicationDirector.Instance.Analytics.GetFunnel(FunnelTitle);
            if (funnelLog == null)
            {
                return new SimpleAsyncToken( new Exception( GetDebugNameFull() + ": failed to get analytics funnel." ) );
            }

            switch (Segment)
            {
                case FunnelSegment.Start:
                {
                    funnelLog.LogStart( LogString );
                }
                break;
                case FunnelSegment.Step:
                {
                    funnelLog.LogStep( LogString );
                }
                break;
                case FunnelSegment.Stop:
                {
                    funnelLog.LogStop( LogString );
                }
                break;
            }

            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

