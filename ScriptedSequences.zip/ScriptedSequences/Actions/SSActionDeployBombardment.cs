﻿using System;
using System.Collections.Generic;
using GameTypes;
using Kixeye.Common;
using Kixeye.Common.StateMachine;
using Kixeye.WCM.AI;
using Kixeye.WCM.GameState;
using Ninject;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDeployBombardment : ScriptedSequenceAction
    {
        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        public WCMGameStateController GameStates
        {
            get;
            private set;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            AttackData attackData = null;
            IState currentState = GameStates.CurrentState;
            if (currentState is AttackingState)
            {
                attackData = (currentState as AttackingState).AttackData;
            }

            if (attackData == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find AttackData to get opponent.  Is the game in an attack or defend state?"));
            }

            var baseBounds = new Bounds();
            foreach (var building in attackData.AttackTargetData.DefendingPlayer.ActiveBase.Buildings)
            {
                baseBounds.Encapsulate(building.Bounds);
            }

            Squad bombardmentSquad = null;
            foreach (var squad in attackData.ArtilleryPlatoon.Squads)
            {
                if (squad.UnitId == UnitTypeConstant.Bombardment)
                {
                    bombardmentSquad = squad;
                    break;
                }
            }

            if (bombardmentSquad == null)
            {
                return new SimpleAsyncToken(new Exception("Could not find bombardment squad"));
            }

            int roundsFired = bombardmentSquad.Brain.ClipSize * bombardmentSquad.LivingUnitCount;
            float targetRadius = Math.Min(baseBounds.size.x, baseBounds.size.z) * 0.5f;
            var targetPositions = new List<PositionData>();
            for (int i = 0; i < roundsFired; i++)
            {
                var position = baseBounds.center + (UnityEngine.Random.insideUnitCircle * targetRadius).x0y();
                targetPositions.Add(position.ToPositionData());
            }
            
            var gameData = WCMApplicationDirector.Instance.GameData;
            ArtilleryBrain.Attack(bombardmentSquad, targetPositions, gameData);

            return new SimpleAsyncToken(true);
        }
    }
}


