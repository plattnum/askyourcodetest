using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using UnityEngine;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionLetterbox : ScriptedSequenceAction
    {
        #region Private Fields

        /// <summary>
        /// The name of the prefab to load.
        /// </summary>
        private const string PREFAB_NAME_LETTERBOX = "Letterbox";

        /// <summary>
        /// The currently spawned letterbox instance.
        /// </summary>
        private static LetterboxWidget _letterboxInstance;

        /// <summary>
        /// The token to the current squint animation.
        /// </summary>
        private SimpleAsyncToken _pendingToken;

        #endregion

        #region Public Fields

        /// <summary>
        /// If this action enables or disables the letterbox.
        /// </summary>
        [JsonProperty("Enabled")]
        [ProtoMember(3)]
        public bool Enabled;
        
        /// <summary>
        /// If true then action won't complete until the letterbox has finished moving in or out.
        /// </summary>
        [JsonProperty("WaitForFinish")]
        [ProtoMember(4)]
        public bool WaitForFinish;

        #endregion

        #region Public Methods

        /// <summary>
        /// Returns the instance of the letterbox object shared by the letterbox actions.
        /// </summary>
        public static LetterboxWidget GetLetterboxWidget()
        {
            return _letterboxInstance;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if (_pendingToken != null)
            {
                //Cancel the old token.
                _pendingToken.ClearCallbacks();
                _pendingToken = null;
            }

            if (_letterboxInstance == null)
            {
                //No letterbox object created, create it now
                GameObject prefab = ScriptedSequencesController.LoadPrefab(PREFAB_NAME_LETTERBOX);
                if (prefab == null)
                {
                    // Failed to load the prefab
                    return new SimpleAsyncToken(new System.Exception("Could not load letterbox prefab"));
                }
                
                Exception exception;
                _letterboxInstance = ScriptedSequencesController.SpawnComponentAndAttachToUICanvas<LetterboxWidget>(prefab, out exception);
                if (_letterboxInstance == null || exception != null)
                {
                    return new SimpleAsyncToken(exception);
                }
            }

            _letterboxInstance.Squint(Enabled ? 1f : 0f);
            if (WaitForFinish)
            {
                _letterboxInstance.SquintFinished += HandleSquintFinished;
                _pendingToken = new SimpleAsyncToken();
                return _pendingToken;
            }
            else
            {
                return new SimpleAsyncToken(true);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Succeeds the pending token when the squinting is finished.
        /// </summary>
        /// <param name="sender">Sender.</param>
        private void HandleSquintFinished(LetterboxWidget sender)
        {
            sender.SquintFinished -= HandleSquintFinished;
            if (!Enabled)
            {
                // This action is removing the letterbox; now that the animation is finished, hide it entirely
                sender.gameObject.SetActive(false);
            }
            if (_pendingToken != null)
            {
                _pendingToken.Succeed();
            }
        }
            
        #endregion
    }
}

