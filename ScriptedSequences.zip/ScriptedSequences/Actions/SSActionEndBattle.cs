﻿using System;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionEndBattle : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// Whether the battle should be ended with a win or a loss.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Win")]
        [ProtoMember(3)]
        public bool Win;
        
        
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (Win)
            {
                // complete the mission by destroying all enemy buildings
                var opponentBase = WCMApplicationDirector.Instance.Players.OpponentPlayer.ActiveBase;
                if (!opponentBase.IsDead)
                {
                    foreach (Building building in WCMApplicationDirector.Instance.Players.OpponentPlayer.ActiveBase.Buildings)
                    {
                        if (building != null && !building.IsUndamageable && !building.IsUnkillable)
                        {
                            building.Die();
                        }
                    }
                }
            }

            WCMApplicationDirector.Instance.Battle.PostEndEvent(attackingPlayerWon: Win);

            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

