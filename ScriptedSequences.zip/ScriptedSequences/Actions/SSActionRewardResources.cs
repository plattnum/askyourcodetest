using System;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using Model;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Rewards resources and various other things to the player.
    /// </summary>
    [Serializable]
    public class SSActionRewardResources : ScriptedSequenceAction
    {
        /// <summary>
        /// The ammount of metal to award the player.
        /// </summary>
        [JsonProperty("Metal")]
        [ProtoMember(3)]
        public int Metal;

        /// <summary>
        /// The ammount of oil to award the player.
        /// </summary>
        [JsonProperty("Oil")]
        [ProtoMember(4)]
        public int Oil;

        /// <summary>
        /// The ammount of thorium to award the player.
        /// </summary>
        [JsonProperty("Thorium")]
        [ProtoMember(5)]
        public int Thorium;

        /// <summary>
        /// The ammount of medals to award the player. 
        /// Ooh! Shiny!
        /// </summary>
        [JsonProperty("Medals")]
        [ProtoMember(6)]
        public int Medals;

        /// <summary>
        /// The reason we are rewarding. This determines experience granted. NoReason will grant no experience.
        /// </summary>
        [JsonProperty("Reason")]
        [ProtoMember(7)]
        public ResourceBasedReward.ReasonForReward Reason = ResourceBasedReward.ReasonForReward.NoReason;

        /// <summary>
        /// Describes the reason for granting resources.
        /// </summary>
        [JsonProperty("ReasonDescription")]
        [ProtoMember(8)]
        public string ReasonDescription = "Scripted Sequence";

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;

            if(localPlayer == null)
            {
                return new SimpleAsyncToken(new Exception("Cannot give local player a reward, local player is null."));
            }

            localPlayer.Resources.GainReward(Metal, Oil, Thorium, ReasonDescription);

            return new SimpleAsyncToken(true);
        }

    }
}

