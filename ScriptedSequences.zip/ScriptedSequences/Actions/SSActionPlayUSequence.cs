﻿using System;
using GameTypes;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using UnityEngine;
using WellFired;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPlayUSequence : ScriptedSequenceAction
    {
        /// <summary>
        /// Bool for whether to wait for timeline end, or interupt during timeline
        /// </summary>
        [Newtonsoft.Json.JsonProperty("WaitForEnd")] 
        [ProtoMember(1)] 
        public bool WaitForEnd;

        /// <summary>
        /// Int for which sequence to play in the level prefab
        /// </summary>
        [Newtonsoft.Json.JsonProperty("SequenceToPlay")]
        [ProtoMember(2)]
        public int SequenceToPlay;

        /// <summary>
        /// The sequence for this event
        /// </summary>
        private USSequencer _sequence = null;

        /// <summary>
        /// Shadow Caster camera
        /// </summary>
        private WCMCameraController camera;

        /// <summary>
        /// Used to store the token that is return from Act if the action should wait for the interpolate to end.
        /// </summary>
        SimpleAsyncToken _interpolateEndToken = null;
        
        public override ISimpleAsyncToken Act()
        {
            Level currentLevel = WCMApplicationDirector.Instance.SpawnManager.CurrentLevel;          

            if (currentLevel == null)
            {
                return new SimpleAsyncToken(new Exception("Failed to find a level in the scene"));
            }

            if (currentLevel.Sequences.Length == 0 || SequenceToPlay > currentLevel.Sequences.Length || SequenceToPlay < 0)
            {
                return new SimpleAsyncToken(new Exception("Failed to find a Sequence in the Level Prefab at index " + SequenceToPlay));
            }

            camera = WCMApplicationDirector.Instance.Camera;
            if (camera == null)
            {
                return new SimpleAsyncToken(new ApplicationException("The application camera is null"));
            }

            //Turn off the camera controller so that the shadow camera will update
            camera.enabled = false;

            _sequence = currentLevel.Sequences[SequenceToPlay];
                        
            _sequence.SequenceEnded += OnSequenceEnd;

            _sequence.Play();

            _interpolateEndToken = new SimpleAsyncToken();

            if (!WaitForEnd)
            {
                _interpolateEndToken.Succeed();
            }

            _interpolateEndToken.OnClear(tok => 
            {
                if (_sequence != null &&
                    _sequence.IsPlaying)
                {
                    _sequence.Stop();
                    camera.enabled = true;
                }
            });

            return _interpolateEndToken;
        }

        /// <summary>
        /// Called when the sequence is done
        /// </summary>
        private void OnSequenceEnd()
        {
            camera.enabled = true;

            if (_interpolateEndToken != null)
            {
                _interpolateEndToken.Succeed();
            }
            if (_sequence != null)
            {
                _sequence.SequenceEnded -= OnSequenceEnd;
                _sequence.Stop();
            }
            _interpolateEndToken = null;
        }

    }
}
