﻿using System;
using System.Collections.Generic;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Ninject;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using Kixeye.WCM.Controllers;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPauseBattleClock : ScriptedSequenceAction  
    {
        public enum PauseAction
        {
            Pause,
            Resume
        }

        #region Serialized properties
        
        /// <summary>
        /// The scope of things to disable.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Action")]
        [ProtoMember(3)]
        public PauseAction Action;
        
        #endregion
        
        #region public Properties
        
        /// <summary>
        /// For finding our battle controller
        /// </summary>
        [Inject]
        public BattleController BattleController
        {
            get;
            private set;
        }
        
        #endregion
        
        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            BattleController.SetBattleClockPaused(Action == PauseAction.Pause);

            return new SimpleAsyncToken(true);
        }
        
        #endregion    
    }
}

