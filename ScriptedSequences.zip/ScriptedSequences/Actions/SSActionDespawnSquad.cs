using System;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDespawnSquad : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The squad to despawn
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToDespawn")]
        [ProtoMember(3)]
        public SquadDesignator SquadToDespawn = new SquadDesignator();
        
        /// <summary>
        /// Whether to completely destroy the squad or just remove them from the battlefield
        /// </summary>
        [Newtonsoft.Json.JsonProperty("DestroySquad")]
        [ProtoMember(4)]
        public bool DestroySquad = false;
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Player thePlayer;
            Platoon platoon;
            Squad squad = SquadToDespawn.GetSquad(out thePlayer, out platoon);

            if (squad == null)
            {
                return new SimpleAsyncToken(new Exception("Cannot find squad to despawn"));
            }
            else
            {
                squad.Recall();
                if (DestroySquad)
                {
                    squad.RemoveAllUnits();
                }
            }
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

