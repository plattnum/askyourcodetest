using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionUIInputEnable : ScriptedSequenceAction
    {
        #region private variables
        
        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }
        
        #endregion        

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            _ssController.ReEnableUI();

            return new SimpleAsyncToken(true);
        }

    }
}

