using System;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionActivateSequence : ScriptedSequenceAction
    {
        #region Serialized properties
        
        /// <summary>
        /// The name of the other sequence to activate.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SequenceName")]
        [ProtoMember(3)]
        public string SequenceName;

        /// <summary>
        /// The name of the other sequence to activate.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("WaitForSequenceToComplete")]
        [ProtoMember(4)]
        public bool WaitForSequenceToComplete;

        [Newtonsoft.Json.JsonProperty("BypassStartConditions")]
        [ProtoMember(5)]
        public bool BypassStartConditions = true;

        [Newtonsoft.Json.JsonProperty("FailIfSequenceDoesNotStart")]
        [ProtoMember(6)]
        public bool FailIfSequenceDoesNotStart = true;

        [Newtonsoft.Json.JsonProperty("LeaveEnabled")]
        [ProtoMember(7)]
        public bool LeaveEnabled;
        #endregion

        #region Private variables

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        #endregion
        
        #region Public methods

        /// <summary>
        /// The game's player manager
        /// </summary>
        [Inject]
        public PlayerManager Players { private get; set; }

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionActivateSequence));
        
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if (SequenceName == null)
            {
                return new SimpleAsyncToken( new Exception( "SequenceName is null" ) );            
            }
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("Act", "{0}: {1} sequence {2}", GetDebugNameFull(), BypassStartConditions ? "Activating" : "Enabling", SequenceName);
            }

            ScriptedSequence foundSequence = _ssController.GetSequenceByName(SequenceName);

            if ( foundSequence == null)
            {
                return new SimpleAsyncToken(new Exception("Sequence not found: " + SequenceName));
            }

            foundSequence.Reset(Players.LocalPlayer.Data.PlayerDetails, ResetReason.ManualEnable);

            SimpleAsyncToken returnToken = new SimpleAsyncToken();

            if (WaitForSequenceToComplete)
            {

                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("Act", "{0}: {1} waiting for sequence to complete: {2}", GetDebugNameFull(), BypassStartConditions ? "Activating" : "Enabling", SequenceName);
                }                
                var sequence = _ssController.GetSequenceByName(SequenceName);
                Action<int> onSequenceCompleted = null;
                onSequenceCompleted = _ =>
                {
                    sequence.SequenceCompleted -= onSequenceCompleted;
                    if (_logger.IsEnabled(LogMessageLevel.Debug))
                    {
                        _logger.Debug("Act", "{0}: sequence complete: {2} {1}", GetDebugNameFull(), LeaveEnabled ? "leaving enabled" : "", SequenceName);
                    }
                    returnToken.Succeed();
                };
                sequence.SequenceCompleted += onSequenceCompleted;
            }

            bool success;

            if (BypassStartConditions)
            {
                success = _ssController.ActivateSequenceByName(SequenceName);
            }
            else
            {
                success = _ssController.EnableSequenceByName(SequenceName, LeaveEnabled);
            }

            if (success || !FailIfSequenceDoesNotStart)
            {
                if (!WaitForSequenceToComplete)
                {
                    returnToken.Succeed();
                }
            }
            else
            {
                returnToken.Fail( new Exception( "Failed to activate sequence [" + SequenceName + "].  Is it deactivated?") );
            }

            return returnToken;
        }
        
        #endregion    
    }
}

