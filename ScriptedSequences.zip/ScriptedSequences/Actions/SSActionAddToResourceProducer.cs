﻿using System;
using GameTypes;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionAddToResourceProducer : ScriptedSequenceAction
    {
        [Newtonsoft.Json.JsonProperty("ResourceType")]
        [ProtoMember(3)]
        public ResourceType ResourceType;

        [Newtonsoft.Json.JsonProperty("Value")]
        [ProtoMember(4)]
        public long Value;

        public override ISimpleAsyncToken Act()
        {
            if (WCMApplicationDirector.Instance == null || WCMApplicationDirector.Instance.PlayerProcessor == null)
            {
                return new SimpleAsyncToken(false);
            }

            WCMApplicationDirector.Instance.PlayerProcessor.AddToResourceProducer(ResourceType, Value, "NUX_Grant");
            return new SimpleAsyncToken(true);
        }
    }
}
