using System;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.Common;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionLevelUpEnable : ScriptedSequenceAction
    {
        #region private variables

        [Newtonsoft.Json.JsonProperty("PopupEnabled")]
        [ProtoMember(3)]
        public bool PopupEnabled = false;

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }
        
        #endregion

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            _ssController.LevelUpModalBypassShowConditions = PopupEnabled;

            return new SimpleAsyncToken(true);
        }

    }
}

