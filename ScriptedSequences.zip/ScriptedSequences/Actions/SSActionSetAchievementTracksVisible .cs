using System;
using System.Collections.Generic;
using Kixeye.WCM.ui;
using Kixeye.Common;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;
using Ninject;
using System.Text;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetAchievementTracksVisible : ScriptedSequenceAction
    {
        [Inject]
        public PlayerManager PlayerManager
        {
            get;
            private set;
        }

        #region Serialized properties
        /// <summary>
        /// A dictionary that specifies for each track if should be displayed or not.
        /// </summary>
        [JsonProperty("Tracks")]
        [ProtoMember(3)]
        public Dictionary<int, bool> Tracks = new Dictionary<int,bool>();
        #endregion
        
        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            if (Tracks == null)
            {
                return new SimpleAsyncToken(new Exception("TrackIds to show/hide is a null list!"));
            }

            PlayerManager.LocalPlayer.Achievements.EnableAchievementTracks(Tracks);
            
            return new SimpleAsyncToken(true);
        }

        #endregion    
    }
}

