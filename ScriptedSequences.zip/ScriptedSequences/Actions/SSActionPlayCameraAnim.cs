﻿using System;
using System.Linq;
using Gameplay.Contracts;
using GameTypes;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using Kixeye.WCM.Events;
using Ninject;
using Ninject.Syntax;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using UnityEngine;
using WellFired;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionPlayCameraAnim : ScriptedSequenceAction
    {
        /// <summary>
        /// Clip to play on the camera
        /// </summary>
        [Newtonsoft.Json.JsonProperty("AnimationToPlay")]
        [ProtoMember(1)]
        public string AnimationToPlay;

        /// <summary>
        /// The sequence for this event
        /// </summary>
        public AnimationClip AnimClip = null;

        /// <summary>
        /// Shadow Caster camera
        /// </summary>
        private WCMCameraController _camera;

        /// <summary>
        /// Coroutine for checking animation is playing
        /// </summary>
        public Coroutine AnimWatcherCoroutine;

        /// <summary>
        /// Main Camera Animation controller
        /// </summary>
        public Animation AnimController;

        /// <summary>
        /// Used to store the token that is return from Act if the action should wait for the interpolate to end.
        /// </summary>
        SimpleAsyncToken _interpolateEndToken = null;

       
        public override ISimpleAsyncToken Act()
        {
            Level currentLevel = WCMApplicationDirector.Instance.SpawnManager.CurrentLevel;

            if (currentLevel == null)
            {
                return new SimpleAsyncToken(new Exception("Failed to find a level in the scene"));
            }

            AnimClip = currentLevel.AnimationClips.FirstOrDefault(x => x.name == AnimationToPlay);

            if (currentLevel.AnimationClips.Length == 0 || AnimClip == null || string.IsNullOrEmpty(AnimationToPlay))
            {
                return new SimpleAsyncToken(new Exception("Failed to find a Sequence in the Level Prefab" + AnimationToPlay));
            }

            AnimClip.legacy = true; //must set to legacy or the addclip will fail 

            if (AnimationToPlay == null)
            {
                return new SimpleAsyncToken(new ApplicationException("No Animation Clip Specifide"));
            }

            _camera = WCMApplicationDirector.Instance.Camera;
            if (_camera == null)
            {
                return new SimpleAsyncToken(new ApplicationException("The application camera is null"));
            }

            AnimController = _camera.GetComponent<Animation>();

            if (AnimController == null)
            {
                return new SimpleAsyncToken(new ApplicationException("The camera has no Animator"));

            }

            //Make sure it isn't set to loop
            AnimClip.wrapMode = WrapMode.Once;

            AnimController.AddClip(AnimClip, AnimationToPlay);
            
            //Turn off the camera controller so that the shadow camera will update
            _camera.enabled = false;

            AnimController.Play(AnimationToPlay);
            _interpolateEndToken = new SimpleAsyncToken();


            _camera.CameraMoveTracker(this);
            

            return _interpolateEndToken;
        }

        /// <summary>
        /// Called when the sequence is done
        /// </summary>
        public void CameraAnimationEndFunction()
        {
            _camera.enabled = true;

            if (_interpolateEndToken != null)
            {
                _interpolateEndToken.Succeed();
            }

            //Remove clip from camera controller
            if (AnimClip != null && AnimController != null)
            {
                AnimController.RemoveClip(AnimationToPlay);
            }
            _interpolateEndToken = null;
        }

    }
}
