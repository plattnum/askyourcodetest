using System;
using GameTypes.GameDefinitions;
using Kixeye.Common;
using Newtonsoft.Json;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.GameData;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that waits for a given ammount of time before being complete.
    /// </summary>
    [Serializable]
    public class SSActionSetTuningData : ScriptedSequenceAction
    {

        #region Private Fields

        /// <summary>
        /// The application's GameDataManager singleton.
        /// </summary>
        [Inject]
        private WCMGameDataManager _gameData
        {
            get;
            set;
        }

        #endregion

        #region Public Fields
        
        /// <summary>
        /// The type of data to tune.
        /// </summary>
        [JsonProperty("DataToTune")]
        [ProtoMember(3)]
        public TuningDefinitionType DataToTune;
        
        /// <summary>
        /// The new value to set it to.
        /// </summary>
        [JsonProperty("NewValue")]
        [ProtoMember(4)]
        public float NewValue;
        
        /// <summary>
        /// Whether to set or clear the overridden tuning value.
        /// </summary>
        [JsonProperty("ClearValue")]
        [ProtoMember(5)]
        public bool ClearValue = false;
        
        #endregion

        #region Public Methods

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if (_gameData == null)
            {
                return new SimpleAsyncToken(new Exception("No GameDataManager found to alter tuning data."));
            }
            
            if (ClearValue)
            {
                _gameData.ClearTuningValueOverride( DataToTune );
            }
            else
            {
                _gameData.SetTuningValueOverride( DataToTune, NewValue );
            }
            
            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

