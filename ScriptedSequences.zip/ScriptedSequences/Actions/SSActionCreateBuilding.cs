using System;
using GameTypes;
using Kixeye.Common;
using Kixeye.WCM.GameData;
using ProtoBuf;
using UnityEngine;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that creates a building in the base.
    /// </summary>
    [Serializable]
    public class SSActionCreateBuilding : ScriptedSequenceAction
    {
        #region Private Fields

        /// <summary>
        /// The token representing the current builidng creation process.
        /// </summary>
        private SimpleAsyncToken _pendingToken;

        #endregion

        #region Public Fields

        /// <summary>
        /// The type of building to create.
        /// </summary>
        [JsonProperty("BuildingType")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(3)]
        public BuildingType BuildingType;

        /// <summary>
        /// The level of the building to create.
        /// </summary>
        [JsonProperty("Level")]
        [ProtoMember(4)]
        public int Level;

        /// <summary>
        /// The desired position the place the new building.
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Vector3 Position 
        { 
            get
            {
                return new Vector3(_position.x, _position.y, _position.z);
            }
            set
            {
                _position.x = value.x;
                _position.y = value.y;
                _position.z = value.z;
            }
        }

        /// <summary>
        /// The backing position data for this position. Should only be modified by teh serializer!
        /// </summary>
        [JsonProperty("Position")]
        [ProtoMember(5)]
        public PositionData _position = new PositionData();

        /// <summary>
        /// If the construction animation should be played or not.
        /// </summary>
        [JsonProperty("ShowConstruction")]
        [ProtoMember(6)]
        public bool ShowConstruction;

        #endregion

        #region Public Methods

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if(_pendingToken != null)
            {
                _pendingToken.ClearCallbacks();
                _pendingToken = null;
            }

            Base currentBase = WCMApplicationDirector.Instance.World.SpawnedBase;

            if(currentBase == null)
            {
                return new SimpleAsyncToken(new Exception("There isn't a spawned base."));
            }

            _pendingToken = new SimpleAsyncToken();

                /* TODO: [Processor] Replace this with a cheat instruction sent to the processor.
            Building createdBuilding;
            currentBase.CreateAndSpawnBuilding(BuildingType, Level, Position, out createdBuilding).ReadyUnity(BuildingSpawned);

            return _pendingToken;
                 */
            return new SimpleAsyncToken(true);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Succeds the currently pending token when the building is created and spawned.
        /// </summary>
        private void BuildingSpawned(ISimpleAsyncToken result)
        {
            if(_pendingToken == null)
            {
                return;
            }

            _pendingToken.Set(result);
            _pendingToken = null;
        }

        #endregion
    }
}

