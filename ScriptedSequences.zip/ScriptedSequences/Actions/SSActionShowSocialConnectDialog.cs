using System;
using Kixeye.Common;
using Ninject;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// An action that shows the prompt to log in to facebook
    /// </summary>
    [Serializable]
    public class SSActionShowSocialConnectDialog : ScriptedSequenceAction
    {
        /// <summary>
        /// The application's scripted sequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }
        
        /// <summary>
        /// The token representing the current act.
        /// </summary>
        private SimpleAsyncToken _actToken;
        
        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {    
            if (_ssController == null)
            {
                return new SimpleAsyncToken(new Exception("Failed to inject Scripted Sequences controller"));
            }

            if (_actToken != null)
            {
                _actToken.ClearCallbacks();
            }

            _actToken = new SimpleAsyncToken();

            SettingsPanel.CheckSocialConnectReminder().ReadyUnity(_actToken.Set);

            return _actToken;
        }
    }
}
