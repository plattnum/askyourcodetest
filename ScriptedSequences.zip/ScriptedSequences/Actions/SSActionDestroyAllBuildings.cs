﻿using System;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDestroyAllBuildings : ScriptedSequenceAction
    {

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            if ( WCMApplicationDirector.Instance.Battle == null ||
                !WCMApplicationDirector.Instance.Battle.IsBattleOccurring ||
                WCMApplicationDirector.Instance.Players == null ||
                WCMApplicationDirector.Instance.Players.OpponentPlayer == null ||
                WCMApplicationDirector.Instance.Players.OpponentPlayer.ActiveBase == null ||
                WCMApplicationDirector.Instance.Players.OpponentPlayer.ActiveBase.Buildings == null )
            {
                new SimpleAsyncToken(false);
            }

            foreach ( Building building in WCMApplicationDirector.Instance.Players.OpponentPlayer.ActiveBase.Buildings )
            {
                if ( building != null && !building.IsUndamageable && !building.IsUnkillable )
                {
                    building.Die();
                }
            }

            return new SimpleAsyncToken(true);
        }
    }
}

