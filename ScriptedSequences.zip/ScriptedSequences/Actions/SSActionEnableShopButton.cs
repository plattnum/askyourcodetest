﻿using System;
using UnityEngine;
using System.Collections;
using Kixeye.Common;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionEnableShopButton : ScriptedSequenceAction
    {
        [Newtonsoft.Json.JsonProperty("EnableShopButton")]
        [ProtoMember(3)]
        public bool EnableShopButton = true;

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }


        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            // set whether the shop button is enabled or not
            if (WCMApplicationDirector.Instance != null && WCMApplicationDirector.Instance.UI != null)
            {
                PersistentTopPanel topPanel = WCMApplicationDirector.Instance.UI.FindHUD<PersistentTopPanel>();
                if (topPanel != null)
                {
                    topPanel.EnableGoldButtonInteraction(EnableShopButton);
                }
            }

            return new SimpleAsyncToken(true);
        }

    }
}
