using System;
using System.Collections.Generic;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Ninject;
using Kixeye.Common.StateMachine;
using Kixeye.WCM.GameState;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDisableAI : ScriptedSequenceAction
    {
        public enum PlayerOwner
        {
            Local,
            Opponent,
        }

        public enum DisableAIScope
        {
            All,
            SingleSquad,
            SingleBuilding,
        }

        #region Serialized properties

        /// <summary>
        /// The scope of things to disable.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Scope")]
        [ProtoMember(3)]
        public DisableAIScope Scope;

        /// <summary>
        /// The player to enable or disable the AI for.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("PlayerWideAI")]
        [ProtoMember(4)]
        public PlayerOwner PlayerWideAI;

        /// <summary>
        /// The squad to enable or disable the AI for.
        /// </summary>
        [JsonProperty("Squad")]
        [ProtoMember(5)]
        public SquadDesignator Squad
        {
            get { return _squad; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _squad = new SquadDesignator();

        /// <summary>
        /// The building to enable or disable the AI for.
        /// </summary>
        [JsonProperty("Building")]
        [ProtoMember(6)]
        public BuildingDesignator Building
        {
            get { return _building; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private BuildingDesignator _building = new BuildingDesignator();

        /// <summary>
        /// Whether the AI of the players units will be turned on or off.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Enable")]
        [ProtoMember(7)]
        public bool Enable = false;

        #endregion

        #region public Properties

        /// <summary>
        /// For finding our local player.
        /// </summary>
        [Inject]
        public PlayerManager Players
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        public WCMGameStateController GameStates
        {
            get;
            private set;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            switch (Scope)
            {
                case DisableAIScope.All:
                    {
                        Player owningPlayer = null;

                        if (PlayerWideAI == PlayerOwner.Local)
                        {
                            owningPlayer = Players.LocalPlayer;
                        }
                        else
                        {
                            AttackData attackData = null;
                            IState currentState = GameStates.CurrentState;
                            if (currentState is AttackingState)
                            {
                                attackData = (currentState as AttackingState).AttackData;
                            }

                            if (attackData == null)
                            {
                                return new SimpleAsyncToken(new Exception("Could not find AttackData to get opponent.  Is the game in an attack or defend state?"));
                            }

                            owningPlayer = attackData.AttackTargetData.DefendingPlayer;
                        }

                        if (owningPlayer != null)
                        {
                            //Log.Error(this, "Disabling all player AIs");
                            List<Platoon> platoons = owningPlayer.Army.Platoons;
                            for (int i = 0, ilen = platoons.Count; i < ilen; i++)
                            {
                                Platoon platoon = platoons[i];
                                List<Squad> squads = platoon.Squads;
                                for (int j = 0, jlen = squads.Count; j < jlen; j++)
                                {
                                    Squad squad = squads[j];
                                    List<Unit> units = squad.Units;
                                    for (int k = 0, klen = units.Count; k < klen; k++)
                                    {
                                        Unit unit = units[k];

                                        if (unit.Brain != null)
                                        {
                                            unit.Brain.Enabled = Enable;
                                        }
                                    }
                                }
                            }

                            List<Building> buildings = owningPlayer.ActiveBase.Buildings;
                            for (int i = 0, len = buildings.Count; i < len; i++)
                            {
                                Building building = buildings[i];
                                if (building.Brain != null)
                                {
                                    building.Brain.Enabled = Enable;
                                }
                            }
                        }
                        else
                        {
                            return new SimpleAsyncToken(new Exception("Could not find a player to disable AIs for."));
                        }
                    }
                    break;

                case DisableAIScope.SingleBuilding:
                    {
                        Building building = this.Building.GetBuilding();
                        if (building != null &&
                            building.Brain != null)
                        {
                            building.Brain.Enabled = this.Enable;
                        }
                    }
                    break;

                case DisableAIScope.SingleSquad:
                    {
                        Squad squad = this.Squad.GetSquad();
                        if (squad != null)
                        {
                            foreach (Unit unit in squad.Units)
                            {
                                if (unit.Brain != null)
                                {
                                    unit.Brain.Enabled = this.Enable;
                                }
                            }
                        }
                    }
                    break;
            }

            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}

