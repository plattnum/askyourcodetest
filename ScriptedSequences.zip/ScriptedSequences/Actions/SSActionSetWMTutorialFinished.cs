﻿using System;
using UnityEngine;
using System.Collections;
using Kixeye.Common;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionSetWMTutorialFinished : ScriptedSequenceAction
    {
        #region private variables

        [Newtonsoft.Json.JsonProperty("WMTutorialFinished")]
        [ProtoMember(3)]
        public bool WMTutorialFinished = false;

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        #endregion

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            _ssController.HasWMTutorialFinished = WMTutorialFinished;

            return new SimpleAsyncToken(true);
        }

    }
}
