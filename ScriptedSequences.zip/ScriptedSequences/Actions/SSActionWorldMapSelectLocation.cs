﻿using System;
using Kixeye.Common;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Ninject;
using WorldMap;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Starts/stops Actor glow
    /// </summary>
    [Serializable]
    public class SSActionWorldMapSelectLocation : ScriptedSequenceAction, ISerializationCallbackReceiver
    {

        #region Serialized properties

        /// <summary>
        /// Every World Map Actor has a named spawner; that's how we identify Actors.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ActorSpawnerName")]
        [ProtoMember(3)]
        public string TargetName;

        [Newtonsoft.Json.JsonProperty("Zoom")]
        [ProtoMember(8)]
        public float? Zoom;

        [Newtonsoft.Json.JsonProperty("RestrictSelection")]
        [ProtoMember(9)]
        public bool RestrictSelection;

        #endregion


        #region Unity Serialization Support

        [SerializeField]
        protected NullableSerializedFloat _zoom;

        public void OnBeforeSerialize()
        {
            _zoom = new NullableSerializedFloat
            {
                Value = Zoom,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_zoom != null)
            {
                Zoom = _zoom.Value;
            }
            _zoom = null;
        }

        #endregion


        [Inject]
        private WorldMapController WorldMapController { get; set; }

        #region Public methods

        public override string GetDebugName ()
        {
            string prefix = "Set SelectLocation to Actor ";

            string name = string.IsNullOrEmpty(TargetName) ? "<NONE SELECTED>" : TargetName;

            return prefix + name ;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act ()
        {
            WorldMapController.SetSelectedLocationFromActor(TargetName, RestrictSelection);
            return new SimpleAsyncToken(true);
        }

        #endregion
    }
}