﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kixeye.Common;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Input;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionDisableUserInteracitionExcept : ScriptedSequenceAction
    {
        #region Serialized properties
        /// <summary>
        /// Is the user interaction is restricted or not.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UnrestrictedInteraction")]
        [ProtoMember(3)]
        public bool UnrestrictedInteraction = false;

        /// <summary>
        /// The squads to restrict selection to.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadExceptions")]
        [ProtoMember(4)]
        public List<SquadDesignator> SquadExceptions = new List<SquadDesignator>();

        /// <summary>
        /// The buildings to restrict selection to.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BuildingExceptions")]
        [ProtoMember(5)]
        public List<BuildingDesignator> BuildingExceptions = new List<BuildingDesignator>();

        /// <summary>
        /// UI elements to restrict the selection to.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("UIElementExceptions")]
        [ProtoMember(6)]
        public List<UIElementDesignator> UIElementExceptions = new List<UIElementDesignator>();
        #endregion

        #region Private Variables
        /// <summary>
        /// The application's Input controller.
        /// </summary>
        [Inject]
        private PlayerInput _input
        {
            get;
            set;
        }

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }
        #endregion

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSActionDisableUserInteracitionExcept));

        #region Public methods

        public override string GetDebugName()
        {
            if (UnrestrictedInteraction)
            {
                return "Enable User Interaction";
            }

            var exceptions = new List<string>();
            foreach (var exception in SquadExceptions.NullAsEmpty())
            {
                exceptions.Add(exception.ToString());
            }
            foreach (var exception in BuildingExceptions.NullAsEmpty())
            {
                exceptions.Add(exception.ToString());
            }
            foreach (var exception in UIElementExceptions.NullAsEmpty())
            {
                exceptions.Add(exception.GetDescription(brief: true));
            }
            if (exceptions.Count > 0)
            {
                return "Disable User Interaction Except " + exceptions.ToLexicalList();
            }

            return "Disable All User Interaction";
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            // reset all previously set restrictions
            _input.ClearGameItemSelectionExceptions();
           _ssController.ReEnableUI();

            if (UnrestrictedInteraction)
            {
                return new SimpleAsyncToken(true); ;
            }

            // squads excepted from the disable interaction rule
            if (SquadExceptions != null)
            {
                foreach (var squadException in SquadExceptions)
                {
                    Player thePlayer;
                    Platoon platoon;
                    Squad squad = squadException.GetSquad(out thePlayer, out platoon);

                    if (squad == null)
                    {
                        return new SimpleAsyncToken(new Exception("Cannot find squad to restrict selection to"));
                    }

                    for (int i = 0, count = squad.Count; i < count; ++i)
                    {
                        _input.AddItemToSelectionExceptions(squad.Units[i]);
                    }
                }
            }

            // buildings excepted from the disable interaction rule
            if (BuildingExceptions != null)
            {
                foreach (var buildingException in BuildingExceptions)
                {
                    foreach (Building building in buildingException.GetBuildings())
                    {
                        if (building == null)
                        {
                            continue;
                        }
                        _input.AddItemToSelectionExceptions(building);
                    }
                }
            }

            // UI elements excepted from the disable interaction rule
            if (UIElementExceptions != null)
            {
                foreach (var uiElementException in UIElementExceptions)
                {
                    GameObject uiElement = uiElementException.GetUIElement();
                    if (uiElement == null)
                    {
                        return new SimpleAsyncToken(new Exception("Could not find UI Element designated by [" + uiElementException.GetDescription() + "]"));
                    }

                    if (!uiElement.activeInHierarchy && _logger.IsEnabled(LogMessageLevel.Warn))
                    {
                        _logger.Warn(GetDebugNameFull() + " disabling all UI except for " + uiElement.name + " which is not currently active.");
                    }                        

                    _ssController.AddDisalbedUIException(uiElement);
                }
            }
            
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

