using System;
using ProtoBuf;
using Kixeye.Common;
using Ninject;
using Kixeye.WCM.WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionWorldMapPlayAnimation : ScriptedSequenceAction
    {
        public enum AnimationType
        {
            HidePlayerHq,
            PlayConstructionAnimationAndShowPlayerHq,
        }

        [Newtonsoft.Json.JsonProperty("WMAnimation")]
        [ProtoMember(3)]
        public AnimationType WMAnimation;

        [Inject]
        public WorldMapController WorldMap
        {
            get;
            private set;
        }

        public override string GetDebugName()
        {
            return "Play Animation on WM: " + WMAnimation;
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Creates an indicator over a UI element.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            switch(WMAnimation)
            {
                case AnimationType.HidePlayerHq:
                    WorldMap.HideZoneActor(WorldMap.GetPlayerHqFromCurrentZone());
                    break;
            }

            return new SimpleAsyncToken(true);
        }
    }
}

