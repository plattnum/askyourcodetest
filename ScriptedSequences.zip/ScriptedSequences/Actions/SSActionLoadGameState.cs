using System;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameState;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSActionLoadGameState : ScriptedSequenceAction
    {
        #region public types
        public enum GameStateEnum
        {
            BaseManagement = 0,
            // AccountSetup,
            ScoutingState = 2,
            WorldMapState = 3,
        }

        public enum PermanentZones
        {
            France = 0,
            Sardinia = 1,
            Spain = 2,
        }
        #endregion

        #region serialized variables
        [JsonProperty("GameState")]
        [ProtoMember(3)]
        public GameStateEnum GameState;

        [JsonProperty("ForceZone")]
        [ProtoMember(4)]
        public bool ForceZone;

        ////[JsonProperty("UseNuxZone")]
        ////[ProtoMember(5)]
        ////public bool UseNuxZone;

        [JsonProperty("ZoneId")]
        [ProtoMember(6)]
        public PermanentZones Zone;
        #endregion

        #region private variables
        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSActionLoadGameState));
        #endregion
        
        #region Public methods
        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            switch (GameState)
            {
            case GameStateEnum.BaseManagement:
                if (WCMApplicationDirector.Instance.GameStates.CurrentState is BaseManagementState)
                {
                    break;
                }
                return WCMApplicationDirector.Instance.GameStates.LoadBaseManagementState();

            case GameStateEnum.WorldMapState:
                int? overrideZoneId = null;
                if (ForceZone)
                {
                    overrideZoneId = (int)Zone;
                }
                if (WCMApplicationDirector.Instance.GameStates.CurrentState is WorldMapState)
                {
                    var currentZone = WCMApplicationDirector.Instance.WorldMap.CurrentZone;
                    if (currentZone != null)
                    {
                        if (!overrideZoneId.HasValue || currentZone.ZoneId == overrideZoneId.Value)
                        {
                            // All is good.
                            break;
                        }
                        WCMApplicationDirector.Instance.WorldMap.LoadZone(overrideZoneId.Value);
                        break;
                    }
                    // Transition to world map must still be in progress
                    break;
                }
                WorldMapState.ForceZoneId = overrideZoneId;
                WCMApplicationDirector.Instance.GameStates.LoadWorldMapState();
                break;

            default:
                return new SimpleAsyncToken(new Exception("Unsupported Game State: " + GameState));
            }

            // TODO: Changing states returns a token.  Why does waiting for it mess up our sequence?
            return new SimpleAsyncToken(true);
        }
        #endregion    
    }
}

