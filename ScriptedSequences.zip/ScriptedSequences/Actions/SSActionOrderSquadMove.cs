using System;
using GameTypes;
using Kixeye.WCM.AI;
using Kixeye.WCM.ui;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.GameData;
using Kixeye.WCM.Controllers;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using ProtoBuf;
using UnityEngine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    [ProtoInclude(3, typeof(SSActionTeleportSquad))]
    public class SSActionOrderSquadMove : ScriptedSequenceAction, ISerializationCallbackReceiver
    {
        #region Serialized properties        

        /// <summary>
        /// The squad to spawn to order to move.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToOrder")]
        [ProtoMember(4)]
        public SquadDesignator SquadToOrder = new SquadDesignator();

        /// <summary>
        /// The backing position data for this position. Should only be modified by the serializer!
        /// </summary>
        [Newtonsoft.Json.JsonProperty("DestinationPosition")]
        [ProtoMember(5)]
        public PositionData DestinationPosition = new PositionData();

        /// <summary>
        /// Override default behavior at end of movement
        /// </summary>
        [Newtonsoft.Json.JsonProperty("OnFinishedBehavior")]
        [ProtoMember(6)]
        public MoveCommand.OnFinishedBehavior? OnFinishedBehavior;

        // Backwards compatibility: default behavior was leash
        public MoveCommand.OnFinishedBehavior EffectiveOnFinishedBehavior
        {
            get
            {
                var onFinishedBehavior = OnFinishedBehavior.GetValueOrDefault(MoveCommand.OnFinishedBehavior.Leash);
                return onFinishedBehavior;
            }
        }

        #endregion

        #region Unity Serialization Support

        [Serializable]
        public class NullableOnFinishedBehavior : NullableSerialization<MoveCommand.OnFinishedBehavior>
        {
        }

        [SerializeField]
        protected NullableOnFinishedBehavior _onFinishedBehavior;

        public void OnBeforeSerialize()
        {
            _onFinishedBehavior = new NullableOnFinishedBehavior
            {
                Value = OnFinishedBehavior,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_onFinishedBehavior != null)
            {
                OnFinishedBehavior = _onFinishedBehavior.Value;
            }
            _onFinishedBehavior = null;
        }

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            return "Order Squad Move: {0} ({1})".FormatWith(SquadToOrder, EffectiveOnFinishedBehavior);
        }

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        override public ISimpleAsyncToken Act()
        {
            Squad squad = SquadToOrder.GetSquad();

            if (squad == null)
            {
                throw new ApplicationException("Cannot find squad for move order.");
            }
            if (squad.IsDeployed == false)
            {
                throw new ApplicationException("Squad cannot be ordered to move because it hasn't been deployed.");
            }
            if (squad.IsDead || squad.IsEmpty)
            {
                throw new ApplicationException("Squad cannot be ordered to move because it has no living units.");
            }

            squad.Brain.Move(DestinationPosition, EffectiveOnFinishedBehavior, true);
            
            return new SimpleAsyncToken(true);
        }

        #endregion    
    }
}

