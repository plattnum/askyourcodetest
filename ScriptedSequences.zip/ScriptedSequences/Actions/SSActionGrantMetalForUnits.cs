using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using ProtoBuf;
using Model;
using GameTypes;
using GameTypes.GameDefinitions;
using GameTypes.Costing;
using Ninject;
using Kixeye.Common;
using Kixeye.Core.Logging;
using Kixeye.WCM.ui;


namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Grant metal to the player to build units.
    /// </summary>
    [Serializable]
    public class SSActionGrantMetalForUnits : ScriptedSequenceAction
    {
        /// <summary>
        /// The ammount of seconds to delay.
        /// </summary>
        [JsonProperty("Count")]
        [ProtoMember(3)]
        public int Count = 1;

        /// <summary>
        /// The game's ui controller
        /// </summary>
        [Inject]
        public UIController UI { private get; set; }

        /// <summary>
        /// Called when a sequence node's conditions are met. Does the action.
        /// </summary>
        public override ISimpleAsyncToken Act()
        {
            // Find out what unit is selected in the panel
            PanelBase currentPanel = UI.CurrentPanel;

            if (currentPanel is SSUI_Unit_Crafting && Count > 0)
            {
                SSUI_Unit_Crafting craftSSUI = (SSUI_Unit_Crafting)currentPanel;

                int? selectedCraftableItemCard = craftSSUI.Panel.SelectedCard.ItemDefinitionId;

                if (selectedCraftableItemCard.HasValue)
                {
                    var gameData = WCMApplicationDirector.Instance.GameData;
                    IList<BaseGameDefinition<string>> definitions = new List<BaseGameDefinition<string>>();

                    ItemDefinition definition = gameData.GetItemDefinition(selectedCraftableItemCard.Value);

                    for (int i = 0; i < Count; i++)
                    {
                        definitions.Add(definition);
                    }
                    WCMApplicationDirector.Instance.PlayerProcessor.GrantMetalForGameDefinitions(definitions);
                }
                else
                {
                    Log.Error(this, "Invalid selected craftable item received: is null.");
                }
            }
            else
            {
                return new SimpleAsyncToken(new Exception("Invalid current Panel recevied: " + currentPanel));
            }
            
            return new SimpleAsyncToken(true);
        }

    }
}

