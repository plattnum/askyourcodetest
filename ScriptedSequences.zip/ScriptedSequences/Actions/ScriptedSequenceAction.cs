using System;
using Newtonsoft.Json;
using Kixeye.Common;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// The base class for actions performed by a Scripted Sequence.  All action classes should derive from this.
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    public abstract class ScriptedSequenceAction : ScriptedSequenceComponent
    {

        #region Private Variables
        protected ISimpleAsyncToken _asyncToken;
        #endregion

        #region Public methods

        /// <summary>
        /// Called when a sequence node's conditions are met.  Does the action.
        /// </summary>
        public abstract ISimpleAsyncToken Act();

        public Status Status { get; set; } // used by controller for debugging

        public string StatusMessage { get; set; } // used by controller for debugging

        public Exception Exception { get; set; } // used by controller for debugging

        public void ResetAsyncToken()
        {
            if (_asyncToken != null)
            {
                _asyncToken.Reset();
                _asyncToken = null;
            }
        }


       #endregion

       
    }

    public enum Status
    {
        Dormant,
        Waiting,
        Running,
        Complete,
        Failed,
    }
}

