using System;
using Newtonsoft.Json;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ProtoBuf;
using UnityEngine;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// The base class for actions performed by a Scripted Sequence.  All action classes should derive from this.
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    [ProtoInclude(1, typeof(ScriptedSequenceAction))]
    [ProtoInclude(2, typeof(ScriptedSequenceCondition))]
    public class ScriptedSequenceComponent : UnityEngine.ScriptableObject, IScriptedSequenceComponent, ISaveAsset
    {
        private const string LogFormat = "{0}: {1}";

        public virtual void WriteTo( AssetSaver saver )
        {
#if UNITY_EDITOR
            saver.Save(this);
#endif
        }

        #region Private variables

        /// <summary>
        /// The parent node, sequence or condition for this condition
        /// </summary>
        [NonSerialized]
        private IScriptedSequenceComponentParent _parent = null;

        #endregion

        #region public properties

        public ScriptedSequence ScriptedSequence { get { return Parent == null ? null : Parent.ScriptedSequence; } }

        public IScriptedSequenceComponentParent Parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        /// <summary>
        /// Get the parent node of the component.
        /// Note: in case the component has a sequence as a parent it will return null.
        /// </summary>
        /// <returns>The parent node for this component.</returns>
        public ScriptedSequenceNode GetParentNode()
        {
            return GetParentNode(this);
        }

        /// <summary>
        /// Get the parent node of the specified component.
        /// Note: in case the component has a sequence as a parent it will return null.
        /// </summary>
        /// <param name="component">The coponent from which to get the parent.</param>
        /// <returns>The parent node for this component.</returns>
        private ScriptedSequenceNode GetParentNode(ScriptedSequenceComponent component)
        {
            if (component == null || component.Parent == null)
            {
                return null;
            }

            Type parentType = component.Parent.GetType();
            if (parentType == typeof(ScriptedSequenceCondition) ||
                parentType.IsSubclassOf(typeof(ScriptedSequenceCondition)))
            {
                ScriptedSequenceCondition parentCondition = component.Parent as ScriptedSequenceCondition;
                return GetParentNode(parentCondition);
            }

            if (parentType == typeof(ScriptedSequenceNode))
            {
                return component.Parent as ScriptedSequenceNode;
            }
            return null;
        }

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(ScriptedSequenceComponent));

        #endregion

        #region Constructor

        public ScriptedSequenceComponent()
        {
        }

        #endregion

        #region Public methods

        private static void AutoGetDescriptions(object[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                var obj = args[i];
                var component = obj as IScriptedSequenceComponent;
                if (component != null)
                {
                    args[i] = component.GetDebugNameFull();
                }
            }
        }

        public void LogDebug(string format, params object[] args)
        {
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                AutoGetDescriptions(args);
                var message = format.FormatWith(args);
                message = LogFormat.FormatWith(GetDebugNameFull(), message);
                _logger.Debug(null, message);
                ScriptedSequencesController.AppendLineToScriptedSequenceLog(message);
            }
        }

        public void LogError(string format, params object[] args)
        {
            if (_logger.IsEnabled(LogMessageLevel.Error))
            {
                AutoGetDescriptions(args);
                var message = format.FormatWith(args);
                message = LogFormat.FormatWith(GetDebugNameFull(), message);
                _logger.Error(null, message);
                ScriptedSequencesController.AppendLineToScriptedSequenceLog(message);
            }
        }

        public virtual void Migrate(bool onCreate) { }

        /// <summary>
        /// Initialize the component.
        /// </summary>
        /// <param name='parent'>
        /// The parent for this component(node, sequence or condition).
        /// </param>
        virtual public void Initialize(IScriptedSequenceComponentParent parent)
        {
            _parent = parent;
            Kixeye.Core.Injector.Inject(this);
        }

        public bool IsInitialized()
        {
            return _parent != null;
        }
        
        /// <summary>
        /// Gets the the descriptive name for this component for debugging.
        /// </summary>
        virtual public string GetDebugName()
        {
            return GetType().Name;
        }
        
        /// <summary>
        /// Gets the the fully-qualified descriptive name for this component for debugging.
        /// </summary>
        virtual public string GetDebugNameFull()
        {
            return (_parent != null ? _parent.GetDebugNameFull() : "<NULL>") + "/" + GetDebugName();
        }
        
        #endregion
    }
}

