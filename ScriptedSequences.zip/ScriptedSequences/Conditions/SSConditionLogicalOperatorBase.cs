﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    public interface ISSCompoundCondition
    {
        IScriptedSequenceComponentParent Parent { get; }

        /// <summary>
        /// Conditions nested under this one.
        /// </summary>        
        List<ScriptedSequenceCondition> Conditions { get; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    public abstract class SSConditionLogicalOperatorBase : ScriptedSequenceCondition, IScriptedSequenceComponentParent, ISSCompoundCondition
    {
        #region Serialized Properties
        /// <summary>
        /// Conditions nested under this one.
        /// </summary>        
        [JsonProperty("NestedConditions")]
        [ProtoMember(3)]
        public List<ScriptedSequenceCondition> Conditions
        {
            get
            {
                if (_nestedConditions == null)
                {
                    _nestedConditions = new List<ScriptedSequenceCondition>();
                }
                return _nestedConditions;
            }
            set
            {
                _nestedConditions = value;
            }
        }

        /// <summary>
        /// The actions that are executed when this sequence activates.
        /// </summary>
        [JsonProperty("Actions")]
        [ProtoMember(4)]
        public List<ScriptedSequenceAction> Actions
        {
            get
            {
                if (_actions == null)
                {
                    _actions = new List<ScriptedSequenceAction>();
                }
                return _actions;
            }
            set
            {
                _actions = value;
            }
        }
        [UnityEngine.SerializeField]
        private List<ScriptedSequenceAction> _actions = default;

        [UnityEngine.SerializeField]
        private List<ScriptedSequenceCondition> _nestedConditions = default;

        #endregion Serialized Properties

        #region Public properties

        public ScriptedSequencesController ScriptedSequences { get { return Parent == null ? null : Parent.ScriptedSequences; } }

        /// <summary>
        /// // Override the base class "Enabled" so we can enable/disable every condition nested under this one
        /// </summary>
        public override bool Enabled
        {
            set
            {
                foreach (var condition in Conditions)
                {
                    condition.Enabled = value;
                }
                // Set base enabled last, it calls Evaluate().
                base.Enabled = value;
            }
        }

        /// <summary>
        /// Force subclasses to implement an appropriate "Met" condition.
        /// </summary>
        public abstract override bool Met { get; }

        public override void Migrate(bool onCreate)
        {
            base.Migrate(onCreate);
            this.MigrateConditionsAndActions(onCreate);
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            foreach (var condition in Conditions.ToArray())
            {
                // make sure that the 'SSConditionNodeComplete' conditions are placed first
                if (condition.GetType() == typeof(SSConditionNodeComplete))
                {
                    Conditions.Remove(condition);
                    Conditions.Insert(0, condition);
                }
                // initialize the condition
                condition.Initialize(this);
            }
        }

        /// <summary>
        /// Resets the condition to its starting state.
        /// </summary>
        public override void Reset()
        {
            foreach (var condition in Conditions)
            {
                condition.Reset();
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected sealed override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }
            base.Met = this.Met;
        }

        /// <summary>
        /// Called whenever a child condition's status has changed.
        /// </summary>
        /// <param name="conditionThatChanged">Condition that changed.</param>
        public void OnConditionMetChanged(ScriptedSequenceCondition conditionThatChanged)
        {
            Evaluate();
        }

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            Actions.ForAll(it => it.WriteTo(saver));
            Conditions.ForAll(it => it.WriteTo(saver));
            base.WriteTo(saver);
#endif
        }

        #endregion Public Properties
    }
}
