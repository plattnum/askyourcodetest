using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Kixeye.WCM.Events;
using Ninject;
using Assets.Source.Scripts.GameData;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionBlueprintAcquired : ScriptedSequenceCondition
    {
        [Newtonsoft.Json.JsonProperty("BlueprintItemId")]
        [ProtoMember(3)]
        public int blueprintItemId;

        [Inject]
        private EventManager _events {get; set;}
        [Inject]
        private PlayerManager _players {get; set;}

        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    SetupHandlers(value);
                }
            }
        }

        public override void Initialize(IScriptedSequenceComponentParent parent )
        {
            base.Initialize(parent);
            SetupHandlers(Enabled);
        }

        private void SetupHandlers(bool enableHandlers)
        {
            if (enableHandlers)
            {
                _events.AddEventHandler<PlayerInventoryHasChangedEvent>(OnPlayerInventoryChanged);
            }
            else
            {
                _events.RemoveEventHandler<PlayerInventoryHasChangedEvent>(OnPlayerInventoryChanged);
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (IsInitialized() && Enabled && _players != null
                && _players.LocalPlayer != null
                && _players.LocalPlayer != null
                && _players.LocalPlayer.Data != null
                && _players.LocalPlayer.Data.Inventory != null
                && _players.LocalPlayer.Data.Inventory.QuantityInInventory(blueprintItemId) > 0)
            {
                Met = true;
            };
        }

        private void OnPlayerInventoryChanged(PlayerInventoryHasChangedEvent @event)
        {
            Evaluate();
        }
    }
}