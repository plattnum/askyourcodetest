using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Events;
using Ninject;
using System.Text.RegularExpressions;


namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionBattleEnded : ScriptedSequenceCondition
    {
        public enum EndingType
        {
            Victory,
            Defeat,
            Either
        }
        
        #region Serialized properties
        
        /// <summary>
        /// Whether the battle ended in victory, defeat or either one.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfEnding")]
        [ProtoMember(3)]
        public EndingType TypeOfEnding = EndingType.Either;


        /// <summary>
        /// The id or pattern to match the battle's map id. Set UseRegex to true if the value is a pattern.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MapId")]
        [ProtoMember(4)]
        public string MapId;

        /// <summary>
        /// If true, MapId is a regular expression pattern to match the battle map id. Otherwise MapId must be equal.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("UseRegex")]
        [ProtoMember(5)]
        public bool UseRegex;

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        private bool _handlersRegistered = false;

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionBattleEnded));
        
        #endregion

        #region Public properties

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            if (value)
                            {

                                if (!_handlersRegistered)
                                {
                                    //Add event handler
                                    _events.AddEventHandler<GameStateChangeEvent>(OnStateChanged);
                                    _events.AddEventHandler<BattleEndedEvent>(OnBattleEnded);
                                    _handlersRegistered = true;
                                }
                            }
                            else
                            {
                                if (_handlersRegistered)
                                {
                                    // remove the event handler
                                    _events.RemoveEventHandler<GameStateChangeEvent>(OnStateChanged);
                                    _events.RemoveEventHandler<BattleEndedEvent>(OnBattleEnded);
                                    _handlersRegistered = false;
                                }
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            var str = "Battle Ended";
            if (!string.IsNullOrEmpty(MapId))
            {
                str += ": " + MapId;
            }
            if (TypeOfEnding != EndingType.Either)
            {
                str += ": " + TypeOfEnding;
            }
            return str;
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (Enabled)
            {
                if (_events != null)
                {
                    //Add event handlers
                    _events.AddEventHandler<GameStateChangeEvent>(OnStateChanged);
                    _events.AddEventHandler<BattleEndedEvent>(OnBattleEnded);

                    _handlersRegistered = true;
                }
            }
        }
        
        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Kixeye.WCM.Controllers.BattleController battleController = WCMApplicationDirector.Instance.Battle;
            if (battleController == null ||
                battleController.IsBattleOccurring == true  || 
                !WCMApplicationDirector.Instance.Battle.PostBattleSequencingOccurring) 
            {
                return;
            }

            if (ConditionsSatisfied(battleController.AttackData, battleController.BattleStats))
            {
                Met = true;
            }
        }

        private bool ConditionsSatisfied(AttackData attackData, BattleStats battleStats)
        {
            string mapName;
            switch (attackData.AttackTargetData.AttackType)
            {
                case GameTypes.AttackType.Matchmaking:
                case GameTypes.AttackType.Revenge:
                case GameTypes.AttackType.Practice:
                    mapName = "HQ";
                    break;
                default:
                    if (attackData.AttackTargetData.DefendingPlayer.BattleData == null)
                    {
                        mapName = string.Empty;
                    }
                    else
                    {
                        mapName = attackData.AttackTargetData.DefendingPlayer.BattleData.MapName ?? string.Empty;
                    }
                    break;
            }
            mapName = mapName.ToLowerInvariant();

            if (!string.IsNullOrEmpty(MapId))
            {
                if (string.IsNullOrEmpty(mapName))
                {
                    if (_logger.IsEnabled(LogMessageLevel.Debug))
                    {
                        _logger.Debug(null, "{0}: AttackTargetData has no MapId: {1}", GetDebugNameFull(), attackData.AttackTargetData);
                    }
                    return false;
                }
                if (UseRegex)
                {
                    if (!Regex.IsMatch(mapName, MapId.ToLowerInvariant()))
                    {
                        if (_logger.IsEnabled(LogMessageLevel.Debug))
                        {
                            _logger.Debug(null, "{0}: AttackData MapId doesn't match: {1} != {2}", GetDebugNameFull(), mapName, MapId);
                        }
                        return false;
                    }
                }
                else
                {
                    if (mapName != MapId.ToLowerInvariant())
                    {
                        if (_logger.IsEnabled(LogMessageLevel.Debug))
                        {
                            _logger.Debug(null, "{0}: AttackData MapId doesn't match: {1} != {2}", GetDebugNameFull(), mapName, MapId);
                        }                        
                        return false;
                    }
                }
            }
            if (TypeOfEnding == EndingType.Either)
            {
                return true;
            }
            var victorious = battleStats.VictoriousPlayer == WCMApplicationDirector.Instance.Players.LocalPlayer;
            return victorious == (TypeOfEnding == EndingType.Victory);
        }

        #endregion
        
        #region Private methods
        
        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnStateChanged( GameStateChangeEvent stateEvent )
        {
            if (Enabled)
            {
                // Reset this condition any time a new state is entered.
                Met = false;
            }
        }
        
        /// <summary>
        /// Called when a battle ends.
        /// </summary>
        private void OnBattleEnded( BattleEndedEvent battleEvent )
        {
            if (Enabled)
            {
                if (ConditionsSatisfied(battleEvent.AttackData, battleEvent.BattleStats))
                {
                    Met = true;
                    
                    //WCM-63882: Note that the quick match NUX actually complete when we win the battle.
                    if (TypeOfEnding == EndingType.Victory)
                    {
                        _events.HandleEvent(TutorialCompleteEvent.GetInstance());
                    }
                }
            }
        }
        
        #endregion
    }
}

