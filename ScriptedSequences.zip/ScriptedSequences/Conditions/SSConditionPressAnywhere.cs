using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;
using UnityEngine.EventSystems;
using System.Collections.Generic;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionPressAnywhere : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("PassThroughTouch")]
        [ProtoMember(3)]
        public bool PassThroughTouch;

        #endregion
        
        #region Private variables

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        [Inject]
        private ScriptedSequencesController _ssController
        {
            get;
            set;
        }

        /// <summary>
        /// The application's VirtualInput.
        /// </summary>
        [Inject]
        private IVirtualInput _input
        {
            get;
            set;
        }

        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (IsInitialized())
                    {
                        SetCatcherActive(value);
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this action.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetCatcherActive(true);
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }
        
        /// Handles the touch catcher being touched.
        /// </summary>
        /// <param name="sender">The even sender.</param>
        private void HandleCatcherTouched()
        {
            if (Met)
            {
                return;
            }

            Met = true;

            SetCatcherActive(false);

            if (_events != null)
            {
                _events.HandleEvent(UIElementEvent.GetInstance(UIElementEvent.UIEventType.TutorialTapAnywhere));
            }

            if (PassThroughTouch && _input != null)
            {
                // check if we hit a UI Element
                PointerEventData cursor = new PointerEventData(EventSystem.current);
                cursor.position = UnityEngine.Input.mousePosition;
                List<RaycastResult> raycastResults = new List<RaycastResult>();
                EventSystem.current.RaycastAll(cursor, raycastResults);
                foreach (var result in raycastResults)
                {
                    // pass on the click event
                    ExecuteEvents.Execute(result.gameObject, cursor, ExecuteEvents.pointerClickHandler);
                }
            }
        }
        
        private void SetCatcherActive( bool active )
        {
            if (_ssController != null)
            {
                if (active)
                {
                    if (!_handlersRegistered)
                    {
                        _ssController.TouchHandlerAdd(HandleCatcherTouched);
                        _handlersRegistered = true;
                    }
                }
                else
                {
                    if (_handlersRegistered)
                    {
                        _ssController.TouchHandlerRemove(HandleCatcherTouched);
                        _handlersRegistered = false;
                    }
                }
            }
        }
    }
}

