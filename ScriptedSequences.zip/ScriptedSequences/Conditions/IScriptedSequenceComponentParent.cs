﻿using System;
using System.Collections.Generic;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;


namespace Kixeye.WCM.ScriptedSequences
{
    public interface IScriptedSequenceComponentParent : IScriptedSequenceComponent
    {
        /// <summary>
        /// The conditions contained by the parent.
        /// </summary>
        List<ScriptedSequenceCondition> Conditions
        {
            get;
            set;
        }

        /// <summary>
        /// The actions contained by the parent.
        /// </summary>
        List<ScriptedSequenceAction> Actions
        {
            get;
            set;
        }

        /// <summary>
        /// The application's ScriptedSequences controller.
        /// </summary>
        ScriptedSequencesController ScriptedSequences { get; }

        /// <summary>
        /// Called whenever a child condition's status has changed.
        /// </summary>
        /// <param name="conditionThatChanged">Condition that changed.</param>
        void OnConditionMetChanged(ScriptedSequenceCondition conditionThatChanged);

        /// <summary>
        /// Perform any necessary on-load fixup.
        /// </summary>
        void Migrate(bool onCreate);
    }

    public static class ScriptedSequenceComponentParentExtensions
    {
        public static void MigrateConditionsAndActions(this IScriptedSequenceComponentParent self, bool onCreate)
        {
            for (int i = 0, count = self.Conditions.Count; i < count; i++)
            {
                if (self.Conditions[i] == null)
                {
                    Log.Error(self, "MigrateConditionsAndActions", "{0} null condition in slot {1}", self.GetDebugNameFull(), i);
                    continue;
                }
                self.Conditions[i].Migrate(onCreate);
            }
            for (int i = 0, count = self.Actions.Count; i < count; i++)
            {
                if (self.Actions[i] == null)
                {
                    Log.Error(self, "MigrateConditionsAndActions", "{0} null action in slot {1}", self.GetDebugNameFull(), i);
                    continue;
                }
                self.Actions[i].Migrate(onCreate);
            }
        }
    }
}
