﻿using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Newtonsoft.Json;
using System.ComponentModel;
using GameTypes;
using Kixeye.WCM.Pve;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionMapTypeAttacked : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("MapAttackType")]
        [ProtoMember(3)]
        public AttackType MapAttackType;

        #endregion
        [Inject]
        protected EventManager _events { get; set; }

        protected bool _handlersRegistered = false;

       // private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionMapTypeAttacked));

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = false;

            ScoutingState scoutingState  = WCMApplicationDirector.Instance.GameStates.CurrentState as ScoutingState;
            if (scoutingState != null)
            {
                Met = scoutingState.ScoutingParameters.AttackType == MapAttackType;
                return;
            }

            AttackingState attackingState  = WCMApplicationDirector.Instance.GameStates.CurrentState as AttackingState;
            if (attackingState != null)
            {
                Met = WCMApplicationDirector.Instance.Battle.AttackData.AttackTargetData.AttackType == MapAttackType;
            }
        }

        /// <summary>
        /// Called when the battle has begun.
        /// </summary>
        private void OnBattleBegun(BattleBegunEvent battleBegunEvent)
        {
            if (!battleBegunEvent.AttackData.AttackTargetData.AttackType.IsRecording())
            {
                Evaluate();
            }
        }
    }
}


