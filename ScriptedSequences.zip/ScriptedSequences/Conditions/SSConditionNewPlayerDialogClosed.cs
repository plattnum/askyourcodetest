﻿using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.ScriptedSequences;

namespace Kixeye.WCM.ScriptedSequences
{
    public class SSConditionNewPlayerDialogClosed : ScriptedSequenceCondition
    {
     #region Private Fields

        private bool _handlersRegistered;

        #endregion

        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<NewPlayerDialogClosedEvent>(OnNewPlayerDialogClosed);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<NewPlayerDialogClosedEvent>(OnNewPlayerDialogClosed);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<NewPlayerDialogClosedEvent>(OnNewPlayerDialogClosed);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }
        #endregion

        #region Private methods

        /// <summary>
        /// Called whenever the train menu gets loaded.
        /// </summary>
        private void OnNewPlayerDialogClosed(NewPlayerDialogClosedEvent evt)
        {
            if (Enabled)
            {
                if (evt.Closed)
                {                    
                    Met = true;
                }
                else
                {                    
                    Met = false;
                }
            }
        }



        #endregion    
    }
}
