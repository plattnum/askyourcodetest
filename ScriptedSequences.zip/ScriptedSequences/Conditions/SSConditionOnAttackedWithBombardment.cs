﻿using System;
using GameTypes;
using ProtoBuf;
using Kixeye.Core.Logging;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnAttackedWithBombardment : ScriptedSequenceCondition
    {
        #region Serialized properties
        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        private bool _handlersRegistered = false;

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionOnAttackedWithBombardment));
        #endregion

        #region Public properties

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
        }
        #endregion

        #region Private methods

        /// <summary>
        /// Called whenever the battle has begun.
        /// </summary>
        private void OnBattleBegun(BattleBegunEvent battleBegunEvent)
        {
            var scoutState = WCMApplicationDirector.Instance.GameStates.CurrentState as ScoutingState;
            if (scoutState != null)
            {
                // Still in scouting state.
                return;
            }

            var battleData = battleBegunEvent.AttackData.AttackTargetData.DefendingPlayer.BattleData;
            if (battleData == null)
            {
                return;
            }

            // Do not apply bombardment to any campaign missions, which will include WMAP NUX
            if ((battleData.ZoneActorType & ZoneActorType.Campaign) != 0)
            {
                return;
            }

            var artilleryPlatoon = battleBegunEvent.AttackData.ArtilleryPlatoon;
            if (artilleryPlatoon == null)
            {
                return;
            }

            Squad bombardmentSquad = null;
            foreach (var squad in artilleryPlatoon.Squads)
            {
                if (squad.UnitId == UnitTypeConstant.Bombardment)
                {
                    bombardmentSquad = squad;
                    break;
                }
            }

            Met = (bombardmentSquad != null);
            if (Met && _logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("SSConditionOnAttackedWithBombardment condition met");
            }
        }

        #endregion
    }
}

