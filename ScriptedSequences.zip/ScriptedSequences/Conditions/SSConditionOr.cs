﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOr : SSConditionLogicalOperatorBase
    {
        #region Public Properties
        /// <summary>
        /// Whether this condition is currently met.
        /// </summary>
        public override bool Met
        {
            get
            {
                foreach (var condition in Conditions)
                {
                    if (condition.Met)
                    {
                        return true;
                    }
                }
                return false;
            }         
        }
        #endregion Public Properties
    }
}
