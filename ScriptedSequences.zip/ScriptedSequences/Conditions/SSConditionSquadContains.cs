using System;
using GameTypes;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameData;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// A condition that is met when a given squad contains a certain ammount of a certain
    /// type of unit.
    /// </summary>
    [Serializable]
    public class SSConditionSquadContains : ScriptedSequenceCondition
    {

        /// <summary>
        /// The application player manager.
        /// </summary>
        [Inject]
        private PlayerManager _players { get ; set; }

        /// <summary>
        /// The application event manager.
        /// </summary>
        [Inject]
        private EventManager _events { get; set; }

        private bool _handlersRegistered = false;

        // skip 3

        /// <summary>
        /// The ammount of units of the given type the squad should contain.
        /// </summary>
        [JsonProperty("Quantity")]
        [ProtoMember(4)]
        public int Quantity;

        /// <summary>
        /// The squad which needs to contain the units.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(5)]
        public SquadDesignator Designator
        {
            get { return _designator; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _designator = new SquadDesignator();

        /// <summary>
        /// If any squad can fulfil the condition, or just a specific squad can.
        /// </summary>
        [JsonProperty("AnySquad")]
        [ProtoMember(6)]
        public bool AnySquad;

        /// <summary>
        /// Condition will met if squad contains the exact number or units.
        /// </summary>
        [JsonProperty("EqualCompare")]
        [ProtoMember(7)]
        public bool EqualCompare;

        /// <summary>
        /// If any active (not in storage) squad can fulfil the condition, or just a specific squad can.
        /// </summary>
        [JsonProperty("AnyNonStorageSquad")]
        [ProtoMember(8)]
        public bool AnyNonStorageSquad;

        /// <summary>
        /// The id of unit the squad should contain.
        /// </summary>
        [JsonProperty("UnitId")]
        [ProtoMember(9)]
        public int UnitId;

        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionSquadContains));

        public SSConditionSquadContains ()
        {
        }

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                if (Designator.PlayerOwningSquad == SquadDesignator.PlayerOwner.Local)
                                {
                                    if (_players.LocalPlayer != null)
                                    {
                                        HandleLocalPlayerLoaded(_players.LocalPlayer);
                                    }
                                    _events.AddEventHandler<PlayersOnLocalPlayerSetEvent>(HandleLocalPlayerLoaded);
                                }
                                else
                                {
                                    _events.AddEventHandler<BattleBegunEvent>(HandleBattleBegun);
                                    _events.AddEventHandler<BattleEndedEvent>(HandleBattleEnded);
                                }

                                _events.AddEventHandler<UnitAddedToSquadEvent>(HandleUnitAddedToSquad);
                                _events.AddEventHandler<UnitRemovedFromSquadEvent>(HandleUnitRemovedFromSquad);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                if (Designator.PlayerOwningSquad == SquadDesignator.PlayerOwner.Local)
                                {
                                    _events.RemoveEventHandler<PlayersOnLocalPlayerSetEvent>(HandleLocalPlayerLoaded);
                                }
                                else
                                {
                                    _events.RemoveEventHandler<BattleBegunEvent>(HandleBattleBegun);
                                    _events.RemoveEventHandler<BattleEndedEvent>(HandleBattleEnded);
                                }

                                _events.RemoveEventHandler<UnitAddedToSquadEvent>(HandleUnitAddedToSquad);
                                _events.RemoveEventHandler<UnitRemovedFromSquadEvent>(HandleUnitRemovedFromSquad);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the action.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this action.</param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            // Set the unit type to search in storage platoon.
            Designator.StorageUnitType = UnitId;

            if (_players == null)
            {
                return;
            }

            if (!Enabled)
            {
                return;
            }

            if (!_handlersRegistered)
            {
                if (Designator.PlayerOwningSquad == SquadDesignator.PlayerOwner.Local)
                {
                    if (_players.LocalPlayer != null)
                    {
                        HandleLocalPlayerLoaded(_players.LocalPlayer);
                    }
                    _events.AddEventHandler<PlayersOnLocalPlayerSetEvent>(HandleLocalPlayerLoaded);
                }
                else
                {
                    _events.AddEventHandler<BattleBegunEvent>(HandleBattleBegun);
                    _events.AddEventHandler<BattleEndedEvent>(HandleBattleEnded);
                }

                _events.AddEventHandler<UnitAddedToSquadEvent>(HandleUnitAddedToSquad);
                _events.AddEventHandler<UnitRemovedFromSquadEvent>(HandleUnitRemovedFromSquad);
                _handlersRegistered = true;
            }
            // Initial check of all squads.
            UpdateConditionForAllSquads();
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }
            UpdateConditionForAllSquads();
        }

        private void HandleLocalPlayerLoaded(PlayersOnLocalPlayerSetEvent eventData)
        {
            HandleLocalPlayerLoaded(eventData.LocalPlayer);
        }

        /// Handles the local player loaded.
        /// </summary>
        /// <param name="localPlayer">The new local player.</param>
        private void HandleLocalPlayerLoaded(Player player)
        {
            UpdateConditionForPlayer(player);
        }

        /// <summary>
        /// Handles the battle begining.
        /// </summary>
        private void HandleBattleBegun(BattleBegunEvent battleEvent)
        {
            UpdateConditionForAllSquads();
        }

        /// <summary>
        /// Handles the battle ending.
        /// </summary>
        private void HandleBattleEnded(BattleEndedEvent battleEvent)
        {
            UpdateConditionForAllSquads();
        }

        /// <summary>
        /// Handles a unit being added to a squad.
        /// </summary>
        private void HandleUnitAddedToSquad(UnitAddedToSquadEvent squadEvent)
        {
            Evaluate(); // with introduction of "any squad / any unit" option,
                        // it's important to check all squads to see if condition is still met or not.
        }

        /// <summary>
        /// Handles a unit being removed from a squad.
        /// </summary>
        /// <param name="squadEvent">Squad event.</param>
        private void HandleUnitRemovedFromSquad(UnitRemovedFromSquadEvent squadEvent)
        {
            Evaluate(); // with introduction of "any squad / any unit" option,
                        // it's important to check all squads to see if condition is still met or not.
        }

        /// <summary>
        /// Updates if the condition has been met for the given squad.
        /// </summary>
        /// <param name="squad">Squad to check.</param>
        private bool UpdateConditionForSquad(Squad squad)
        {
            if (!Enabled)
            {
                return false;
            }
            else if (AnyNonStorageSquad && (squad.Platoon.PlatoonType == PlatoonType.Storage))
            {
                return false;
            }
            else if (!AnyNonStorageSquad && !AnySquad && !Designator.IsSquad(squad))
            {
                return false;
            }

            List<Unit> units = squad.Units;
            int targetUnitCount = 0;
            for (int i = 0, count = units.Count; i < count; ++i)
            {
                if(units[i].UnitId == UnitId || UnitId == UnitTypeConstant.ANY_UNIT_TYPE)
                {
                    ++targetUnitCount;
                }
            }

            if (EqualCompare)
            {
                return (targetUnitCount == Quantity);
            }
            else
            {
                return (targetUnitCount >= Quantity);
            }
        }

        /// <summary>
        /// Updates if the condition has been met for all squads contained by the
        /// given player.
        /// </summary>
        /// <param name="player">Player to check.</param>
        private bool UpdateConditionForPlayer(Player player)
        {
            if (!Enabled || player == null)
            {
                return false;
            }

            List<Platoon> platoons = player.Army.Platoons.ToList();
            platoons.Add(player.ActiveBase.StoragePlatoon);
            bool result = false;
            for (int platoonIndex = 0, platoonCount = platoons.Count; platoonIndex < platoonCount; ++platoonIndex)
            {
                if (platoons[platoonIndex] != null)
                {
                    List<Squad> squads = platoons[platoonIndex].Squads;
                    for (int squadIndex = 0, squadCount = squads.Count; squadIndex < squadCount; ++squadIndex)
                    {
                        result |= UpdateConditionForSquad(squads[squadIndex]);
                    }
                } else {
                    _logger.Warn(null, "{0}: Null platoon in player {1} at index {2}.", GetDebugNameFull(), player.Name, platoonIndex);
                }
            }

            return result;
        }

        /// <summary>
        /// Updates if the condition has been met for all squads in all palyers.
        /// </summary>
        private void UpdateConditionForAllSquads()
        {
            bool result = UpdateConditionForPlayer(_players.LocalPlayer) || UpdateConditionForPlayer(_players.OpponentPlayer);

            if (Met != result)
            {
                Met = result;
            }
        }
    }
}

