﻿using System;
using Kixeye.Common.StateMachine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionWorldMapBasePinAvailable : ScriptedSequenceCondition
    {
        #region Serialized properties
        
        /// <summary>
        /// Whether the condition is met when a metal deposit is available
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Metal")]
        [ProtoMember(3)]
        public bool Metal;

        /// <summary>
        /// Whether the condition is met when a thorium deposit is available
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Thorium")]
        [ProtoMember(4)]
        public bool Thorium;
        
        /// <summary>
        /// Whether the condition is met when a rival base is available
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Rival")]
        [ProtoMember(5)]
        public bool Rival;

        /// <summary>
        /// Whether the condition is met when a revenge is available
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Revenge")]
        [ProtoMember(6)]
        public bool Revenge;
        
        #endregion
        
        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<WorldMapBaseInfoUpdatedEvent>(OnWMBaseInfoUpdated);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<WorldMapBaseInfoUpdatedEvent>(OnWMBaseInfoUpdated);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        private WCMGameStateController _gameStates
        {
            get;
            set;
        }

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<WorldMapBaseInfoUpdatedEvent>(OnWMBaseInfoUpdated);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }

        #endregion
        
        #region Private methods

        /// <summary>
        /// Called when base objects are updated.
        /// </summary>
        private void OnWMBaseInfoUpdated(WorldMapBaseInfoUpdatedEvent evt)
        {
            Met = ( Metal && (evt.MetalDepositsCount > 0) ) ||
                  ( Thorium && (evt.ThoriumDepositsCount  > 0) ) ||
                  ( Rival && (evt.UncoveredRegularBasesCount  > 0) ) ||
                  ( Revenge && (evt.UncoveredRevengeBasesCount  > 0) );
        }

        #endregion
    }
}

