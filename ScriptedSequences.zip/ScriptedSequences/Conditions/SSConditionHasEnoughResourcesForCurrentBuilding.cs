using System;
using GameTypes;
using GameTypes.GameDefinitions;
using Kixeye.Core.Logging;
using Kixeye.WCM.Events;
using Kixeye.WCM.ui;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionHasEnoughResourcesForCurrentBuilding : ScriptedSequenceCondition
    {
        #region Private variables
        
        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        /// <summary>
        /// The game's ui controller
        /// </summary>
        [Inject]
        public UIController UI { private get; set; }

        /// <summary>
        /// Flag that specifies if we should ignore events or not.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("IgnoreEvents")]
        [ProtoMember(6)]
        public bool IgnoreEvents = false;

        private bool _handlersRegistered = false;
        
        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionHasEnoughResourcesForCurrentBuilding));

        #endregion

        #region Public properties

        // Sets the enabled state of the condition. Registeres/Unregisteres event handlers.
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && !IgnoreEvents)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        
        #endregion
        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && !IgnoreEvents)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
            if (localPlayer == null)
            {
                return;
            }
            
            // Find out what building is selected in the panel
            PanelBase currentPanel = UI.CurrentPanel;

            var buildingSSUI = currentPanel as SSUI_Building_Construction;
            if (buildingSSUI == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn(null, "{0}: Unexpected current panel: {1}", GetDebugNameFull(), currentPanel);
                }
                return;
            }

            if (buildingSSUI.Panel == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn(null, "{0}: No active SSUI panel: {1}", GetDebugNameFull(), buildingSSUI);
                }
                return;
            }

            BuildingType buildingType = buildingSSUI.Panel.SelectedBuildingType;

            var gameData = WCMApplicationDirector.Instance.GameData;

            BuildingDefinition definition = gameData.GetBuildingDefinition(buildingType, 1);

            long currentLevel = localPlayer.Resources.GetAmountByType(ResourceType.Metal);

            Met = currentLevel >= definition.r1;
        }
        
        #endregion
        
        #region Private methods

        private void OnResourcesChange( GameResourceChangedEvent resourceChangeEvent )
        {
            Evaluate();
        }

        #endregion
    }
}
