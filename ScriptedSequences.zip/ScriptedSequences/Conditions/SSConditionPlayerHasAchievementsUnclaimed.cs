﻿using System;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionPlayerHasAchievementsUnclaimed : ScriptedSequenceCondition
    {
        private EventManager Events
        {
            get
            {
                if(WCMApplicationDirector.Instance != null)
                {
                    return WCMApplicationDirector.Instance.Events;
                }

                return null;
            }
        }

        private Player LocalPlayer
        {
            get
            {
                if (WCMApplicationDirector.Instance != null
                    && WCMApplicationDirector.Instance.Players != null)
                {
                    return WCMApplicationDirector.Instance.Players.LocalPlayer;
                }

                return null;
            }
        }

        private bool _handlersRegistered = false;

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (Events != null)
                    {
                        if (IsInitialized())
                        {
                            SetHandlers(value);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetHandlers(true);
            }
        }

        /// <summary>
        /// Evaluate if the condition is met.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = LocalPlayer.Achievements.TotalUnclaimed > 0;
        }

        /// <summary>
        /// Turns event handlers for building destruction on or off
        /// </summary>
        /// <param name="turnOn"></param>
        private void SetHandlers(bool turnOn)
        {
            if (WCMApplicationDirector.Instance == null
                || Events == null
                || LocalPlayer == null)
            {
                return;
            }

            if (turnOn)
            {
                if (!_handlersRegistered)
                {
                    Events.AddEventHandler<AchievementsUpdatedEvent>(HandleAchievementUpdate);
                }
            }
            else
            {
                if (_handlersRegistered)
                {
                    Events.RemoveEventHandler<AchievementsUpdatedEvent>(HandleAchievementUpdate);
                }
            }
            _handlersRegistered = turnOn;
        }

        private void HandleAchievementUpdate(AchievementsUpdatedEvent eventData)
        {
            if (LocalPlayer != null)
            {
                Met = LocalPlayer.Achievements.TotalUnclaimed > 0;
            }
        }

        public override string GetDebugName()
        {
            return "Player has achievement unclaimed";
        }
    }
}