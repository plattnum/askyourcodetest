using System;
using System.Collections.Generic;
using System.ComponentModel;
using ProtoBuf;
using UnityEngine;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    /// The base class for a condition in a Scripted Sequence.  All condition classes should derive from this.
    [JsonObject(MemberSerialization.OptIn)]
    public class ScriptedSequenceCondition : ScriptedSequenceComponent
    {
        [JsonProperty("DoNotEvaluateOnEnable")]
        [ProtoMember(1000)] // 1000 is arbitrarily high to avoid collision with subclass fields.
        [DefaultValue(false)] // Avoid adding this confusing entry to every condition in the JSON.
        public bool DoNotEvaluateOnEnable; // Because many subclasses are marked "SkipConstructor" it is impossible to have properties with non-default initial values.

        public bool EvaluateOnEnable
        {
            get { return !DoNotEvaluateOnEnable; }
            set { DoNotEvaluateOnEnable = !value; }
        }

        #region public properties
        /// <summary>
        /// Whether this condition is currently met.
        /// </summary>
        private bool _met = false;
        public virtual bool Met
        {
            get { return _met; }
            set
            {
                if (_met != value)
                {
                    _met = value;

                    LogDebug("Changing Met to {0}", _met);

                    // inform the parent node
                    if (Parent == null)
                    {
                        LogError("No parent on status change.");
                    }
                    else
                    {
                        Parent.OnConditionMetChanged(this);
                    }

                    // inform anyone else who cares
                    if (ConditionMetChanged != null)
                    {
                        ConditionMetChanged(this, value);
                    }
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected virtual void Evaluate()
        {
        }

        /// <summary>
        /// Resets the condition to its starting state
        /// </summary>
        public virtual void Reset()
        {
            _met = false;
        }

        /// <summary>
        /// This condition will only check for its completion conditions (and can only be met) if this is true.
        /// </summary>
        private bool _enabled = false;
        public virtual bool Enabcled
        {
            get { return _enabled; }
            set
            {
                _enabled = value;

                if (value && EvaluateOnEnable)
                {
                    // evaluate the 'Met' state when the condition is enabled
                    Evaluate();
                }
            }
        }

        public Action<ScriptedSequenceCondition, bool> ConditionMetChanged;
        #endregion
    }
}

