using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionAchievementClaimed : SSConditionPlayerDataQuery
    {
        [Inject]
        protected new EventManager _events
        {
            get
            {
                return base._events;    
            }
            set
            {
                base._events = value;
            }
        }

        #region Serialized properties
        /// <summary>
        /// The (zero-based) index of the Mission within the specified faction
        /// </summary>
        [Newtonsoft.Json.JsonProperty("AchievementId")] 
        [ProtoMember(3)]
        public int AchievementId;
        #endregion

        #region method overrides

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            if (LocalPlayer != null && LocalPlayer.Data != null)
            {                
                Met = LocalPlayer.Data.Achievements.ClaimedAchievements.Contains(AchievementId);            
            }
        }

        #endregion
    }
}
