using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionUIPanelOpen : ScriptedSequenceCondition
    {
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionUIPanelOpen));

        #region Serialized properties

        /// <summary>
        /// The name of the Panel game object to listen for an open event.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("PanelName")]
        [ProtoMember(3)]
        public string PanelName;

        [Newtonsoft.Json.JsonProperty("WaitForOnPanelOpenEvent")]
        [ProtoMember(4)]
        public bool WaitForOnPanelOpenEvent;
        
        #endregion
        
        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<VisiblePanelChangedEvent>(OnPanelOpen);
                                _events.RemoveEventHandler<PopupController.EventPopupOpen>(OnPartialPanelOpen);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<VisiblePanelChangedEvent>(OnPanelOpen);
                                _events.AddEventHandler<PopupController.EventPopupOpen>(OnPartialPanelOpen);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<VisiblePanelChangedEvent>(OnPanelOpen);
                    _events.AddEventHandler<PopupController.EventPopupOpen>(OnPartialPanelOpen);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (WaitForOnPanelOpenEvent || !IsInitialized() || !Enabled)
            {
                return;
            }

            GameObject gameObject = GameObject.Find(PanelName);
            if (gameObject != null && gameObject.activeInHierarchy)
            {
                Met = true;
                return;
            }
            
            gameObject = GameObject.Find(PanelName + "(Clone)");
            if (gameObject != null && gameObject.activeInHierarchy)
            {
                Met = true;
                return;
            }
        }
        #endregion
        
        #region Private methods
        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnPanelOpen( VisiblePanelChangedEvent panelEvent )
        {
            if (Enabled)
            {
                if (panelEvent.PanelNowInvisible != null && _logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("Panel now invisible: '" + panelEvent.PanelNowInvisible.name + "'; waiting for '" + PanelName + "'");
                }

                if (panelEvent.PanelNowVisible != null && _logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("Panel now visible: '" + panelEvent.PanelNowVisible.name + "'; waiting for '" + PanelName + "'");
                }

                // let's detect if the panel was actually closed (and some other panel was open)
                if (panelEvent.PanelNowInvisible != null
                    && (panelEvent.PanelNowInvisible.name == PanelName || panelEvent.PanelNowInvisible.name == PanelName + "(Clone)")
                   )
                {
                    Met = false;
                    return;
                }

                if (panelEvent.PanelNowVisible != null &&
                    (panelEvent.PanelNowVisible.gameObject == GameObject.Find(PanelName) ||
                     panelEvent.PanelNowVisible.gameObject == GameObject.Find(PanelName + "(Clone)")))
                    // Lame.  TODO: Replace this with tags
                {
                    Met = true;
                }
            }
        }

        private void OnPartialPanelOpen(PopupController.EventPopupOpen panelEvent)
        {
            if (Enabled)
            {
                // let's detect if the panel was actually closed (and some other panel was open)
                if (panelEvent.WidgetNowInvisible != null
                    &&
                    (panelEvent.WidgetNowInvisible.name == PanelName ||
                     panelEvent.WidgetNowInvisible.name == PanelName + "(Clone)")
                    )
                {
                    Met = false;
                    return;
                }

                if (panelEvent.WidgetNowVisible != null &&
                    (panelEvent.WidgetNowVisible.gameObject == GameObject.Find(PanelName) ||
                     panelEvent.WidgetNowVisible.gameObject == GameObject.Find(PanelName + "(Clone)")))
                    // Lame.  TODO: Replace this with tags
                {
                    Met = true;
                }
            }
        }

        #endregion
    }
}

