using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionSquadSelected : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToSelect")]
        [ProtoMember(3)]
        public SquadDesignator SquadToSelect = new SquadDesignator();
        
        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;
        #endregion
        
        #region Public properties

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            if (value)
                            {
                                if (!_handlersRegistered)
                                {
                                    //Add event handler
                                    _events.AddEventHandler<SquadSelectedEvent>(OnSquadSelectionChange);
                                    _handlersRegistered = true;
                                }
                            }
                            else
                            {
                                if (_handlersRegistered)
                                {
                                    // remove the event handler
                                    _events.RemoveEventHandler<SquadSelectedEvent>(OnSquadSelectionChange);
                                    _handlersRegistered = false;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        #endregion
        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );
            
            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<SquadSelectedEvent>(OnSquadSelectionChange);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met |= WCMApplicationDirector.Instance.PlayerInput.SelectedSquads.Contains(SquadToSelect.GetSquad());
        }
        
        #endregion
        
        #region Private methods
        
        private void OnSquadSelectionChange( SquadSelectedEvent squadSelectedEvent )
        {
            if (Enabled)
            {
                if (SquadToSelect.IsSquad(squadSelectedEvent.Squad))
                {
                    Met = true;
                    return;
                }

                Met = false;
            }
        }
        
        #endregion
    }
}

