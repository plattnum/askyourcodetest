using System;
using Kixeye.WCM.Events;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using Kixeye.WCM.ui;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using UnityEngine.UI;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionPressButton : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// [DEPRECATED] The name of the button game object to listen for a press.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ButtonName")]
        [ProtoMember(3)]
        public string ButtonName;

        /// <summary>
        /// The button game object to listen for a press.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Button")]
        [ProtoMember(4)]
        public UIElementDesignator ButtonDesignator = new UIElementDesignator();

        #endregion
        
        #region Public properties
        
        /// <summary>
        /// The game's event manager
        /// </summary>
        [Inject]
        public EventManager _events
        {
            private get; 
            set;
        }

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public properties
        
        // Override the base class enabled so we can add or remove a click handler when enabled state changes
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (IsInitialized())
                    {
                        SetHandler(value);
                    }
                }
            }
        }
        
        #endregion
        
        #region Public methods

        /// <summary>
        /// Sets up the condition.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            // version the old style that just had a button name
            if (!String.IsNullOrEmpty(ButtonName))
            {
                ButtonDesignator.TypeOfDesignation = UIElementDesignator.DesignationType.ByName;
                ButtonDesignator.ElementName = ButtonName.Replace('.', '/');        // replace analytics-style dot separator with Unity slash separator
                ButtonName = null;
            }

            if (Enabled)
            {
                SetHandler(true);
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }
        
        #endregion
        
        #region private methods

        private void SetUnitCardEventHandler(bool enabled)
        {
            GameObject button = ButtonDesignator.GetUIElement();
            if (button == null)
            {
                return;
            }

            UIElementTag buttonTag = button.GetComponent<UIElementTag>();

            if (buttonTag == null || buttonTag.Tags == null )
            {
                return;
            }


            //new crafting
            CraftingItemCardController unitCard = button.GetComponentInParent<CraftingItemCardController>();
            if ( unitCard != null )
            {
                if (enabled)
                {
                    unitCard.onPointerUp.AddListener(HandleUnitCardClicked);
                }
                else
                {
                    unitCard.onPointerUp.RemoveListener(HandleUnitCardClicked);
                }
            }

            
        }

        private void SetHandler(bool enabled)
        {
            if (ButtonDesignator.TypeOfDesignation == UIElementDesignator.DesignationType.ByTag)
            {
                if (enabled)
                {
                    if (!_handlersRegistered)
                    {
                        _events.AddEventHandler<ScriptedSequenceUIElementEvent>(OnUIElementEvent);
                        SetUnitCardEventHandler(true);
                        _handlersRegistered = true;
                    }
                }
                else
                {
                    if (_handlersRegistered)
                    {
                        _events.RemoveEventHandler<ScriptedSequenceUIElementEvent>(OnUIElementEvent);
                        SetUnitCardEventHandler(false);
                        _handlersRegistered = false;
                    }
                }
            }
            else
            {
                GameObject button = ButtonDesignator.GetUIElement();
                if (button == null)
                {
                    Log.Error( this, "No button found for " + GetDebugNameFull() );
                    return;
                }

                // Add an NGUI event listener if it is an NGUI control, or
                // a UGUI event listener if it is a UGUI control.
                var uguiButton = button.GetComponent<Button>();
                if (uguiButton != null)
                {
                    if (enabled)
                    {
                        if (!_handlersRegistered)
                        {
                            uguiButton.onClick.AddListener(OnButtonClicked);
                            _handlersRegistered = true;
                        }
                    }
                    else
                    {
                        if (_handlersRegistered)
                        {
                            uguiButton.onClick.RemoveListener(OnButtonClicked);
                            _handlersRegistered = false;
                        }
                    }
                }
            }
        }

        private void OnUIElementEvent( ScriptedSequenceUIElementEvent evt )
        {
            if (evt.Type == ScriptedSequenceUIElementEvent.EventType.Pressed &&
                ButtonDesignator.IsCorrectUIElement(evt.Element))
            {
                Met = true;
            }
        }

        private void OnButtonClicked()
        {
            if (Enabled)
            {
                this.Met = true;
            }
        }

        private void HandleUnitCardClicked(bool pressed)
        {
            OnButtonClicked();
        }

        #endregion
    }
}

