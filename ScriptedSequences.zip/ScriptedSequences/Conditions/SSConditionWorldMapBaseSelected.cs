﻿using System;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionWorldMapBaseSelected : ScriptedSequenceCondition
    {
        public enum BaseType
        {
            PlayerBase,
            Deposit,
        }

        [Newtonsoft.Json.JsonProperty("TypeOfBase")]
        [ProtoMember(3)]
        public BaseType TypeOfBase;

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<WorldMapBaseSelectedEvent>(OnBaseSelected);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<WorldMapBaseSelectedEvent>(OnBaseSelected);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered;

        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<WorldMapBaseSelectedEvent>(OnBaseSelected);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }

        private void OnBaseSelected( WorldMapBaseSelectedEvent baseEvent )
        {
        }
    }
}

