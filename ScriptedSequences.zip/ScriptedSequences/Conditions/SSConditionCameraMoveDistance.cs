﻿using System;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using UnityEngine;
using Kixeye.WCM.Input;
using Kixeye.WCM.Events;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionCameraMoveDistance : ScriptedSequenceCondition
    {
        public enum MovementType
        {
            Pan,
            Zoom,
        }

        #region Serialized properties

        /// <summary>
        /// How far the user must pan the camera to meet the condition.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("PanDistance")]
        [ProtoMember(3)]
        public float PanDistance;

        /// <summary>
        /// How far the user must zoom the camera to meet the condition.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ZoomDistance")]
        [ProtoMember(4)]
        public float ZoomDistance;
        
        /// <summary>
        /// Which type of camera movement to track
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TypeOfMovement")]
        [ProtoMember(5)]
        public MovementType TypeOfMovement = MovementType.Pan;
        
        #endregion    

        #region Private properties

        /// <summary>
        /// The position the camera is looking at when we start tracking.
        /// </summary>
        private Vector3 _startingLookAtPosition;

        /// <summary>
        /// The zoom the camera is at when we start tracking.
        /// </summary>
        private float _startingZoom;

        private float _panDistanceSquared;

        private bool _handlersRegistered = false;

        #endregion

        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (value)
                {
                    WCMCameraController camera = WCMApplicationDirector.Instance.Camera;
                    if (camera != null)
                    {
                        _startingLookAtPosition = camera.LookAtPosition;
                        _startingZoom = camera.Zoom;
                    }
                }
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                }
                InitializeCallbacks();
            }
        }
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            _panDistanceSquared = PanDistance * PanDistance;

            InitializeCallbacks();
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            WCMCameraController camera = WCMApplicationDirector.Instance.Camera;
            if (camera == null)
            {
                Log.Error( this, "Camera not found during Camera callback." );
                return;
            }

            if (TypeOfMovement == MovementType.Pan)
            {
                Vector3 delta = camera.LookAtPosition - _startingLookAtPosition;
                if (delta.sqrMagnitude > _panDistanceSquared)
                {
                    Log.Error(this, "Camera pan from " + camera.LookAtPosition + " to " + _startingLookAtPosition + " meets condition.");
                    Met = true;
                }
            }
            else if (TypeOfMovement == MovementType.Zoom)
            {
                float delta = Mathf.Abs( camera.Zoom - _startingZoom );
                if (delta > ZoomDistance)
                {
                    Met = true;
                }
            }
        }
        #endregion

        #region Private methods

        /// <summary>
        /// Called when the camera is done interpolating
        /// </summary>
        private void OnCameraMove()
        {
            Evaluate();
        }

        /// <summary>
        /// Called when setting up or shutting down the condition to set callbacks to the camera.
        /// </summary>
        private void InitializeCallbacks()
        {
            WCMCameraController camera = WCMApplicationDirector.Instance.Camera;
            if (camera != null)
            {
                if (Enabled)
                {
                    if (!_handlersRegistered)
                    {
                        camera.InterpolateEnded += OnCameraMove;
                        camera.CameraMoved += OnCameraMove;
                    }
                    _handlersRegistered = true;
                }
                else
                {
                    if (_handlersRegistered)
                    {
                        camera.InterpolateEnded -= OnCameraMove;
                        camera.CameraMoved -= OnCameraMove;
                        _handlersRegistered = false;
                    }
                }
            }
        }

        #endregion 
    }
}
