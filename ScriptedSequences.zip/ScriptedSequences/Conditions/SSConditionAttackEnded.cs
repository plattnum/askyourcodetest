using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;
using GameTypes;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionAttackEnded : ScriptedSequenceCondition
    {
        #region Serialized properties

        public enum AttackEndedNotificationType
        {   
            WON_QUICKMATCH,
            LOST_QUICKMATCH,
            WON_REVENGE,
            LOST_REVENGE,
            DESTROYED_WORLDMAP,
            WON_WORLDMAP,
            LOST_WORLDMAP      
        };

        [Newtonsoft.Json.JsonProperty("AttackEndedResult")]
        [ProtoMember(1)]
        public AttackEndedNotificationType AttackEndedResult;

        #endregion
        
        #region Private variables

        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<NotificationEvent>(HandleNotificationEvent);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<NotificationEvent>(HandleNotificationEvent);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this action.</param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<NotificationEvent>(HandleNotificationEvent);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate() { }

        private void HandleNotificationEvent(NotificationEvent notification)
        {
            var attackNotificationData = notification.Notification as AttackEndedNotificationData;
            Met = false;
            if (attackNotificationData != null)
            {
                var attackLog = attackNotificationData.AttackLog;

                if (attackLog != null)
                {
                    bool victory = attackLog.Stars == 0;

                    switch (attackLog.AttackType)
                    {
                        case AttackType.Matchmaking:
                            if( (victory && AttackEndedResult == AttackEndedNotificationType.WON_QUICKMATCH) ||
                                (!victory && AttackEndedResult == AttackEndedNotificationType.LOST_QUICKMATCH))
                            {
                                Met = true;
                            }       
                            return;
                        case AttackType.Revenge:
                            if( (victory && AttackEndedResult == AttackEndedNotificationType.WON_REVENGE) ||
                                (!victory && AttackEndedResult == AttackEndedNotificationType.LOST_REVENGE))
                            {
                                Met = true;   
                            }
                            return;
                        case AttackType.WorldMap:
                            if (attackLog.ZoneActorType == ZoneActorType.Headquarters && !victory && AttackEndedResult == AttackEndedNotificationType.DESTROYED_WORLDMAP)
                            {
                                Met = true;
                            }
                            else if((victory && AttackEndedResult == AttackEndedNotificationType.WON_WORLDMAP) ||
                                    (!victory && AttackEndedResult == AttackEndedNotificationType.LOST_WORLDMAP))
                            {
                                Met = true;
                            }
                            return;
                    }
                }
            }
        }
    }
}

