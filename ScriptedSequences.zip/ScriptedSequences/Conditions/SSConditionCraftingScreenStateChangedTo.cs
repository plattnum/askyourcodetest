using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;
using GameTypes;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionCraftingScreenStateChangedTo : ScriptedSequenceCondition
    {
        #region Serialized properties
        [Newtonsoft.Json.JsonProperty("TabOpened")]
        [ProtoMember(1)]
        public TabsView.CraftingScreenTab TabOpened;

        [Newtonsoft.Json.JsonProperty("SegmentOpened")]
        [ProtoMember(2)]
        public SegmentsView.CraftingScreenUnitSegment SegmentOpened;

        [Newtonsoft.Json.JsonProperty("PlatoonSelectedIdx")]
        [ProtoMember(3)]
        public int PlatoonSelectedIdx;
        #endregion

        #region Private variables
        [Inject]
        private EventManager _events { get; set; }
        private bool _handlersRegistered = false;
        #endregion

        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                _events.RemoveEventHandler<CraftingScreenStateChangedEvent>(HandleNotificationEvent);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                _events.AddEventHandler<CraftingScreenStateChangedEvent>(HandleNotificationEvent);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition, attach handler to react to Crafting Screen events.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this action.</param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    _events.AddEventHandler<CraftingScreenStateChangedEvent>(HandleNotificationEvent);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the Met state of the condition.
        /// </summary>
        protected override void Evaluate() { }

        private void HandleNotificationEvent(CraftingScreenStateChangedEvent craftingScreenEvent)
        {
            Met = (craftingScreenEvent.PlatoonSelected != null
                   && !craftingScreenEvent.PlatoonSelected.IsDefensiveWavesPlatoon
                   && !craftingScreenEvent.PlatoonSelected.IsDefendingPlatoon
                   && craftingScreenEvent.PlatoonSelected.PlatoonIndex == this.PlatoonSelectedIdx
                   && craftingScreenEvent.TabOpened == this.TabOpened
                   && craftingScreenEvent.SegmentOpened == this.SegmentOpened);
        }
    }
}