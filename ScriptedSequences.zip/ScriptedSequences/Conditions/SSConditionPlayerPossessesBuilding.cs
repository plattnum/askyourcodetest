﻿using System;
using ProtoBuf;
using UnityEngine;
using System.Collections.Generic;
using Kixeye.WCM.GameData;
using Ninject;
using Kixeye.WCM.Events;
using System.ComponentModel;
using GameTypes;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionPlayerPossessesBuilding : ScriptedSequenceCondition
    {
        #region Serialized properties
        /// <summary>
        /// The building that player's expected to possess
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BuildingType")]
        [ProtoMember(3)]
        public BuildingType BuildingType;

        /// <summary>
        /// Minimum level of the building
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MinimumBuildingLevel")]
        [ProtoMember(4)]
        public int MinimumBuildingLevel;

        [Newtonsoft.Json.JsonProperty("DoNotWaitForUpgradeAnimation")]
        [ProtoMember(5)]
        public bool DoNotWaitForUpgradeAnimation;

        [Newtonsoft.Json.JsonProperty("IsCheckTurretEquip")]
        [ProtoMember(6)]
        public bool IsCheckTurretEquip;
        #endregion

        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            SetHandlers(value);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetHandlers(true);
            }
        }

        /// <summary>
        /// Evaluate if the condition is met.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = IsBuildingInActiveBase();
        }

        /// <summary>
        /// Turns event handlers for building destruction on or off
        /// </summary>
        /// <param name="turnOn"></param>
        private void SetHandlers(bool turnOn)
        {
            //We start checking conditions before the player is loaded (during the loading scren) 
            //early out and hopefully it will fire again
            if (WCMApplicationDirector.Instance.PlayerProcessor == null)
                return;

            if (turnOn)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<UpgradeCompleteEvent>(OnUpgradeCompleteEvent);
                    _events.AddEventHandler<PlayerDataProcessorNewBuildingAddedEvent>(NewBuildingAdded);
                    _events.AddEventHandler<PlayerDataProcessorBuildingUpgradedEvent>(BuildingUpgraded);
                }
            }
            else
            {
                if (_handlersRegistered)
                {
                    // remove the event handler
                    _events.RemoveEventHandler<UpgradeCompleteEvent>(OnUpgradeCompleteEvent);
                    _events.RemoveEventHandler<PlayerDataProcessorNewBuildingAddedEvent>(NewBuildingAdded);
                    _events.RemoveEventHandler<PlayerDataProcessorBuildingUpgradedEvent>(BuildingUpgraded);
                }
            }
            _handlersRegistered = turnOn;
        }

        private void NewBuildingAdded(PlayerDataProcessorNewBuildingAddedEvent eventData)
        {
            if (eventData.BuildingData != null)
            {
                Met = IsBuildingInActiveBase();
            }
        }

        private void BuildingUpgraded(PlayerDataProcessorBuildingUpgradedEvent eventData) // pre-scaffold animation
        {
            if (DoNotWaitForUpgradeAnimation)
            {
                Met = IsBuildingInActiveBase();
            }
        }

        private void OnUpgradeCompleteEvent(UpgradeCompleteEvent upgradeEvent) // post-scaffold animation
        {
            if (!DoNotWaitForUpgradeAnimation)
            {
                Met = IsBuildingInActiveBase();
            }
        }

        private bool IsBuildingInActiveBase()
        {
            if (WCMApplicationDirector.Instance.Players.LocalPlayer == null || WCMApplicationDirector.Instance.Players.LocalPlayer.ActiveBase == null)
            {
                return false;
            }

            var building = WCMApplicationDirector.Instance.Players.LocalPlayer.ActiveBase.GetBuildingByType(BuildingType);
            if (building != null
                && building.GetData() != null
                && building.GetData().Type == BuildingType
                && building.GetData().Level >= MinimumBuildingLevel)
            {
                if (BuildingType == BuildingType.TowerPlatform && IsCheckTurretEquip)
                {
                    // We check TowerPlatform not TowerPlatform with equipped turret.
                    return !building.HasTurret;
                }
                return true;
            }
            return false;
        }

        public override string GetDebugName()
        {
            return "Player possesses the building: "
                + BuildingType.ToString() 
                + ", level " + MinimumBuildingLevel + " [or higher]";
        }
    }
}