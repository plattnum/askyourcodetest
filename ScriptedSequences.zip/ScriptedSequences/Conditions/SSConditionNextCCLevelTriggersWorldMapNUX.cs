﻿using System;
using ProtoBuf;
using UnityEngine;
using System.Collections.Generic;
using Kixeye.WCM.GameData;
using Ninject;
using Kixeye.WCM.Events;
using System.ComponentModel;
using GameTypes;
using GameTypes.GameDefinitions;
using Kixeye.Core.Logging;
using Model;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionNextCCLevelTriggersWorldMapNUX : ScriptedSequenceCondition
    {
        #region Serialized properties
        
        /// <summary>
        /// The building that player's expected to possess
        /// </summary>
        [Newtonsoft.Json.JsonProperty("CheckNextCCLevel")]
        [ProtoMember(3)]
        public bool CheckNextCCLevel;
        
        #endregion
        
        [Inject]
        private WCMGameDataManager _gameData {get; set;}

        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;
        private int _targetCCLevel = 0;        

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            SetHandlers(value);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetHandlers(true);
            }

            // verify the pre-req for global ops 1, the current trigger for World Map NUX
            BuildingDefinition definition = _gameData.GetBuildingDefinition(BuildingType.GlobalOperations, 1);
            if (definition != null)
            {
                string[] requirements = definition.re.Split(';');
                for (int eachRequirement = 0; eachRequirement < requirements.Length; eachRequirement++)
                {
                    int progressionLevel;
                    if (BuildingDefinition.ParsePlayerProgressionRequirement(requirements[eachRequirement], out progressionLevel))
                    {
                        // we are only interested in Command Center requirements for this condition
                        continue;
                    }

                    int buildingType, buildingLevel;
                    if (BuildingDefinition.ParseBuildingRequirement(requirements[eachRequirement], out buildingType, out buildingLevel))
                    {
                        if ((BuildingType)buildingType == BuildingType.CommandCenter)
                        {
                            _targetCCLevel = buildingLevel;                            
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Turns event handlers for building events on or off
        /// </summary>
        /// <param name="turnOn"></param>
        private void SetHandlers(bool turnOn)
        {
            //We start checking conditions before the player is loaded (during the loading scren) 
            //early out and hopefully it will fire again
            if (WCMApplicationDirector.Instance.PlayerProcessor == null)
                return;

            if (turnOn)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<PlayerDataProcessorBuildingUpgradedEvent>(BuildingUpgraded);
                }
            }
            else
            {
                if (_handlersRegistered)
                {
                    // remove the event handler
                    _events.RemoveEventHandler<PlayerDataProcessorBuildingUpgradedEvent>(BuildingUpgraded);
                }
            }
            _handlersRegistered = turnOn;
        }
        
        private void BuildingUpgraded(PlayerDataProcessorBuildingUpgradedEvent eventData) // pre-scaffold animation
        {
            Met = IsCCLevelTargetHit();
        }
        
        /// <summary>
        /// Evaluate if the condition is met.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled || _targetCCLevel == 0)
            {
                return;
            }
            
            if (WCMApplicationDirector.Instance == null
                || WCMApplicationDirector.Instance.Players == null
                || WCMApplicationDirector.Instance.Players.LocalPlayer == null)
            {
                return;
            }

            Met = IsCCLevelTargetHit();
        }

        private bool IsCCLevelTargetHit()
        {
            var building = WCMApplicationDirector.Instance.Players.LocalPlayer.ActiveBase.GetBuildingByType(BuildingType.CommandCenter);
            if (building != null
                && building.GetData() != null
                && building.GetData().Type == BuildingType.CommandCenter
                && building.GetData().Level == _targetCCLevel)
            {
                return true;
            }
            else
            {
                return false;
            }            
        }
        
        public override string GetDebugName()
        {
            return "See if current Command Center Level will trigger WMNUX";
        }
    }
}