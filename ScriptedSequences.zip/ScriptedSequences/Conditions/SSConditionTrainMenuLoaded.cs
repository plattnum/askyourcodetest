﻿using System;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;
using UnityEngine;
using UnityEngine.UI;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionTrainMenuLoaded : ScriptedSequenceCondition
    {
        #region Private Fields

        private bool _handlersRegistered;

        #endregion

        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<TrainMenuLoadedEvent>(OnTrainMenuLoaded);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<TrainMenuLoadedEvent>(OnTrainMenuLoaded);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<TrainMenuLoadedEvent>(OnTrainMenuLoaded);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }
            
            PanelBase currentPanel = WCMApplicationDirector.Instance.UI.CurrentPanel;
            if (currentPanel == null || (currentPanel as SSUI_Unit_Crafting) == null)
            {
                return;
            }

            // gdavis - WCM-39705 - this condition is no longer used but this class remains. So I'm commenting this out as it is just terrible. If someone wants to use this SS condition they
            // will need to refactor this code so it works efficiently.
//            foreach (Button button in GameObject.FindObjectsOfType<Button>())
//            {
//                if (button.name == "TrainButton" && button.isActiveAndEnabled)
//                {
//                    Met = true;
//                }
//            }
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Called whenever the train menu gets loaded.
        /// </summary>
        private void OnTrainMenuLoaded(TrainMenuLoadedEvent evt)
        {
            if (Enabled)
            {
                if (evt.Opened)
                {                    
                    Met = true;
                }
                else
                {                    
                    Met = false;
                }
            }
        }



        #endregion
    }
}

