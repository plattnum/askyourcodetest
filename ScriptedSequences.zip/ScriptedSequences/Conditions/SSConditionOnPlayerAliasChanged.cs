﻿using System;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnPlayerAliasChanged : ScriptedSequenceCondition
    {
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<LocalPlayerNameChangedEvent>(OnPlayerAliasChange);
                    _events.AddEventHandler<DefaultPlayerNameAcceptedEvent>(OoDefaultPlayerNameAccepted);
                    _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            if (WCMApplicationDirector.Instance != null &&
                    WCMApplicationDirector.Instance.Players != null &&
                    WCMApplicationDirector.Instance.Players.LocalPlayer != null &&
                    WCMApplicationDirector.Instance.Players.LocalPlayer.Data.PlayerDetails.SkipRenameOffer)
            {
                Met = true;
                return;
            }
        }

        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            if (value)
                            {
                                if (!_handlersRegistered)
                                {
                                    //Add event handler
                                    _events.AddEventHandler<LocalPlayerNameChangedEvent>(OnPlayerAliasChange);
                                    _events.AddEventHandler<DefaultPlayerNameAcceptedEvent>(OoDefaultPlayerNameAccepted);
                                    _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                    _handlersRegistered = true;
                                }
                            }
                            else
                            {
                                if (_handlersRegistered)
                                {
                                    // remove the event handler
                                    _events.RemoveEventHandler<LocalPlayerNameChangedEvent>(OnPlayerAliasChange);
                                    _events.RemoveEventHandler<DefaultPlayerNameAcceptedEvent>(OoDefaultPlayerNameAccepted);
                                    _events.RemoveEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                    _handlersRegistered = false;
                                }
                            }
                        }
                    }
                }
                Evaluate();
            }
        }

        private void OnPlayerAliasChange( LocalPlayerNameChangedEvent playerAliasChangeEvent )
        {
            if (Enabled)
            {
                Met = true;
            }
        }

        private void OoDefaultPlayerNameAccepted (DefaultPlayerNameAcceptedEvent defaultPlayerNameAcceptedEvent)
        {
            if (Enabled)
            {
                Met = true;
            }
        }

        private void OnGameStateChange( GameStateChangeEvent playerAliasChangeEvent )
        {
            // handling game state change messages was the easiest way I could fine to
            // ensure that we properly set the Met condition prior to the user gettign to WM
            if (Enabled && !Met)
            {
                Evaluate();
            }
        }
    }
}

