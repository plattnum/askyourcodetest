using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using System.ComponentModel;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionSequenceCompleted : ScriptedSequenceCondition
    {
        #region Serialized properties
        [Newtonsoft.Json.JsonProperty("Sequence Name")]
        [ProtoMember(3)]        
        public string SequenceName;

        #endregion

        [Inject]
        private EventManager _events {get; set;}

        private bool _linkDone = false;   // set once we have successfully linked in the sequence check for completion on

        #region Public methods

        public override string GetDebugName()
        {
            string name = "Sequence Complete";
            if (!string.IsNullOrEmpty(SequenceName))
            {
                name += ": " + SequenceName;
            }
            return name;
        }

        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );
            ScriptedSequencesController ssController = WCMApplicationDirector.Instance.ScriptedSequences;
            ssController.AllSequencesLoaded += OnAllSequencesLoaded;
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (IsInitialized() && Enabled)
            {
                var met = WCMApplicationDirector.Instance.ScriptedSequences.GetSequenceCompletionCountByName(SequenceName) > 0;
                if (met)
                {
                    LogComplete();
                }
                Met = met;
            }
        }

        #endregion

        #region Private methods
        private void OnObservedSequenceCompleted(int completionCount)
        {
            if (Enabled && completionCount > 0)
            {
                LogComplete();
                Met = true;
            }
        }

        private void LogComplete()
        {
            LogDebug("Condition met, {0} completed.", SequenceName);
        }

        private void OnGameStateChange( GameStateChangeEvent gameStateChangeEvent )
        {
            // we handle this event as a safe way to get at sequence completion data at a time
            // when we know player data has been loaded
            Evaluate();
        }

        private void OnAllSequencesLoaded()
        {
            if (!_linkDone)
            {
                ScriptedSequencesController ssController = WCMApplicationDirector.Instance.ScriptedSequences;
                ScriptedSequence sequence = ssController.GetSequenceByName(SequenceName);

                if (sequence == null)
                {
                    LogError("Sequence not found: {0}", SequenceName);
                }
                else
                {
                    sequence.SequenceCompleted += OnObservedSequenceCompleted;
                }
                
                _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                _linkDone = true;    
            }
        }

        #endregion
    }
}

