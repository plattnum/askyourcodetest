﻿using System;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;
using WorldMap.ChannelMessages;
using System.Linq;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionWorldMapActorUpdate : ScriptedSequenceCondition
    {
        [Newtonsoft.Json.JsonProperty("HexDesignator")]
        [ProtoMember(3)]
        public HexDesignator HexDesignator
        {
            get
            {
                if (_hexDesignator == null)
                {
                    _hexDesignator = HexDesignator.Alloc();
                }
                return _hexDesignator;
            }
            set { _hexDesignator = value; }
        }

        [UnityEngine.SerializeField]
        private HexDesignator _hexDesignator = default;

        [Newtonsoft.Json.JsonProperty("UpdateReason")]
        [ProtoMember(4)]
        public ZoneActorUpdate.ZoneActorUpdateReason UpdateReasons = ZoneActorUpdate.ZoneActorUpdateReason.Any;

        /// <summary>
        /// If true, the state of the world will be checked every time <see cref="ScriptedSequenceCondition.Met"/>
        /// is invoked instead of only on state change.  This allows AND 
        /// conditions to work as expected regardless of what order event 
        /// handlers are invoked.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("AlwaysCheckCurrentState")]
        [ProtoMember(5)]
        public bool AlwaysCheckCurrentState;

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            saver.Save(HexDesignator);
            saver.Save(this);
#endif
        }

        public override string GetDebugName()
        {
            var result = "World Map Actor";
            switch (UpdateReasons)
            {
                case ZoneActorUpdate.ZoneActorUpdateReason.None:
                    break;
                case ZoneActorUpdate.ZoneActorUpdateReason.Any:
                    result += " Changed";
                    break;
                default:
                    result += " " + UpdateReasons;
                    break;
            }
            result += ": " + HexDesignator.GetDebugName();
            return result;
        }

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<MessageChannelEvent<ZoneActorUpdate>>(HandleZoneActorUpdate);
                                _events.RemoveEventHandler<ZoneActorUpdateClientSideOnly>(HandleZoneActorUpdateClientOnly);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<MessageChannelEvent<ZoneActorUpdate>>(HandleZoneActorUpdate);
                                _events.AddEventHandler<ZoneActorUpdateClientSideOnly>(HandleZoneActorUpdateClientOnly);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// The application's event manager.
        /// </summary>
        [Inject]
        private EventManager _events { get; set; }

        /// <summary>
        /// The worldmap controller.
        /// </summary>
        [Inject]
        public WorldMapController _worldMap { get; private set; }

        /// <summary>
        /// The game's player manager
        /// </summary>
        [Inject]
        public PlayerManager _players { get; private set; }

        private bool _handlersRegistered = false;

        public override bool Met
        {
            get
            {
                if (AlwaysCheckCurrentState)
                {
                    return CheckCurrentState();
                }
                return base.Met;
            }
            set { base.Met = value; }
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<ZoneActorUpdateClientSideOnly>(HandleZoneActorUpdateClientOnly);
                    _events.AddEventHandler<MessageChannelEvent<ZoneActorUpdate>>(HandleZoneActorUpdate);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!EvaluateOnEnable || !IsInitialized() || !Enabled)
            {
                return;
            }

            Met = CheckCurrentState();
        }

        private bool CheckCurrentState()
        {
            ZoneActorUpdate za = new ZoneActorUpdate()
            {
                UpdatedActors = _worldMap.OwnActors.ToArray(),
            };
            return CheckZoneActorUpdate(za, false);
        }

        private void HandleZoneActorUpdate(MessageChannelEvent<ZoneActorUpdate> messageEvent)
        {
            Met = CheckZoneActorUpdate(messageEvent.Value);
        }

        private void HandleZoneActorUpdateClientOnly(ZoneActorUpdateClientSideOnly clientEvent)
        {
            if (UpdateReasons != ZoneActorUpdate.ZoneActorUpdateReason.None)
            {
                if (0 == (UpdateReasons & clientEvent.Value.UpdateReason))
                {
                    // Failed update reason check.
                    Met = false;
                    return;
                }
            }
            var targetActor = clientEvent.Value.ActorInfo;
            Met = HexDesignator.CheckConditionsForHex(targetActor, targetActor.HexCell.WorldPosition, _worldMap, _players);
        }

        private bool CheckZoneActorUpdate(ZoneActorUpdate zoneActorUpdate, bool checkUpdateReasons = true)
        {
            bool met;
            if (checkUpdateReasons && UpdateReasons != ZoneActorUpdate.ZoneActorUpdateReason.None)
            {
                if (0 == (UpdateReasons & zoneActorUpdate.Reason))
                {
                    // Failed update reason check.
                    return false;
                }
            }

            var deletedActors = zoneActorUpdate.DeletedActors;
            var updatedActors = zoneActorUpdate.UpdatedActors;

            if (!deletedActors.IsNullOrEmpty())
            {
                foreach (var actor in deletedActors)
                {
                    met = HexDesignator.CheckConditionsForHex(actor, actor.HexCell.WorldPosition, _worldMap, _players);
                    if (met)
                    {
                        return true;
                    }
                }
            }

            if (!updatedActors.IsNullOrEmpty())
            {
                foreach (var actor in updatedActors)
                {
                    met = HexDesignator.CheckConditionsForHex(actor, actor.HexCell.WorldPosition, _worldMap, _players);
                    if (met)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }



    public class ZoneActorUpdateClientSideOnly : SingletonEvent<ZoneActorUpdateClientSideOnly, ZoneActorUpdateClientSideOnlyData>
    {
    }

    public class ZoneActorUpdateClientSideOnlyData
    {
        public ZoneActorInfo ActorInfo;
        public ZoneActorUpdate.ZoneActorUpdateReason UpdateReason;
    }
}

