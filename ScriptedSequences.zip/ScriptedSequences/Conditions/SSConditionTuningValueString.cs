using System;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameData;
using GameTypes.GameDefinitions;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionTuningValueString : ScriptedSequenceCondition
    {
        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionTuningValueString));

        private bool _handlersRegistered = false;

        #region Serialized properties
        [Newtonsoft.Json.JsonProperty("TuningDefinition")]
        [ProtoMember(1)]        
        public TuningDefinitionType TuningDefinition;

        [Newtonsoft.Json.JsonProperty("Operator")]
        [ProtoMember(2)]
        public OperatorType Operator;

        [Newtonsoft.Json.JsonProperty("Value")]
        [ProtoMember(3)]
        public string Value;

        #endregion

        #region Injected properties
        [Inject]
        private WCMGameDataManager _gameData {get; set;}

        [Inject]
        protected virtual EventManager _events {get; set;}
        #endregion

        #region Public properties
        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Public methods
        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (Enabled &&
                _events != null &&                
                !_handlersRegistered)
            {
                _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                _handlersRegistered = true;
            }
        }
        #endregion

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            // we don't want this condition to be triggered until the PlayerProcessor is initialized
            if (IsInitialized() && Enabled && WCMApplicationDirector.Instance.PlayerProcessor != null)
            {
                if (!Met)
                {
                    string tuningValue = _gameData.TuningStringValue(TuningDefinition);
                    switch (Operator)
                    {
                        case OperatorType.Equals:
                            Met = tuningValue == Value;
                            break;
                        case OperatorType.NotEqual:
                            Met = tuningValue != Value;
                            break;
                        case OperatorType.GreaterThan:
                            Met = string.CompareOrdinal(tuningValue, Value) > 0;
                            break;
                        case OperatorType.GreaterThanOrEquals:
                            Met = string.CompareOrdinal(tuningValue, Value) >= 0;
                            break;
                        case OperatorType.LessThan:
                            Met = string.CompareOrdinal(tuningValue, Value) < 0;
                            break;
                        case OperatorType.LessThanOrEquals:
                            Met = string.CompareOrdinal(tuningValue, Value) <= 0;
                            break;
                        case OperatorType.Contains:
                            Met = tuningValue.Contains(Value);
                            break;
                        default:
                            Met = false;
                            _logger.Error("Operator type {0} not supported".FormatWith(Operator));
                            break;
                    }

                    if (Met)
                    {
                        _logger.Debug(null, "Float comparison condition for tuning {0} met.", TuningDefinition);
                    }
                }
            }
        }

        #region Private methods
        private void OnGameStateChange( GameStateChangeEvent gameStateChangeEvent )
        {
            Evaluate();
        }


        #endregion
    }
}

