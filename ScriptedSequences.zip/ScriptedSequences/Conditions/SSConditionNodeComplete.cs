using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using System.ComponentModel;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionNodeComplete : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("NodeID")]
        [ProtoMember(3),DefaultValue(-1)]
        public int NodeID = -1;

        private ScriptedSequenceNode _node;

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            if (_node != null)
            {
                return "On Node Complete: " + _node.GetDebugNameFull();
            }
            else
            {
                return base.GetDebugName();
            }
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            _node = ScriptedSequence.GetNodeByID(NodeID);
            if (_node != null)
            {
                _node.OnAllActionsComplete += OnOtherNodeComplete;
            }
            else
            {
                LogError("NodeID " + NodeID + " was not found.");
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled  || _node == null)
            {
                return;
            }
            Met = _node.AllActionsComplete;
        }

        #endregion

        #region Private methods
        private void OnOtherNodeComplete(ScriptedSequenceNode node, bool allConditionsMet)
        {
            if (Enabled)
            {
                Met = allConditionsMet;
            }
            else if (allConditionsMet)
            {
                LogDebug("Other node completed when this one isn't enabled: {0}", node);
            }
        }
        #endregion
    }
}

