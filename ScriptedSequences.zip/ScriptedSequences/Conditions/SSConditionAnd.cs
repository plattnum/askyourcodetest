﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionAnd : SSConditionLogicalOperatorBase
    {
        #region Public properties

        /// <summary>
        /// Whether this condition is currently met.
        /// </summary>
        public override bool Met
        {
            get
            {
                foreach (var condition in Conditions)
                {
                    if (!condition.Met)
                    {
                        return false;
                    }
                }
                return true;
            }
        }

        #endregion Public Properties
    }
}
