﻿using System;
using ProtoBuf;
using UnityEngine;
using System.Collections.Generic;
using Kixeye.WCM.GameData;
using Ninject;
using Kixeye.WCM.Events;
using System.ComponentModel;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionBuildingDamaged : ScriptedSequenceCondition
    {
        #region Serialized properties
        
        /// <summary>
        /// The building that needs to be destroyed to satisfy this condition.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BuildingDamaged")]
        [ProtoMember(3)]
        public BuildingDesignator BuildingDamaged = new BuildingDesignator();

        /// <summary>
        /// The percent of full health below which the condition will be triggered.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ThresholdPct")]
        [ProtoMember(4), DefaultValue(1.0f)]
        public float ThresholdPct = 1.0f;
        
        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion

        #region Public properties

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            SetHandlers(value);
                        }
                    }
                }
            }
        }

        #endregion
    
        #region Public methods
        
        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetHandlers(true);
            }
        }

        /// <summary>
        /// Evaluate if the condition is met.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            foreach (Building checkBuilding in BuildingDamaged.GetBuildings())
            {
                float health = (checkBuilding.Health / checkBuilding.MaxHealth);
                if (health == 0f || health < ThresholdPct)
                {
                    Met = true;
                    return;
                }
            }
        }
        #endregion
        
        #region Private methods
    
        /// <summary>
        /// Called when a building has been destroyed so we can see if it's the one we care about
        /// </summary>
        /// <param name="buildingEvent">Building event.</param>
        private void HandleBuildingDamaged( BuildingDamagedEvent buildingEvent )
        {
            if (Enabled)
            {
                foreach (Building checkBuilding in BuildingDamaged.GetBuildings())
                {
                    if (buildingEvent.DamagedBuilding == checkBuilding)
                    {
                        float health = (buildingEvent.DamagedBuilding.Health / buildingEvent.DamagedBuilding.MaxHealth);

                        if (health == 0f || health < ThresholdPct)
                        {
                            Met = true;
                        }
                        else
                        {
                            Met = false;
                        }
                        break;
                    }
                }
            }
        }
        
        /// <summary>
        /// Handles the battle begining by clearing this condition (the building hasn't been destroyed yet)
        /// </summary>
        private void HandleBattleBegun(BattleBegunEvent battleEvent)
        {
            if (Enabled)
            {
                Met = false;
            }
        }

        /// <summary>
        /// Turns event handlers for building destruction on or off
        /// </summary>
        /// <param name="turnOn"></param>
        private void SetHandlers(bool turnOn)
        {
            if (turnOn)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BuildingDamagedEvent>(HandleBuildingDamaged);
                    _events.AddEventHandler<BattleBegunEvent>(HandleBattleBegun);
                }
            }
            else
            {
                if (_handlersRegistered)
                {
                    // remove the event handler
                    _events.RemoveEventHandler<BuildingDamagedEvent>(HandleBuildingDamaged);
                    _events.RemoveEventHandler<BattleBegunEvent>(HandleBattleBegun);
                }
            }
            _handlersRegistered = turnOn;
        }
        
        #endregion
    }
}

