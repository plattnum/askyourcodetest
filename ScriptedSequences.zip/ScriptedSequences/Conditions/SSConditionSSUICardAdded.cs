using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionSSUICardAdded : ScriptedSequenceCondition
    {
        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionObjectivePanelEntryUpdated));
        #region Serialized properties
        
        /// <summary>
        /// The name of the Panel game object to listen for an open event.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("CardId")]
        [ProtoMember(3)]
        public int CardId;
        
        [Newtonsoft.Json.JsonProperty("CardType")]
        [ProtoMember(4)]
        public GameCardType CardType;

        #endregion
        
        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<SSUICardAddedEvent>(OnCardAdded);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<SSUICardAddedEvent>(OnCardAdded);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );
            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<SSUICardAddedEvent>(OnCardAdded);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnCardAdded( SSUICardAddedEvent cardAddedEvent )
        {
            _logger.Debug(null, "SSConditionObjectivePanelEntryUpdated::OnCardAdded = {0} CardType = {1}", cardAddedEvent.CardId, CardType);
            if (Enabled)
            {
                if (cardAddedEvent.CardId == CardId && cardAddedEvent.CardType == CardType)
                {
                    Met = true;
                }
            }
        }

        
        #endregion
    }
}

