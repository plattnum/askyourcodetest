using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;
using Kixeye.WCM.WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnGameStateTransitionCompleted : ScriptedSequenceCondition, ISerializationCallbackReceiver
    {

        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("GameState")]
        [ProtoMember(3)]
        public SSActionLoadGameState.GameStateEnum GameState;

        [Newtonsoft.Json.JsonProperty("CheckForZoneLoaded")]
        [ProtoMember(4)]
        public bool CheckForZoneLoaded;

        ////[Newtonsoft.Json.JsonProperty("UseNuxZone")]
        ////[ProtoMember(5)]
        ////public bool UseNuxZone;

        [Obsolete]
        [Newtonsoft.Json.JsonProperty("ZoneId")]
        [ProtoMember(6)]
        public SSActionLoadGameState.PermanentZones? ZoneId;

        [Newtonsoft.Json.JsonProperty("ZoneDefinitionId")]
        [ProtoMember(7)]
        public int ZoneDefinitionId;

        #endregion


        #region Unity Serialization Support

        [Serializable]
        public class NullablePermanentZones: NullableSerialization<SSActionLoadGameState.PermanentZones>
        {
        }

        [SerializeField]
        protected NullablePermanentZones _zoneId;

#pragma warning disable 0618, 0612 // deprecated field
        public void OnBeforeSerialize()
        {
            _zoneId = new NullablePermanentZones
            {
                Value = ZoneId,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_zoneId != null)
            {
                ZoneId = _zoneId.Value;
            }
            _zoneId = null;
        }
#pragma warning restore 0618, 0612 // deprecated field

        #endregion

        #region Public properties

        public override void Migrate(bool onCreate)
        {
            base.Migrate(onCreate);
#pragma warning disable 0618, 0612 // deprecated field
            if (ZoneId.HasValue)
            {
                ZoneDefinitionId = (int)ZoneId.Value;
                ZoneId = null;
            }
#pragma warning restore 0618, 0612 // deprecated field
        }

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                base.Enabled = value;
                UpdateEventRegistration();
            }
        }

        private void UpdateEventRegistration()
        {
            if (_events == null) return; // In editor, maybe?
            if (_handlersRegistered == Enabled) return;
            if (Enabled)
            {
                _events.AddEventHandler<GameStateTransitionProgressEvent>(OnStateTransitionComplete);
            }
            else
            {
                _events.RemoveEventHandler<GameStateTransitionProgressEvent>(OnStateTransitionComplete);
            }
            _handlersRegistered = Enabled;
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        private WCMGameStateController _gameStates { get; set; }

        /// <summary>
        /// Player Management
        /// </summary>
        [Inject]
        public PlayerManager _players { get; private set; }

        private bool _handlersRegistered = false;

        #endregion

        #region Public methods

        public override string GetDebugName()
        {
            var gameState = GameState.ToString();
            if (GameState == SSActionLoadGameState.GameStateEnum.WorldMapState)
            {
                if (CheckForZoneLoaded)
                {
                    gameState += " (" + ZoneDefinitionId + ")";
                }
            }
            if (EvaluateOnEnable)
            {
                return "Already in {0} or transition to {1} Complete".FormatWith(gameState, GameState);
            }
            else
            {
                return "Transition to {0} Complete".FormatWith(gameState);
            }
        }

        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);
            UpdateEventRegistration();
        }

        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = IsDesiredStateAndZone(_gameStates.CurrentState);
        }

        #endregion

        #region Private methods

        private void OnStateTransitionComplete(GameStateTransitionProgressEvent stateEvent)
        {
            if (stateEvent.IsStateTransitionCompleted)
            {
                Evaluate();
            }
        }

        private bool IsDesiredStateAndZone(IState state)
        {
            switch (GameState)
            {
                case SSActionLoadGameState.GameStateEnum.BaseManagement:
                    return state is BaseManagementState;

                case SSActionLoadGameState.GameStateEnum.ScoutingState:
                    return state is ScoutingState;

                case SSActionLoadGameState.GameStateEnum.WorldMapState:
                {
                    var worldMapState = state as WorldMapState;
                    if (worldMapState != null)
                    {
                        bool isCorrectZone = true;
                        if (CheckForZoneLoaded)
                        {
                            var currentZone = worldMapState.Controller.CurrentZone;
                            if (currentZone == null)
                            {
                                isCorrectZone = false;
                            }
                            else
                            {
                                isCorrectZone = currentZone.Definition.ZoneDefinitionId == ZoneDefinitionId;
                            }
                        }
                        // If a transition is in progress we'll get an event
                        // when it is actually done.  The transition becomes
                        // active at the same moment WorldMapState is entered.
                        return worldMapState.StateTransitionComplete && isCorrectZone;
                    }
                    return false;
                }

                default:
                    Log.Error(this, "Unsupported Game State: " + GameState);
                    return false;
            }
        }

        #endregion
    }
}

