using System;
using UnityEngine;
using Kixeye.WCM.Input;
using Kixeye.WCM.Events;
using Ninject;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionTargetSelected : ScriptedSequenceCondition
    {
        public enum SelectType
        {
            Building,
            Squad,
        }

        #region Serialized properties

        /// <summary>
        /// Whether we're looking for an enemy building or squad to be targeted.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("TargetSelectType")]
        [ProtoMember(3)]
        public SelectType TargetSelectType;

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadTargeted")]
        [ProtoMember(4)]
        public SquadDesignator SquadTargeted = new SquadDesignator();
        
        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BuildingTargeted")]
        [ProtoMember(5)]
        public BuildingDesignator BuildingTargeted = new BuildingDesignator();
        
        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;
        
        #endregion
        
        #region Public properties
        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<SquadOrderedToAttackEvent>(OnSquadOrderedToAttackEvent);
                                _handlersRegistered = true;
                            }

                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<SquadOrderedToAttackEvent>(OnSquadOrderedToAttackEvent);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        
        #endregion

        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );
            
            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<SquadOrderedToAttackEvent>(OnSquadOrderedToAttackEvent);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            if (TargetSelectType == SelectType.Building)
            {
                foreach (Building building in BuildingTargeted.GetBuildings())
                {
                    if (building.IsSelected)
                    {
                        Met = true;
                        return;
                    }
                }
            }
            else if (TargetSelectType == SelectType.Squad)
            {
                Met |= WCMApplicationDirector.Instance.PlayerInput.SelectedSquads.Contains(SquadTargeted.GetSquad());
                return;
            }
        }

        #endregion

        #region private methods

        /// <summary>
        /// Invoked when the user selects a hostile unit or building with a squad selected
        /// </summary>
        private void OnSquadOrderedToAttackEvent(SquadOrderedToAttackEvent squadOrderedToAttackEvent)
        {
            if (TargetSelectType == SelectType.Building)
            {
                Building targetBuilding = squadOrderedToAttackEvent.Target as Building;
                if (targetBuilding != null)
                {
                    foreach( Building bldg in BuildingTargeted.GetBuildings())
                    {
                        if (bldg == targetBuilding)
                        {
                            Met = true;
                            return;
                        }
                    }
                }
            }
            else if (TargetSelectType == SelectType.Squad)
            {
                Squad targetedSquad = SquadTargeted.GetSquad();
                if (squadOrderedToAttackEvent.Target.GameItemId == targetedSquad.GameItemId)
                {
                    Met = true;
                    return;
                }
            }

            Met = false;
        }

        #endregion
    }
}

