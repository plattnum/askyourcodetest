using System;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameData;
using GameTypes.GameDefinitions;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionTuningValueSet : ScriptedSequenceCondition
    {
        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionTuningValueSet));

        private bool _handlersRegistered = false;

        #region Serialized properties
        [Newtonsoft.Json.JsonProperty("TuningDefinition")]
        [ProtoMember(3)]        
        public TuningDefinitionType TuningDefinition;

        #endregion

        #region Injected properties
        [Inject]
        private WCMGameDataManager _gameData {get; set;}

        [Inject]
        protected virtual EventManager _events {get; set;}
        #endregion

        #region Public properties
        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<GameStateChangeEvent>(OnGameStateChange);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Public methods
        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (Enabled &&
                _events != null &&                
                !_handlersRegistered)
            {
                _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChange);
                _handlersRegistered = true;
            }
        }
        #endregion

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            // we don't want this condition to be triggered until the PlayerProcessor is initialized
            if (IsInitialized() && Enabled && WCMApplicationDirector.Instance.PlayerProcessor != null)
            {
                if (!Met)
                {
                    Met = _gameData.TuningValue(TuningDefinition) > 0;
                    if (Met)
                    {
                        _logger.Debug(null, "SSConditionTuningValueSet::OnGameStateChange tuning value {0} is set to non-zero.", TuningDefinition);
                    }
                }
            }
        }

        #region Private methods
        private void OnGameStateChange( GameStateChangeEvent gameStateChangeEvent )
        {
            Evaluate();
        }


        #endregion
    }
}

