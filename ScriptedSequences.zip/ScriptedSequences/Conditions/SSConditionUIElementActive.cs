﻿using System;
using System.Collections.Generic;
using Kixeye.WCM.Events;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionUIElementActive : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The button game object to listen for a press.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Designator")]
        [ProtoMember(3)]
        public UIElementDesignator Designator = new UIElementDesignator();

        /// <summary>
        /// If true, condition is met when element is disabled
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Invert")]
        [ProtoMember(4)]
        public bool Invert;

        [Newtonsoft.Json.JsonProperty("Completed Animation")]
        [ProtoMember(5)]
        public bool FinishedAnimation;

        #endregion
        
        #region Public properties
        
        /// <summary>
        /// The game's event manager
        /// </summary>
        [Inject]
        public EventManager _events
        {
            private get; 
            set;
        }

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public properties
        
        // Override the base class enabled so we can add or remove a click handler when enabled state changes
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (IsInitialized())
                    {
                        SetHandler(value);
                    }
                }
            }
        }
        
        #endregion
        
        #region Public methods

        public override string GetDebugName()
        {
            if (EvaluateOnEnable)
            {
                return (Invert ? "UI Element Inactive: " : "UI Element Active: ") + Designator.GetDescription(brief: true);
            }
            else
            {
                return (Invert ? "UI Element Deactivated: " : "UI Element Activated: ") + Designator.GetDescription(brief: true);
            }
        }

        /// <summary>
        /// Sets up the condition.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (Enabled)
            {
                SetHandler(true);
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            IEnumerable<GameObject> elements = Designator.GetUIElements();
            foreach (var element in elements)
            {
                if (element.activeInHierarchy)
                {
                    if (FinishedAnimation)
                    {
                        //check if the element is animating
                        var animatorComp = element.GetComponent<Animator>();
                        if (animatorComp != null && animatorComp.GetCurrentAnimatorStateInfo(0).normalizedTime > 1 &&
                            !animatorComp.IsInTransition(0))
                        {
                            continue;
                        }

                        var cam = WCMApplicationDirector.Instance.UI.CameraForUI;
                        if (cam)
                        {
                            Vector3 screenPoint = cam.WorldToViewportPoint(element.transform.position);
                            //check if on screen
                            if (!(screenPoint.z > 0 && screenPoint.x > 0 && screenPoint.x < 1 && screenPoint.y > 0 &&
                                  screenPoint.y < 1))
                            {
                                //off screen
                                continue;
                            }
                        }
                    }

                    Met |= !Invert;
                    return;
                }
            }

            
        }

        #endregion

        #region private methods

        private void SetHandler(bool enabled)
        {
            if (Designator.TypeOfDesignation == UIElementDesignator.DesignationType.ByTag)
            {
                if (enabled)
                {
                    if (!_handlersRegistered)
                    {
                        _events.AddEventHandler<ScriptedSequenceUIElementEvent>(OnUIElementEvent);
                    }
                }
                else
                {
                    if (_handlersRegistered)
                    {
                        _events.RemoveEventHandler<ScriptedSequenceUIElementEvent>(OnUIElementEvent);
                    }
                }
            }
            _handlersRegistered = enabled;
        }

        private void OnUIElementEvent( ScriptedSequenceUIElementEvent evt )
        {
            if (Designator.IsCorrectUIElement(evt.Element))
            {
                if (evt.Type == ScriptedSequenceUIElementEvent.EventType.Activated)
                {
                    Met = !Invert;
                }
                else if (evt.Type == ScriptedSequenceUIElementEvent.EventType.Deactivated)
                {
                    Met = Invert;
                }
            }
        }

        #endregion
    }
}

