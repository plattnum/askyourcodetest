using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.WCM.Pve;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnMissionScouted : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The map name for the attacked mission.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MapName")]
        [ProtoMember(3)]
        public string MapName;

        #endregion

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        private bool _handlersRegistered = false;
        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionOnMissionScouted));

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BaseLoadedEvent>(OnGameStateChanged);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BaseLoadedEvent>(OnGameStateChanged);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        public override string GetDebugName()
        {
            return "Mission Scouted: " + (MapName ?? "?");
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BaseLoadedEvent>(OnGameStateChanged);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = false;

            // condition met as soon as the state is Scouting, map name matches, and the coresponding mission allows sequences
            if (!(WCMApplicationDirector.Instance.GameStates.CurrentState is ScoutingState))
            {
                return;
            }

            if (!string.IsNullOrEmpty(MapName))
            {
                string currentLevelName = WCMApplicationDirector.Instance.SpawnManager.CurrentLevelName ?? string.Empty;
                if (string.Compare(currentLevelName, MapName, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    // Wrong map name
                    return;
                }

                PveCampaignProgress campaignProgress = WCMApplicationDirector.Instance.Players.LocalPlayer.PveCampaignProgress;
                if ((campaignProgress != null) && (campaignProgress.RFBaseDefinition != null) && !campaignProgress.RFBaseDefinition.allowSequences)
                {
                    // This campaign mission disallows sequences
                    return;
                }
            }

            // If there is no map set, then we'll allow this sequence (without campaign filtering)
            Met = true;
        }

        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnGameStateChanged(BaseLoadedEvent baseLoadedEvent)
        {
            Evaluate();
            if (Met && _logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug("OnMissionScouted condition met on map '" + MapName + "'");
            }
        }
    }
}

