using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;  
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    [ProtoInclude(1001, typeof(SSConditionAchievementClaimed))] 
    [ProtoInclude(1002, typeof(SSConditionPlatoonsEverModified))] 

    public abstract class SSConditionPlayerDataQuery : ScriptedSequenceCondition
    {

        #region Private variables

        private bool _handlersRegistered = false;

        private Player _localPlayer = null;

        #endregion

        #region Protected variables

        [Inject]
        protected virtual EventManager _events {get; set;}

        protected Player LocalPlayer
        {
            get { return _localPlayer; }
            set { _localPlayer = value; }
        }

        #endregion

        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                base.Enabled = value; 
                if (_events != null)
                {
                    if (value)
                    {
                        if (!_handlersRegistered)
                        {
                            //Add event handler
                            _events.AddEventHandler<PlayersOnLocalPlayerSetEvent>(OnLocalPlayerSet);
                            
                            _handlersRegistered = true;
                        }
                    }
                    else
                    {
                        if (_handlersRegistered)
                        {
                            // remove the event handler
                            _events.RemoveEventHandler<PlayersOnLocalPlayerSetEvent>(OnLocalPlayerSet);
                            _handlersRegistered = false;
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (_events != null)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<PlayersOnLocalPlayerSetEvent>(OnLocalPlayerSet);
                    _handlersRegistered = true;
                }
            }
        }

        #endregion

        #region abstract interface

        #endregion

        #region Private methods

        private void OnLocalPlayerSet(PlayersOnLocalPlayerSetEvent eventData)
        {
            // our initial implementation here is specifically targeted at
            // detecting conditions in player data at startup time that should triger a NUX
            // component to play or not play.  Longer term it would be betetr to catch all player data chnage 
            // events so that that we could provide reactive teaching at any time during the application
            // lifecycle.
            if (eventData.LocalPlayer != null)
            {
                LocalPlayer = eventData.LocalPlayer;
                Evaluate();
                LocalPlayer = null;
            }
        }

        #endregion
    }
}
