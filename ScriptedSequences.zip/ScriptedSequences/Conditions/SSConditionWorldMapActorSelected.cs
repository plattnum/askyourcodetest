﻿using System;
using GameTypes;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Ninject;
using Kixeye.WCM.Events;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionWorldMapActorSelected : ScriptedSequenceCondition
    {
        [Newtonsoft.Json.JsonProperty("HexDesignator")]
        [ProtoMember(3)]
        public HexDesignator HexDesignator
        {
            get
            {
                if (_hexDesignator == null)
                {
                    _hexDesignator = HexDesignator.Alloc();
                }
                return _hexDesignator;
            }
            set { _hexDesignator = value; }
        }

        [UnityEngine.SerializeField]
        private HexDesignator _hexDesignator = default;

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            saver.Save(HexDesignator);
            saver.Save(this);
#endif
        }

        public override string GetDebugName()
        {
            var result = "World Map Selection: " + HexDesignator.GetDebugName();
            return result;
        }

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<WorldMapUnoccupiedSelectedEvent>(OnUnoccupiedSelected);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<WorldMapUnoccupiedSelectedEvent>(OnUnoccupiedSelected);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// The application's event manager.
        /// </summary>
        [Inject]
        private EventManager _events { get; set; }

        /// <summary>
        /// The worldmap controller.
        /// </summary>
        [Inject]
        public WorldMapController _worldMap { get; private set; }

        /// <summary>
        /// The game's player manager
        /// </summary>
        [Inject]
        public PlayerManager _players { get; private set; }

        private bool _handlersRegistered = false;

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<WorldMapUnoccupiedSelectedEvent>(OnUnoccupiedSelected);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (_worldMap.SelectedLocation.HasValue)
            {
                Evaluate(_worldMap.SelectedLocation.Value);
            }
        }

        /// <summary>
        /// Called when a hex from WM is selected.
        /// </summary>
        private void OnUnoccupiedSelected(WorldMapUnoccupiedSelectedEvent unoccupiedSelectedEvent)
        {
            var position2d = HexGridUtils.GetClosestGridSquare(unoccupiedSelectedEvent.SelectedLocation);
            Evaluate(position2d);
        }

        private void Evaluate(Position2Data position2d)
        {
            Met = HexDesignator.CheckConditionsForHex(null, position2d, _worldMap, _players);
        }
    }
}

