using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnRogueFactionAttacked : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("GameState")]
        [ProtoMember(3)]
        public Kixeye.WCM.ScriptedSequences.SSActionLoadGameState.GameStateEnum GameState;

        /// <summary>
        /// The (zero-based) index of the SP rogue faction
        /// </summary>
        [Newtonsoft.Json.JsonProperty("FactionID")]
        [ProtoMember(4)]
        public int FactionID;

        /// <summary>
        /// The (zero-based) index of the Mission within the specified faction
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MissionID")]
        [ProtoMember(5)]
        public int MissionID;

        #endregion
        
        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public properties

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BattleStartedEvent>(OnBattleStarted);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BattleStartedEvent>(OnBattleStarted);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BattleStartedEvent>(OnBattleStarted);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Kixeye.WCM.Controllers.BattleController battleController = WCMApplicationDirector.Instance.Battle;
            if (battleController == null || !battleController.IsBattleOccurring)
            {
                return;
            }

            AttackData attackData = battleController.AttackData;
            Player defendingPlayer = attackData.AttackTargetData.DefendingPlayer;
            if (defendingPlayer == null)
            {
                return;
            }

            if (defendingPlayer.RFBaseDefinition != null &&
                defendingPlayer.RFBaseDefinition.factionID == FactionID &&
                defendingPlayer.RFBaseDefinition.missionID == MissionID)
            {
                Met = true;
            }
        }

        #endregion
        
        #region Private methods

        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnBattleStarted(BattleStartedEvent battleStartedEvent)
        {
            Player defendingPlayer = battleStartedEvent.AttackData.AttackTargetData.DefendingPlayer;
            if (defendingPlayer == null)
            {
                LogError("No defending player found.");
            }
            else if (defendingPlayer.RFBaseDefinition != null &&
                        defendingPlayer.RFBaseDefinition.factionID == FactionID &&
                        defendingPlayer.RFBaseDefinition.missionID == MissionID)
            {
                Met = true;
                return;
            }

            Met = false;
        }
        
        #endregion
    }
}

