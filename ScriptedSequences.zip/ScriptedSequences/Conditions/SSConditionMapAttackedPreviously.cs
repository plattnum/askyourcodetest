using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Newtonsoft.Json;
using System.ComponentModel;
using GameTypes;
using Kixeye.WCM.Pve;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionMapAttackedPreviously : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The map name for the attacked mission.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MapName")]
        [ProtoMember(3)]
        public string MapName;

        #endregion

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        protected EventManager _events { get; set; }

        protected bool _handlersRegistered = false;

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(SSConditionMapAttackedPreviously));

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            // condition met as soon as a battle has begun and map name matches
            if (!string.IsNullOrEmpty(MapName))
            {
                string currentLevelName = WCMApplicationDirector.Instance.SpawnManager.CurrentLevelName ?? string.Empty;
                if (string.Compare(currentLevelName, MapName, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    // Wrong map name
                    return;
                }

                PveCampaignProgress campaignProgress = WCMApplicationDirector.Instance.Players.LocalPlayer.PveCampaignProgress;
                if ((campaignProgress != null) && (campaignProgress.RFBaseDefinition != null) && !campaignProgress.RFBaseDefinition.allowSequences)
                {
                    // This campaign mission disallows sequences
                    return;
                }
            }

            ScriptedSequenceNode parentNode = GetParentNode();
            if (parentNode != null)
            {
                if ((parentNode.Parent != null) &&
                    (parentNode.Parent.TimesPlayerHasCompleted(WCMApplicationDirector.Instance.Players.LocalPlayer.Data.PlayerDetails) > 0))
                {
                    Met = true;
                }

                if (Met && _logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug("SSConditionMapAttackedPreviously condition met on map '" + MapName + "'");
                }
            }
        }
        
        /// <summary>
        /// Called when the battle has begun.
        /// </summary>
        private void OnBattleBegun(BattleBegunEvent battleBegunEvent)
        {
            if (!battleBegunEvent.AttackData.AttackTargetData.AttackType.IsRecording())
            {
                Evaluate();
            }
        }
    }
}

