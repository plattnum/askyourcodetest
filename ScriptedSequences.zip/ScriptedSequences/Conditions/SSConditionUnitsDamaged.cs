using System;
using Ninject;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using ProtoBuf;
using Kixeye.WCM.Events;
using Kixeye.WCM.ui;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Condition that is true when player units are damaged.
    /// </summary>
    [Serializable]
    public class SSConditionUnitsDamaged : ScriptedSequenceCondition
    {
        public enum Scope
        {
            AnyUnit,
            SpecificSquad,
            SpecificPlatoon,
            SelectedCraftingPlatoon
        }
        
        #region Serialized properties
        
        /// <summary>
        /// What needs to be damaged in order to satisfy the condition.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ScopeOfDamage")]
        [ProtoMember(3)]
        public Scope ScopeOfDamage;

        /// <summary>
        /// The percent of full health below which the condition will be triggered.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ThresholdPct")]
        [ProtoMember(4)]
        public float ThresholdPct = 1.0f;
        
        /// <summary>
        /// The squad which contains the units to check for damage.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Designator")]
        [ProtoMember(5)]
        public SquadDesignator Designator
        {
            get { return _designator; }
        }

        /// <summary>
        /// Flag that specifies if we should ignore events or not.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("IgnoreEvents")]
        [ProtoMember(6)]
        public bool IgnoreEvents = false;

        #endregion

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _designator = new SquadDesignator();

        [Inject]
        private IEventDispatcher _events { get; set; }

        private bool _handlersRegistered = false;

        public SSConditionUnitsDamaged ()
        {
        
        }

        public override string GetDebugName()
        {
            switch (ScopeOfDamage)
            {
                case Scope.AnyUnit:
                    return "Any Unit Damaged";

                case Scope.SpecificSquad:
                case Scope.SpecificPlatoon:
                case Scope.SelectedCraftingPlatoon:
                    return "Units Damaged: {0}".FormatWith(Designator);

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && ! IgnoreEvents)
                    {
                        if (IsInitialized())
                        {
                            if (value)
                            {
                                if (!_handlersRegistered)
                                {
                                    //Add event handler
                                    if (ScopeOfDamage == Scope.SelectedCraftingPlatoon)
                                    {
                                        _events.AddEventHandler<CraftingPlatoonSelectedEvent>(HandleCraftingPlatoonSelected);
                                    }
                                    else
                                    {
                                        _events.AddEventHandler<UnitDamagedEvent>(HandleDamageTaken);
                                        _events.AddEventHandler<PlatoonRepairedEvent>(HandleRepairChanged);
                                    }
                                    _handlersRegistered = true;
                                }
                            }
                            else
                            {
                                if (_handlersRegistered)
                                {
                                    // remove the event handler
                                    if (ScopeOfDamage == Scope.SelectedCraftingPlatoon)
                                    {
                                        _events.RemoveEventHandler<CraftingPlatoonSelectedEvent>(HandleCraftingPlatoonSelected);
                                    }
                                    else
                                    {
                                        _events.RemoveEventHandler<UnitDamagedEvent>(HandleDamageTaken);
                                        _events.RemoveEventHandler<PlatoonRepairedEvent>(HandleRepairChanged);
                                    }
                                    _handlersRegistered = false;
                                }
                            }
                        }
                    }
                }
            }
        }

        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && !IgnoreEvents)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    if (ScopeOfDamage == Scope.SelectedCraftingPlatoon)
                    {
                        _events.AddEventHandler<CraftingPlatoonSelectedEvent>(HandleCraftingPlatoonSelected);
                    }
                    else
                    {
                        _events.AddEventHandler<UnitDamagedEvent>(HandleDamageTaken);
                        _events.AddEventHandler<PlatoonRepairedEvent>(HandleRepairChanged);
                    }
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            if (ScopeOfDamage == Scope.SpecificSquad)
            {
                Met |= IsSquadDamaged(Designator.GetSquad());
                return;
            }
            else if (ScopeOfDamage == Scope.SpecificPlatoon)
            {
                Army army = WCMApplicationDirector.Instance.Players.LocalPlayer.Army;
                if (army == null)
                {
                    Met = false;
                    return;
                }

                Platoon platoon = army.Platoons.Find(_ => _.PlatoonIndex == Designator.PlatoonNumber);

                Met |= IsPlatoonDamaged(platoon);
                return;
            }
            else if (ScopeOfDamage == Scope.SelectedCraftingPlatoon)
            {
                PanelBase currentPanel = WCMApplicationDirector.Instance.UI.CurrentPanel;
                if (currentPanel != null && currentPanel is SSUI_Unit_Crafting)
                {
                    CraftingUIManager craftingScreen = (currentPanel as SSUI_Unit_Crafting).Panel;
                    if (craftingScreen.SelectedPlatoon != null)
                    {
                        foreach (var squad in craftingScreen.SelectedPlatoon.Squads)
                        {
                            if (IsSquadDamaged(squad))
                            {
                                Met = true;
                                return;
                            }
                        }
                    }
                }
            }
            else
            {
                // check all squads
                Kixeye.WCM.Controllers.BattleController battleController = WCMApplicationDirector.Instance.Battle;
                if (battleController == null || !battleController.IsBattleOccurring)
                {
                    return;
                }
                // check defending player squads
                AttackData attackData = battleController.AttackData;
                Player defendingPlayer = attackData.AttackTargetData.DefendingPlayer;
                foreach (var squad in defendingPlayer.ActiveSquads)
                {
                    if (IsSquadDamaged(squad))
                    {
                        Met = true;
                        return;
                    }
                }
                // check attacking player squads
                Player attachingPlayer = attackData.AttackTargetData.AttackingPlayer;
                foreach (var squad in attachingPlayer.ActiveSquads)
                {
                    if (IsSquadDamaged(squad))
                    {
                        Met = true;
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// Handles the times repaired stat being changed.
        /// </summary>
        void HandleRepairChanged (PlatoonRepairedEvent evt)
        {
            Met = false;
        }

        /// <summary>
        /// Handles the platoon selection change in the crafting UI
        /// </summary>
        /// <param name="evt">The event.</param>
        void HandleCraftingPlatoonSelected(CraftingPlatoonSelectedEvent evt)
        {
            if (Enabled && evt.Platoon != null)
            {
                foreach (var squad in evt.Platoon.Squads)
                {
                    if (IsSquadDamaged(squad))
                    {
                        Met = true;
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// Check if a squad has taken damage.
        /// </summary>
        /// <param name="squad"></param>
        /// <returns></returns>
        private bool IsSquadDamaged(Squad squad)
        {
            if (squad != null)
            {
                float healthMax = squad.GetTotalHealthMax();
                if (healthMax > 0)
                {
                    float totalHealth = squad.GetTotalHealth();
                    float health = (totalHealth / healthMax);

                    if (health == 0f || health < ThresholdPct)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Check if a platoon has taken damage.
        /// </summary>
        /// <param name="squad"></param>
        /// <returns></returns>
        private bool IsPlatoonDamaged(Platoon platoon)
        {
            if (platoon == null)
            {
                return false;
            }

            foreach (Squad squad in platoon.Squads)
            {
                if (IsSquadDamaged(squad))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Handles the ammount of damage taken stat being changed.
        /// </summary>
        /// <param name="stat">Stat.</param>
        /// <param name="previous">Previous.</param>
        /// <param name="newValue">New value.</param>
        /// <param name="removeAction">Remove action.</param>
        private void HandleDamageTaken(UnitDamagedEvent evt)
        {
            if (!Enabled)
            {
                return;
            }

            if (ScopeOfDamage == Scope.AnyUnit)
            {
                Met = true;
            }
            else if (ScopeOfDamage == Scope.SpecificPlatoon)
            {
                Squad squad = evt.Unit.Squad;
                Met |= (squad.Platoon.PlatoonIndex == Designator.PlatoonNumber);
            }
            else
            {
                try
                {
                    Squad squad = evt.Unit.Squad;

                    if (squad != null && Designator.IsSquad(squad))
                    {
                        Met = IsSquadDamaged(squad);
                    }
                }
                catch (ApplicationException ex)
                {
                    LogError(ex.ToString());
                }
            }
        }
    }
}

