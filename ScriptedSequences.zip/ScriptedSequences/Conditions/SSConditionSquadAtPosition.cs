using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionSquadAtPosition : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The backing position data for this position
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Position")]
        [ProtoMember(4)]
        public PositionData Position = new PositionData();

        /// <summary>
        /// The squad to follow until they reach the position.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadToTrack")]
        [ProtoMember(3)]
        public SquadDesignator SquadToTrack = new SquadDesignator();

        /// <summary>
        /// The target squad has to be within this distance of the target point to meet the condition.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("Tolerance")]
        [ProtoMember(5)]
        public float Tolerance
        {
            get { return _tolerance;}
            set { _tolerance = value; _toleranceSqr = value * value; }
        }

        #endregion
        
        #region private variables
        private float _tolerance = 10f;
        private float _toleranceSqr = 100f;


        private bool _handlersRegistered = false;

        #endregion
        
        #region Public properties
        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    Squad squad = SquadToTrack.GetSquad();
                    if (squad != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                squad.OnPositionChange += HandleOnPositionChange;
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                squad.OnPositionChange -= HandleOnPositionChange;
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (Enabled)
            {
                Squad squad = SquadToTrack.GetSquad();
                if (squad != null)
                {
                    if (!_handlersRegistered)
                    {
                        //Add event handler
                        squad.OnPositionChange += HandleOnPositionChange;
                        _handlersRegistered = true;
                    }
                }
            }
        }
        
        #endregion
        
        #region Private methods
        
        private void HandleOnPositionChange()
        {
            Evaluate();
        }
        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Squad squad = SquadToTrack.GetSquad();
            if (squad != null)
            {
                PositionData delta = Position - squad.Position;
                Met = (delta.sqrMagnitude <= _toleranceSqr);
            }
            else
            {
                Met = false;
            }
        }
        
        #endregion
    }
}
