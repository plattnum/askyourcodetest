using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.WCM.Pve;
using Newtonsoft.Json;

namespace Kixeye.WCM.ScriptedSequences
{

    [Serializable]
    public class SSConditionOnMapAttacked : ScriptedSequenceCondition, ISerializationCallbackReceiver
    {
        #region Serialized properties
        /// <summary>
        /// The map name for the attacked mission.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("MapName")]
        [ProtoMember(3)]
        public string MapName;

        [Newtonsoft.Json.JsonProperty("ZoneActorTypes")]
        [ProtoMember(4)]
        public ZoneActorType ZoneActorTypes = ZoneActorType.Invalid;

        [Newtonsoft.Json.JsonProperty("ZoneActorSubType")]
        [ProtoMember(5)]
        public int? ZoneActorSubType;

        #endregion


        #region Unity Serialization Support

        [SerializeField]
        protected NullableSerializedInt _zoneActorSubType;

        public void OnBeforeSerialize()
        {
            _zoneActorSubType = new NullableSerializedInt
            {
                Value = ZoneActorSubType,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_zoneActorSubType != null)
            {
                ZoneActorSubType = _zoneActorSubType.Value;
            }
            _zoneActorSubType = null;
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public properties

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BattleBegunEvent>(OnBattleBegun);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BattleBegunEvent>(OnBattleBegun);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
        }
        #endregion
        
        #region Private methods

        /// <summary>
        /// Called whenever the battle has begun.
        /// </summary>
        private void OnBattleBegun(BattleBegunEvent battleBegunEvent)
        {
            if (battleBegunEvent.AttackData.AttackTargetData.AttackType.IsRecording())
            {
                // Battle is a replay.
                return;
            }

            if (WCMApplicationDirector.Instance.GameStates.CurrentState is ScoutingState)
            {
                // Still in scouting state.
                return;
            }

            if (!string.IsNullOrEmpty(MapName))
            {
                string currentLevelName = WCMApplicationDirector.Instance.SpawnManager.CurrentLevelName ?? string.Empty;
                if (string.Compare(currentLevelName, MapName, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    // Wrong map name
                    return;
                }

                PveCampaignProgress campaignProgress = WCMApplicationDirector.Instance.Players.LocalPlayer.PveCampaignProgress;
                if ((campaignProgress != null) && (campaignProgress.RFBaseDefinition != null) && !campaignProgress.RFBaseDefinition.allowSequences)
                {
                    // This campaign mission disallows sequences
                    return;
                }
            }

            if (ZoneActorTypes != ZoneActorType.Invalid)
            {
                var battleData = battleBegunEvent.AttackData.AttackTargetData.DefendingPlayer.BattleData;
                if (battleData == null)
                {
                    // BattleData appears to be null for the combat tutorial battle.
                    return;
                }

                if (0 == (battleData.ZoneActorType & ZoneActorTypes))
                {
                    // Incorrect actor type.
                    return;
                }

                if (ZoneActorSubType.HasValue)
                {
                    FOBType battleDataFOBType = battleData.FobType;
                    int flag = 1 << (int)battleDataFOBType;
                    if ((ZoneActorSubType.Value & flag) == 0)
                    {
                        // Incorrect actor subtype.
                        return;
                    }
                }
            }

            Met = true;
            LogDebug("Condition met for map '" + MapName + "' and type '" + ZoneActorTypes + "'");
        }

        #endregion
    }
}
