using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionCurrentCampaignProgressionState : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("FactionId")]
        [ProtoMember(3)]
        public int FactionId;

        [Newtonsoft.Json.JsonProperty("MissionId")]
        [ProtoMember(4)]
        public int MissionId;

        [Newtonsoft.Json.JsonProperty("Comparison")]
        [ProtoMember(5)]
        public ComparisonType Comparison;
        #endregion

        #region Public methods
        /// <summary>
        /// Gets the pretty display name for the editor
        /// </summary>
        public static string GetDisplayNameStatic() { return "Current Campaign Progress"; }
        
        public override string GetDebugName()
        {
            return "Campaign Progress: Next mission: {0}C{1}M{2}".FormatWith(
                Comparison == ComparisonType.Equals ? "" : Comparison + " ",
                FactionId + 1,
                MissionId + 1);
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }
            
            if (Players == null || Players.LocalPlayer == null || Players.LocalPlayer.PveCampaignProgress == null)
            {
                return; // no known campaign progress so far
            }

            if (Met)
            {
                // To maintain existing behavior this condition stays met even if 
                // the condition is later violated;  that isn't how all conditions 
                // operate, so it could be a gotcha.
                return;
            }

            bool met;
            var campaignProgress = Players.LocalPlayer.PveCampaignProgress;
            switch (Comparison)
            {
                case ComparisonType.Equals:
                    met = ((campaignProgress.FactionID == FactionId) && (campaignProgress.MissionID == MissionId));
                    break;
                case ComparisonType.GreaterThan:
                    met = ((campaignProgress.FactionID > FactionId)
                        || ((campaignProgress.FactionID == FactionId) && (campaignProgress.MissionID > MissionId)));
                    break;
                case ComparisonType.LessThan:
                    met = ((campaignProgress.FactionID < FactionId)
                        || ((campaignProgress.FactionID == FactionId) && (campaignProgress.MissionID < MissionId)));
                    break;
                default:
                    throw new ArgumentOutOfRangeException("Comparison", Comparison, "Unexpected enum value.");
            }
            Met = met;
        }

        #endregion

        #region Implementation

        [Inject]
        private PlayerManager Players { get; set; }

        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<PlayerDataChanged>(OnPlayerDataChanged);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (_events != null)
                    {
                        if (!_handlersRegistered)
                        {
                            //Add event handler
                            _events.AddEventHandler<PlayerDataChanged>(OnPlayerDataChanged);
                            _handlersRegistered = true;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnPlayerDataChanged(PlayerDataChanged evt)
        {
            if (Enabled)
            {
                Evaluate();
            }
        }

        private bool _handlersRegistered;

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events { get; set; }

        #endregion
    }
}

