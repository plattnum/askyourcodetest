using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;
using Kixeye.Common.StateMachine;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionOnEnterGameState : ScriptedSequenceCondition
    {
        #region Serialized properties

        [Newtonsoft.Json.JsonProperty("GameState")]
        [ProtoMember(3)]
        public Kixeye.WCM.ScriptedSequences.SSActionLoadGameState.GameStateEnum GameState;

        #endregion
        
        #region Public properties

        // Override the base class enabled so we set event-handling depending on enabled state
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {                            
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<GameStateChangeEvent>(OnStateChanged);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<GameStateChangeEvent>(OnStateChanged);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        /// <summary>
        /// Gets the game state controller singleton.
        /// </summary>
        [Inject]
        private WCMGameStateController _gameStates
        {
            get;
            set;
        }

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public methods

        public override string GetDebugName()
        {
            return "On Enter Game State: {1}".FormatWith(GetType().Name, GameState);
        }

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<GameStateChangeEvent>(OnStateChanged);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Met = IsDesiredState(_gameStates.CurrentState);
        }
        #endregion
        
        #region Private methods
        
        /// <summary>
        /// Called whenever the game changes states.
        /// </summary>
        private void OnStateChanged( GameStateChangeEvent stateEvent )
        {
            // Fun fact: our global event handers are removed the frame after the remove call is 
            // made, not instantly.  This is generally good but it can lead to a case for
            // this condition where it is disabled in the same frame that the callback is made to
            // its event handler.  Since it hasn't been removed yet it'll be handled.  This just
            // ignores it in that case.
            if (Enabled)
            {
                Met = IsDesiredState( stateEvent.NewState );
            }
        }
        
        private bool IsDesiredState(IState state)
        {
            switch (GameState)
            {
            case Kixeye.WCM.ScriptedSequences.SSActionLoadGameState.GameStateEnum.BaseManagement:
                return (state as BaseManagementState) != null;

            case Kixeye.WCM.ScriptedSequences.SSActionLoadGameState.GameStateEnum.ScoutingState:
                return (state as ScoutingState) != null;

            case Kixeye.WCM.ScriptedSequences.SSActionLoadGameState.GameStateEnum.WorldMapState:
                return (state as WorldMapState) != null;

            default:
                Log.Error(this, " Unsupported Game State: " + GameState);
                break;
            }        

            return false;
        }
        
        #endregion
    }
}

