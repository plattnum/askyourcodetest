using System;
using ProtoBuf;
using UnityEngine;
using System.Collections.Generic;
using Kixeye.WCM.GameData;
using Ninject;
using Kixeye.WCM.Events;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionBuildingDestroyed : ScriptedSequenceCondition
    {
        #region Serialized properties
        
        /// <summary>
        /// The building that needs to be destroyed to satisfy this condition.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("BuildingDestroyed")]
        [ProtoMember(3)]
        public BuildingDesignator BuildingDestroyed = new BuildingDesignator();
        
        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion

        #region Public properties

        /// <summary>
        /// Sets the enabled state of the condition and performs necessary functions based on the new state.
        /// </summary>
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;

                    if (_events != null)
                    {
                        if (IsInitialized())
                        {
                            SetHandlers(value);
                        }
                    }
                }
            }
        }

        #endregion
    
        #region Public methods
        
        /// <summary>
        /// Initialize the condition.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this condition.</param>
        public override void Initialize (IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (Enabled)
            {
                SetHandlers(true);
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            foreach (Building checkBuilding in BuildingDestroyed.GetBuildings())
            {
                if (checkBuilding.IsDead)
                {
                    Met = true;
                    break;
                }
            }
        }
        #endregion
        
        #region Private methods
    
        /// <summary>
        /// Called when a building has been destroyed so we can see if it's the one we care about
        /// </summary>
        /// <param name="buildingEvent">Building event.</param>
        private void HandleBuildingDestroyed( BuildingDestroyedEvent buildingEvent )
        {
            if (Enabled)
            {
                foreach (Building checkBuilding in BuildingDestroyed.GetBuildings())
                {
                    if (buildingEvent.Building == checkBuilding)
                    {
                        Met = true;
                        break;
                    }
                }
            }
        }
        
        /// <summary>
        /// Handles the battle begining by clearing this condition (the building hasn't been destroyed yet)
        /// </summary>
        private void HandleBattleBegun(BattleBegunEvent battleEvent)
        {
            if (Enabled)
            {
                Met = false;
            }
        }

        /// <summary>
        /// Turns event handlers for building destruction on or off
        /// </summary>
        /// <param name="turnOn"></param>
        private void SetHandlers(bool turnOn)
        {
            if (turnOn)
            {
                // see if the building is already destroyed
                foreach (Building checkBuilding in BuildingDestroyed.GetBuildings())
                {
                    if (checkBuilding.IsDead)
                    {
                        Met = true;
                        break;
                    }
                }

                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BuildingDestroyedEvent>(HandleBuildingDestroyed);
                    _events.AddEventHandler<BattleBegunEvent>(HandleBattleBegun);
                }
            }
            else
            {
                if (_handlersRegistered)
                {
                    // remove the event handler
                    _events.RemoveEventHandler<BuildingDestroyedEvent>(HandleBuildingDestroyed);
                    _events.RemoveEventHandler<BattleBegunEvent>(HandleBattleBegun);
                }
            }
            _handlersRegistered = turnOn;
        }
        
        #endregion
    }
}

