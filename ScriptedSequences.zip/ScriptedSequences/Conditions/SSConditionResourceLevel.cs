using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionResourceLevel : ScriptedSequenceCondition
    {
        #region Serialized properties
        [Newtonsoft.Json.JsonProperty("Resource")]
        [ProtoMember(3)]
        public ResourceType Resource;

        [Newtonsoft.Json.JsonProperty("Comparison")]
        [ProtoMember(4)]
        public ComparisonType Comparison;
        
        [Newtonsoft.Json.JsonProperty("ResourceLevel")]
        [ProtoMember(5)]
        public int ResourceLevel;
        #endregion

        #region Private variables
        
        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion

        #region Public properties
        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        
        #endregion
        #region Public methods
        
        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize( parent );
            
            if (_events != null)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<GameResourceChangedEvent>(OnResourcesChange);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
            if (localPlayer == null)
            {
                return;
            }
            
            long currentLevel = localPlayer.Resources.GetAmountByType(Resource);
            switch (Comparison)
            {
                case ComparisonType.Equals:
                    Met = (currentLevel == ResourceLevel);
                    break;
                case ComparisonType.GreaterThan:
                    Met = (currentLevel > ResourceLevel);
                    break;
                case ComparisonType.LessThan:
                    Met = (currentLevel < ResourceLevel);
                    break;
            }
        }
        
        #endregion
        
        #region Private methods

        private void OnResourcesChange( GameResourceChangedEvent resourceChangeEvent )
        {
            Evaluate();
        }

        #endregion
    }
}
