using System;
using GameTypes;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    // This is what one would call a hack.  Rather than try to handle every permutation of cases
    // that could break the SSUI part of the NUX, we check a condition to see if the player's Army is 
    // in a state that appears to have ever been modified.  If this returns true, we just skip the 
    // SSUI part of the NUX - we know that the user completed at least the first part of it anyway

    [Serializable]
    public class SSConditionPlatoonsEverModified : SSConditionPlayerDataQuery
    {
        // seems like Ninject doesn't deal well with properties on base classes
        [Inject]
        protected new EventManager _events
        {
            get
            {
                return base._events;    
            }
            set
            {
                base._events = value;
            }
        }

        #region method overrides

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()    
        {
            if (!IsInitialized() || 
                !Enabled || 
                LocalPlayer == null || 
                LocalPlayer.Data == null)
            {
                return;
            }

            // the default platoon contains 1 Rhino, 10 Riflemen, and 10 Riflemen
            var alphaPlatoon = LocalPlayer.Data.Army.PlatoonList[0];

            bool squad1Modified = alphaPlatoon.SquadList[0].UnitList.Count != 1;
            bool squad2Modified = alphaPlatoon.SquadList[1].UnitList.Count != 10;
            bool squad3Modified = alphaPlatoon.SquadList[2].UnitList.Count != 10;

            // the player's reserves are empty when the player is created
            bool reservesNotEmpty = false;
            foreach (SquadData reserveSquad in LocalPlayer.Data.Base.StoragePlatoon.SquadList) 
            {
                if (reserveSquad.UnitList.Count > 0)
                {
                    reservesNotEmpty = true; 
                }
            }

            Met = (squad1Modified || squad2Modified || squad3Modified || reservesNotEmpty);
        }

        #endregion
    }
}
