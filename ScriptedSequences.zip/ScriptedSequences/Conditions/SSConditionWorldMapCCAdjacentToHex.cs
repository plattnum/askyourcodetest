﻿using System;
using Kixeye.WCM.WorldMap;
using ProtoBuf;
using Kixeye.WCM.Events;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionWorldMapCCAdjacentToHex : ScriptedSequenceCondition
    {

        [Newtonsoft.Json.JsonProperty("HexDesignator")]
        [ProtoMember(3)]
        public HexDesignator HexDesignator
        {
            get
            {
                if (_hexDesignator == null)
                {
                    _hexDesignator = HexDesignator.Alloc();
                }
                return _hexDesignator;
            }
            set { _hexDesignator = value; }
        }

        [UnityEngine.SerializeField]
        private HexDesignator _hexDesignator = default;

        public override void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            saver.Save(HexDesignator);
            saver.Save(this);
#endif
        }

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value;
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                RemoveHandlers();
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                AddHandlers();
                            }
                        }
                    }
                }
            }
        }

        private EventManager _events { get { return WCMApplicationDirector.Instance.Events; } }

        /// <summary>
        /// The game's player manager
        /// </summary>
        public PlayerManager Players { get { return WCMApplicationDirector.Instance.Players; } }

        /// <summary>
        /// The worldmap controller.
        /// </summary>
        public WorldMapController WorldMap { get { return WCMApplicationDirector.Instance.WorldMap; } }

        private bool _handlersRegistered;

        public override string GetDebugName()
        {
            return "HQ adjacent to " + HexDesignator.GetDebugName();
        }

        public override void Migrate(bool onCreate)
        {
            base.Migrate(onCreate);
            HexDesignator.Migrate(onCreate);
        }

        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    AddHandlers();
                }
            }
        }

        private void AddHandlers()
        {
            // TODO: See if we can move to a ZoneActorUpdate check instead
            _events.AddEventHandler<GameStateChangeEvent>(OnGameStateChangeEvent);
            _events.AddEventHandler<GameStateTransitionProgressEvent>(OnGameStateChangeEvent);
            _events.AddEventHandler<WorldMapHQMovedEvent>(OnHqMoved);
            _handlersRegistered = true;

        }

        private void RemoveHandlers()
        {
            _events.RemoveEventHandler<GameStateChangeEvent>(OnGameStateChangeEvent);
            _events.RemoveEventHandler<GameStateTransitionProgressEvent>(OnGameStateChangeEvent);
            _events.RemoveEventHandler<WorldMapHQMovedEvent>(OnHqMoved);
            _handlersRegistered = false;
        }


        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            EvaluateLocation(WorldMap.GetPlayerHqFromCurrentZone()); // checking if HQ is in target location right now
        }

        private void OnGameStateChangeEvent(IEvent gameStateChangedEvent)
        {
            Evaluate();
        }

        private void OnHqMoved(WorldMapHQMovedEvent hqMovedEvent)
        {
            EvaluateLocation(hqMovedEvent.ZoneActorInfo);
        }

        private void EvaluateLocation(ZoneActorInfo zoneActorInfo)
        {
            var currentZone = WorldMap.CurrentZone;
            if (currentZone == null)
            {
                // cannot evaluate
                return;
            }

            if (zoneActorInfo == null || zoneActorInfo.Location.IsZero || zoneActorInfo.ZoneId != currentZone.ZoneId)
            {
                // no HQ, hq kicked off map, or hq in another zone
                Met = false;
                return;
            }

            foreach (var neighbor in zoneActorInfo.HexCell.Neighbors)
            {
                if (HexDesignator.CheckConditionsForHex(null, neighbor, WorldMap, Players))
                {
                    Met = true;
                    return;
                }
            }

            Met = false;
        }
    }
}

