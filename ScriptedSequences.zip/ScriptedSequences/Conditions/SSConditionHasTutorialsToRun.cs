using System;
using System.Linq;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Events;
using Ninject;
using Kixeye.Core.Logging;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionHasTutorialsToRun : ScriptedSequenceCondition
    {
        #region method overrides

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }
            ScriptedSequencesController controller = WCMApplicationDirector.Instance.ScriptedSequences;
            Met = ! controller.AvailableSequences
                        .Where(_ =>
                            _.IsTutorialSequence &&
                            _.AutoStart &&
                            _.PlayerCanComplete(controller.LocalPlayerData)).ToArray().IsNullOrEmpty();
        }

        #endregion
    }
}
