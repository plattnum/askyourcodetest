using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Kixeye.WCM.Events;
using Ninject;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionBuildingSelected : ScriptedSequenceCondition
    {
        #region Serialized properties

        /// <summary>
        /// The squad to spawn the units in.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("BuildingToSelect")]
        [ProtoMember(3)]
        public BuildingDesignator BuildingToSelect = new BuildingDesignator();
        
        #endregion
        
        #region Private variables
        
        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion

        
        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<BuildingSelectedEvent>(OnBuildingSelectionChange);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<BuildingSelectedEvent>(OnBuildingSelectionChange);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }
        
        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize(IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );
            
            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<BuildingSelectedEvent>(OnBuildingSelectionChange);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            foreach (Building building in BuildingToSelect.GetBuildings())
            {
                if (building.IsSelected)
                {
                    Met = true;
                    return;
                }
            }
        }
        #endregion

        #region Private methods

        private void OnBuildingSelectionChange( BuildingSelectedEvent buildingSelectedEvent )
        {
            foreach (Building candidate in BuildingToSelect.GetBuildings())
            {
                if (candidate == buildingSelectedEvent.Building)
                {
                    Met = true;
                    return;
                }
            }

            Met = false;
        }

        #endregion
    }
}

