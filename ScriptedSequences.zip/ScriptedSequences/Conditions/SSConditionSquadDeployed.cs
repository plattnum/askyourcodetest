using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.WCM.Input;
using Ninject;
using Kixeye.WCM.Events;
using Newtonsoft.Json;
using GameTypes;
using System.Collections.Generic;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionSquadDeployed : ScriptedSequenceCondition
    {
        /// <summary>
        /// The application player manager.
        /// </summary>
        [Inject]
        private PlayerManager _players { get ; set; }

        /// <summary>
        /// The application event manager.
        /// </summary>
        [Inject]
        private EventManager _events { get; set; }

        private bool _handlersRegistered = false;

        /// <summary>
        /// The squad which needs to be deployed.
        /// </summary>
        [JsonProperty("Designator")]
        [ProtoMember(3)]
        public SquadDesignator Designator
        {
            get { return _designator; }
        }

        // not for use, use public field instead.
        // Done this way so it gets serialized but continues to be 'readonly'.
        [UnityEngine.SerializeField]
        private SquadDesignator _designator = new SquadDesignator();

        public SSConditionSquadDeployed()
        {
        }

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null)
                    {
                        if (value)
                        {
                            if (!_handlersRegistered)
                            {
                                _events.AddEventHandler<SquadDeployedEvent>(HandleSquadDeployed);
                                _handlersRegistered = true;
                            }
                        }
                        else
                        {
                            if (_handlersRegistered)
                            {
                                _events.RemoveEventHandler<SquadDeployedEvent>(HandleSquadDeployed);
                                _handlersRegistered = false;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the action.
        /// </summary>
        /// <param name="parent">The ScriptedSequenceNode that owns this action.</param>
        public override void Initialize(IScriptedSequenceComponentParent parent)
        {
            base.Initialize(parent);

            if(_players == null)
            {
                return;
            }

            if (!Enabled)
            {
                return;
            }

            if (!_handlersRegistered)
            {
                _events.AddEventHandler<SquadDeployedEvent>(HandleSquadDeployed);
                _handlersRegistered = true;
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
            if (!IsInitialized() || !Enabled)
            {
                return;
            }

            if (Designator.TypeOfPlatoon == SquadDesignator.PlatoonSearchType.Any
                || Designator.TypeOfPlatoon == SquadDesignator.PlatoonSearchType.AnyNonCivilian)
            {
                Player localPlayer = WCMApplicationDirector.Instance.Players.LocalPlayer;
                if (localPlayer != null && localPlayer.Army != null)
                {
                    foreach (Platoon platoon in localPlayer.Army.Platoons)
                    {
                        foreach (Squad squad in platoon.Squads)
                        {
                            if (squad.IsDeployed)
                            {
                                // 'Non-civilian" is defined as "under player's control", 
                                // so for AnyNonCivilian we do an extra check:
                                if (Designator.TypeOfPlatoon == SquadDesignator.PlatoonSearchType.AnyNonCivilian && !squad.PerformingPlayerCommand)
                                {
                                    continue;
                                }
                                else
                                {
                                    Met = true;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                Squad squad = Designator.GetSquad();
                if (squad == null)
                {
                    return;
                }
                Met |= squad.IsDeployed;
            }
        }
        
        /// <summary>
        /// Handles a squad being deployed.
        /// </summary>
        private void HandleSquadDeployed(SquadDeployedEvent squadEvent)
        {
            UpdateConditionForSquad(squadEvent.Squad);
        }

        /// <summary>
        /// Updates if the condition has been met for the given squad.
        /// </summary>
        /// <param name="squad">Squad to check.</param>
        private void UpdateConditionForSquad(Squad squad)
        {
            if(!Designator.IsSquad(squad))
            {
                return;
            }

            Met |= true;
        }
    }
}

