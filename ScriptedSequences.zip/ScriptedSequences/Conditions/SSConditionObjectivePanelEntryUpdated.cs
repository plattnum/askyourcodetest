using System;
using ProtoBuf;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Ninject;
using Kixeye.WCM.Events;
using Kixeye.WCM.GameState;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class SSConditionObjectivePanelEntryUpdated : ScriptedSequenceCondition
    {
        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(SSConditionObjectivePanelEntryUpdated));

        #region Serialized properties
        
        /// <summary>
        /// The Id of the objective that we are watching for.  Eventually we could
        /// do more completex logic on the event
        /// </summary>
        [Newtonsoft.Json.JsonProperty("ObjectiveId")]
        [ProtoMember(3)]
        public int ObjectiveId;
        
        #endregion
        
        #region Public properties

        // Override the base class enabled so we can turn on the touch-catcher when enabled
        public override bool Enabled
        {
            set 
            {
                if (base.Enabled != value)
                {
                    base.Enabled = value; 
                    if (_events != null && IsInitialized())
                    {
                        if (value == false)
                        {
                            if (_handlersRegistered)
                            {
                                // remove the event handler
                                _events.RemoveEventHandler<ObjectivePanelEntryUpdatedEvent>(ObjectivePanelEntryUpdated);
                                _handlersRegistered = false;
                            }
                        }
                        else
                        {
                            if (!_handlersRegistered)
                            {
                                //Add event handler
                                _events.AddEventHandler<ObjectivePanelEntryUpdatedEvent>(ObjectivePanelEntryUpdated);
                                _handlersRegistered = true;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Private variables

        /// <summary>
        /// The application's event manager.
        /// </summary>
        /// <value>The _events.</value>
        [Inject]
        private EventManager _events {get; set;}

        private bool _handlersRegistered = false;

        #endregion
        
        #region Public methods

        /// <summary>
        /// Register the callback for condition completion.
        /// </summary>
        /// <param name='callback'>
        /// The callback method.
        /// </param>
        public override void Initialize( IScriptedSequenceComponentParent parent )
        {
            base.Initialize( parent );

            if (_events != null && Enabled)
            {
                if (!_handlersRegistered)
                {
                    //Add event handler
                    _events.AddEventHandler<ObjectivePanelEntryUpdatedEvent>(ObjectivePanelEntryUpdated);
                    _handlersRegistered = true;
                }
            }
        }

        /// <summary>
        /// Evaluate the met state of the condition.
        /// </summary>
        protected override void Evaluate()
        {
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Called when an objective is updated in the objective UI
        /// </summary>
        private void ObjectivePanelEntryUpdated( ObjectivePanelEntryUpdatedEvent objectiveUpdatedEvent )
        {
            if (Enabled)
            {
                if (objectiveUpdatedEvent.ObjectiveConfiguration.Id == ObjectiveId)
                {
                    Met = true;
                    _logger.Debug(null, " \t condition is now {0} for ID {1}", Met, ObjectiveId);
                }
            }
        }

        
        #endregion
    }
}

