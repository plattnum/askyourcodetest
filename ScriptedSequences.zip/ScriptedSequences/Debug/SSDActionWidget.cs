using System;
using UnityEngine;
using UnityEngine.UI;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// A debug widget for a scipted sequence action.
    /// </summary>
    public class SSDActionWidget : MonoBehaviour
    {

        /// <summary>
        /// The widget's name label.
        /// </summary>
        [SerializeField]
        private Text _nameLabel = default;

        /// <summary>
        /// Sets this scripted sequence action this widget represents.
        /// </summary>
        public void SetAction(ScriptedSequenceAction action)
        {
            _nameLabel.text = action.GetDebugName();
        }

    }
}

