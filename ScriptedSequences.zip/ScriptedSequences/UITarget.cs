using System;
using UnityEngine;
using GameTypes;

namespace Kixeye.WCM
{
    public class UITarget : IUITarget
    {
        private readonly PositionData _uiPosition;

        public UITarget (PositionData uiPosition)
        {
            _uiPosition = uiPosition;
        }
            
        #region IUITarget implementation

        public PositionData ScreenPosition 
        {
            get 
            {
                return _uiPosition;
            }
        }

        #endregion
    }
}

