using System;
using System.Linq;
using System.Collections.Generic;
using GameTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ProtoBuf;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class BuildingDesignator
    {

        /// <summary>
        /// Defines a way to designate a building.
        /// </summary>
        public enum DesignationMethod
        {
            ByType,
            ByTag
        }

        /// <summary>
        /// The method used to designate the building.
        /// </summary>
        [JsonProperty("Method")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(1)]
        public DesignationMethod Method;

        /// <summary>
        /// The tag to use to search for a building if designating by tag.
        /// </summary>
        [JsonProperty("Tag")]
        [ProtoMember(2)]
        public string Tag = "";

        /// <summary>
        /// The type of the building to designate if designating by type.
        /// </summary>
        [JsonProperty("Type")]
        [JsonConverter(typeof(StringEnumConverter))]
        [ProtoMember(3)]
        public BuildingType Type;

        public override string ToString()
        {
            switch (Method)
            {
                case DesignationMethod.ByType:
                    return Type.ToString();
                case DesignationMethod.ByTag:
                    return "Building [{0}]".FormatWith(Tag);
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private static readonly ILogger _logger = Kixeye.Core.Logging.Log.GetLoggerForType(typeof(BuildingDesignator));

        /// <summary>
        /// Returns the building designated.
        /// Returns null if the designated building could not be found.
        /// </summary>
        /// <returns>The building.</returns>
        public Building GetBuilding()
        {
            return GetBuildings().FirstOrDefault();
        }

        public IEnumerable<Building> GetBuildings()
        {
            if (WCMApplicationDirector.Instance.World == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn("GetBuildings() invoked before world exists.");
                }
                return Empty<Building>.Array;
            }
            Base spawnedBase = WCMApplicationDirector.Instance.World.SpawnedBase;
            return GetBuildings(spawnedBase);
        }

        public IEnumerable<Building> GetBuildings(Base spawnedBase)
        {
            if (spawnedBase == null)
            {
                return Enumerable.Empty<Building>();
            }

            if (Method == DesignationMethod.ByType)
            {
                return spawnedBase.Buildings.Where(building => building.Definition.Type == Type);
            }

            return spawnedBase.GetBuildingsWithTag(Tag);
        }
    }
}