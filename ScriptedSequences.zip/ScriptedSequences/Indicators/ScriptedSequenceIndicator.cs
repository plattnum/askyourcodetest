using System;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using GameTypes;
using Kixeye.WCM.WorldMap;
using WorldMap;

namespace Kixeye.WCM.ScriptedSequences
{
    public class ScriptedSequenceIndicator : MonoBehaviour
    {
        private static readonly ILogger _logger = Log.GetLoggerForType(typeof(ScriptedSequenceIndicator));
        // This is the default rotation (in euler angles) that this indicator should be in when spawned out of the pool before it is rotated
        [SerializeField]
        private Vector3 _defaultEulerAngle = Vector3.zero;

        private const float PositionDeltaEpsilon = 0.01f;

        public enum UIElementOffsetType
        {
            Middle,
            Top,
            Bottom,
            Left,
            Right,
        }

        // the prefab name used to spawn this object, saved so we can despawn this object and still this context
        // Note: this is cleared in the despawn callback OnDespawned() below
        public string PoolingPrefabName { get; set; }

        #region Private variables
        
        protected Squad _indicatedSquad = null;
        
        protected GameItem _indicatedGameItem = null;

        protected ZoneActorInfo _indicatedActor = null;
        
        protected PositionData? _indicatedWorldPosition = null;
        
        protected RectTransform _indicatedUGUIElement = null;

        protected PositionData _worldSpaceOffset = PositionData.zero;

        protected UIElementOffsetType _uguiOffset = UIElementOffsetType.Middle;

        private readonly Vector3[] _indicatedUGUIElementWorldCorners = new Vector3[4];
        private readonly Vector3[] _gizmoMyWorldCorners = new Vector3[4];

        private String _parentName = "";
        #endregion

        #region MonoBehaviour overrides

        void OnDrawGizmos()
        {
            GetComponent<RectTransform>().GetWorldCorners(_gizmoMyWorldCorners);

            Gizmos.color = new Color(1.0f, 0.2f, 0.4f);
            DrawRect(_indicatedUGUIElementWorldCorners);

            Gizmos.color = new Color(0.2f, 1.0f, 0.4f);
            DrawRect(_gizmoMyWorldCorners);

            Gizmos.color = new Color(0.8f, 0.8f, 0.4f);
            Gizmos.DrawLine(_indicatedUGUIElementWorldCorners[0], _gizmoMyWorldCorners[0]);
            Gizmos.DrawLine(_indicatedUGUIElementWorldCorners[1], _gizmoMyWorldCorners[1]);
            Gizmos.DrawLine(_indicatedUGUIElementWorldCorners[2], _gizmoMyWorldCorners[2]);
            Gizmos.DrawLine(_indicatedUGUIElementWorldCorners[3], _gizmoMyWorldCorners[3]);
        }

        private static void DrawRect(Vector3[] worldCorners)
        {
            Gizmos.DrawLine(worldCorners[0], worldCorners[1]);
            Gizmos.DrawLine(worldCorners[1], worldCorners[2]);
            Gizmos.DrawLine(worldCorners[2], worldCorners[3]);
            Gizmos.DrawLine(worldCorners[3], worldCorners[0]);
        }

        /// <summary>
        /// Reposition the indicator based on the new state of the frame.
        /// Note that this script's execution order should be late to avoid trailing motion.
        /// We avoid LateUpdate because of bugs in Unity multithreaded rendering + object position changes.
        /// </summary>
        protected virtual void Update()
        {
            UpdateIndicatorTransform();
        }

        #endregion
        
        #region Public methods
        
        public void SetIndicateTarget( Squad squad, PositionData offset, String parentName = "" )
        {
            ResetIndicator();
            _indicatedSquad = squad;
            _worldSpaceOffset = offset;
            UpdateIndicatorTransform();
        }

        public void SetIndicateTarget( GameItem gameItem, PositionData offset, String parentName = "" )
        {
            _parentName = parentName;
            ResetIndicator();
            _indicatedGameItem = gameItem;
            _worldSpaceOffset = offset;
            UpdateIndicatorTransform();
        }

        public void SetIndicateTarget( ZoneActorInfo zoneActorInfo, PositionData offset, String parentName = "" )
        {
            _parentName = parentName;
            ResetIndicator();
            _indicatedActor = zoneActorInfo;
            _worldSpaceOffset = offset;
            UpdateIndicatorTransform();
        }

        public void SetIndicateTarget( PositionData position, PositionData offset, String parentName = "" )
        {
            _parentName = parentName;
            ResetIndicator();
            _indicatedWorldPosition = position;
            _worldSpaceOffset = offset;
            UpdateIndicatorTransform();
        }

        public void SetIndicateTarget( RectTransform elementRect, UIElementOffsetType offsetType, float rotation, Vector3 ScreenOffset, String parentName = "" )
        {
            _parentName = parentName;
            ResetIndicator();
            _indicatedUGUIElement = elementRect;
            _uguiOffset = offsetType;
            gameObject.transform.Rotate(new Vector3(0f, 0f, rotation));
            _worldSpaceOffset = ScreenOffset.ToPositionData();
            UpdateIndicatorTransform();
        }

        // this is called when this object is despawned and returned to a pool
        public void OnDespawned()
        {
            PoolingPrefabName = string.Empty;
        }

        #endregion

        #region Private methods

        private void ResetIndicator()
        {
            _indicatedSquad = null;
            _indicatedGameItem = null;
            _indicatedWorldPosition = null;
            _indicatedActor = null;
            _indicatedUGUIElement = null;
            _uguiOffset = default(UIElementOffsetType);
            _worldSpaceOffset = default(PositionData);

            gameObject.transform.SetParent(WCMApplicationDirector.Instance.UI.AbovePanelsRoot);
            gameObject.transform.SetAsLastSibling();
            gameObject.transform.localPosition = Vector3.zero;
            gameObject.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            gameObject.transform.eulerAngles = _defaultEulerAngle;  // default the object to its starting rotation
        }

        protected virtual void UpdateIndicatorTransform()
        {
            if (_indicatedUGUIElement == null)
            {
                UpdateIndicatorTransformForWorldTarget();
            }
            else
            {
                UpdateIndicatorTransformForUGUITarget();
            }
        }

        private void UpdateIndicatorTransformForWorldTarget()
        {
            PositionData? positionToIndicate = null;

            if (_indicatedSquad != null)
            {
                positionToIndicate = _indicatedSquad.Position;
            }
            else if (_indicatedGameItem != null)
            {
                positionToIndicate = _indicatedGameItem.Position;
            }
            else if (_indicatedActor != null)
            {
                positionToIndicate = new PositionData(_indicatedActor.Location.x, 0, _indicatedActor.Location.y);
            }
            else
            {
                positionToIndicate = _indicatedWorldPosition;
            }

            if (positionToIndicate == null)
            {
                if(_logger.IsEnabled(LogMessageLevel.Warn) &&
                    WCMApplicationDirector.Instance != null
                    && WCMApplicationDirector.Instance.SpawnManager != null)
                {
                    _logger.Warn(
                        null, 
                        string.Format(
                            "Indicator has nothing set to indicate. Map {0}. SS File {1}", 
                            WCMApplicationDirector.Instance.SpawnManager.CurrentLevelName, 
                            _parentName));
                }
                
                gameObject.SetActive(false);
                return;
            }

            gameObject.SetActive(true);

            positionToIndicate += _worldSpaceOffset;
            var uiScreenPos = Utilities.WorldToUGUIScreenPos(positionToIndicate.Value.ToVector());
            uiScreenPos.z = 0;
            if (uiScreenPos.Approximately(gameObject.transform.localPosition, PositionDeltaEpsilon))
            {
                //if the element to indicate did not move, we don't need to update indicator position
                //this is to avoid animator overhead due to animated gameobject moved from outside the animator
                return;
            }
            gameObject.transform.localPosition = uiScreenPos;
        }

        private void UpdateIndicatorTransformForUGUITarget()
        {
            PositionData positionToIndicate;
            // The order is (0) bottom-left, (1) top-left, (2) top-right, (3) bottom-right.
            _indicatedUGUIElement.GetWorldCorners(_indicatedUGUIElementWorldCorners);
            switch (_uguiOffset)
            {
                case UIElementOffsetType.Middle:
                    positionToIndicate = new PositionData(
                        (_indicatedUGUIElementWorldCorners[1].x + _indicatedUGUIElementWorldCorners[3].x) / 2,
                        (_indicatedUGUIElementWorldCorners[1].y + _indicatedUGUIElementWorldCorners[3].y) / 2,
                        0f);
                    break;
                case UIElementOffsetType.Top:
                    positionToIndicate = new PositionData(
                        (_indicatedUGUIElementWorldCorners[1].x + _indicatedUGUIElementWorldCorners[3].x) / 2,
                        _indicatedUGUIElementWorldCorners[1].y,
                        0f);
                    break;
                case UIElementOffsetType.Left:
                    positionToIndicate = new PositionData(
                        _indicatedUGUIElementWorldCorners[1].x,
                        (_indicatedUGUIElementWorldCorners[1].y + _indicatedUGUIElementWorldCorners[3].y) / 2,
                        0f);
                    break;
                case UIElementOffsetType.Bottom:
                    positionToIndicate = new PositionData(
                        (_indicatedUGUIElementWorldCorners[1].x + _indicatedUGUIElementWorldCorners[3].x) / 2,
                        _indicatedUGUIElementWorldCorners[3].y,
                        0f);
                    break;
                case UIElementOffsetType.Right:
                    positionToIndicate = new PositionData(_indicatedUGUIElementWorldCorners[3].x,
                        (_indicatedUGUIElementWorldCorners[1].y + _indicatedUGUIElementWorldCorners[3].y) / 2,
                        0f);
                    break;
                default:
                    throw new ArgumentOutOfRangeException("Unsupported ugui offet type: " + _uguiOffset);
            }

            gameObject.SetActive(true);

            Vector3 uiScreenPos = positionToIndicate.ToVector();
            uiScreenPos += _worldSpaceOffset.ToVector();
            if (uiScreenPos.Approximately(gameObject.transform.position, PositionDeltaEpsilon))
            {
                //if the element to indicate did not move, we don't need to update indicator position
                //this is to avoid animator overhead due to animated gameobject moved from outside the animator
                return;
            }
            gameObject.transform.position = uiScreenPos;
        }

        protected float InOutQuadratic(float t, float b, float c, float d)
        {
            t /= d/2;
            if (t < 1) return c/2*t*t + b;
            t--;
            return -c/2 * (t*(t-2) - 1) + b;
        }

        #endregion
    }
}
