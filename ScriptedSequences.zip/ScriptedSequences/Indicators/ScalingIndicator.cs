using System;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    public class ScalingIndicator : ScriptedSequenceIndicator
    {
        #region Private variables
        
        /// <summary>
        /// Scale factorset independently by HOTween.
        /// </summary>
        public float _internal_scale;
        
        private float _currentTime = 0;
        
        private float _direction = 1;

        
        #endregion
        
        #region Public properties
        
        /// <summary>
        /// The time from min to max scale.
        /// </summary>
        public float ScalePeriod = 0.75f;
        
        /// <summary>
        /// The maximum scale amount this will tween to.
        /// </summary>
        public float ScaleMax = 2f;

        #endregion

        #region MonoBehaviour overrides
        
        /// <summary>
        /// Reposition the indicator based on the new state of the frame.
        /// </summary>
        protected override void Update()
        {
            base.Update();

            _currentTime += _direction * Time.deltaTime;
            
            if(_currentTime > ScalePeriod)
            {
                _direction = -1;
            }
            if(_currentTime < 0)
            {
                _direction = 1;
            }
            _internal_scale = InOutQuadratic(_currentTime, 0, ScaleMax, ScalePeriod);

            gameObject.transform.localScale = new Vector3(_internal_scale, 1, _internal_scale);
        }
        
        /// <summary>
        /// Called when the gameObject is disabled or destroyed.  Clean up.
        /// </summary>
        private void OnDisable()
        {
            StopScaling();    
        }
        
        #endregion
        
        #region Public methods
        
        public void StartScaling()
        {
            StopScaling();
                    
            _currentTime = 0;
            _direction = 1;
        }
        
        public void StopScaling()
        {
            _direction = 0;
        }
        
        #endregion
        
        #region Private methods
        
        protected override void UpdateIndicatorTransform()
        {
            base.UpdateIndicatorTransform();

            StartScaling();
        }
        
        #endregion
    }
}

