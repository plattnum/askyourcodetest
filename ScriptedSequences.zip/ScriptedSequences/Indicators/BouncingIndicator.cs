using System;
using UnityEngine;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;

namespace Kixeye.WCM.ScriptedSequences
{
    public class BouncingIndicator : ScriptedSequenceIndicator
    {
        #region Private variables
        
        public Vector3 _internal_arrowBounceOffset;

        private float _currentTime = 0;

        private float _direction = 1;

        
        #endregion
        
        #region Public properties
        
        /// <summary>
        /// The period of the bounce in seconds
        /// </summary>
        public float BouncePeriod = 0.75f;
        
        /// <summary>
        /// How high the bounce goes.
        /// </summary>
        public float BounceMagnitude = 25.0f;
        
        #endregion

        #region MonoBehaviour overrides
        
        /// <summary>
        /// Reposition the indicator based on the new state of the frame.
        /// </summary>
        protected override void Update()
        {
            base.Update();

            _currentTime += _direction * Time.deltaTime;
            
            if(_currentTime > BouncePeriod)
            {
                _direction = -1;
            }
            if(_currentTime < 0)
            {
                _direction = 1;
            }
            _internal_arrowBounceOffset.y = InOutQuadratic(_currentTime, 0, BounceMagnitude, BouncePeriod);

            gameObject.transform.localPosition = _internal_arrowBounceOffset;
        }
        
        /// <summary>
        /// Called when the gameObject is disabled or destroyed.  Clean up.
        /// </summary>
        private void OnDisable()
        {
            StopBouncing();    
        }
        
        #endregion
        
        #region Public methods
        
        public void StartBouncing()
        {
            StopBouncing();
                    
            _currentTime = 0;
            _direction = 1;
        }
        
        public void StopBouncing()
        {
            _direction = 0;
            _internal_arrowBounceOffset = Vector3.zero;
        }

        #endregion
        
        #region Private methods
        
        protected override void UpdateIndicatorTransform()
        {
            base.UpdateIndicatorTransform();

            StartBouncing();
        }
        
        #endregion
    }
}

