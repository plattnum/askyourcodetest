using System;
using System.Linq;
using System.Security.Permissions;
using Kixeye.WCM.ui;
using Ninject;
using UnityEngine;
using System.Collections.Generic;
using Kixeye.Core.Logging;
using ProtoBuf;

namespace Kixeye.WCM.ScriptedSequences
{
    [Serializable]
    public class UIElementDesignator : ISerializationCallbackReceiver
    {
        [ProtoContract(EnumPassthru = true)]
        public enum DesignationType
        {
            ByName,
            ByTag,
            BySquad,            // Special case that will return a specified squad selector button if there is a squad in it, or an alternative if not.
        }
        
        #region Serialized properties
        
        /// <summary>
        /// The way this designator is choosing the element
        /// </summary>
        [Newtonsoft.Json.JsonProperty("TypeOfDesignation")]
        [ProtoMember(1)]
        public DesignationType TypeOfDesignation = DesignationType.ByTag;
        
        /// <summary>
        /// The name of the element.
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("ElementName")]
        [ProtoMember(2)]
        public string ElementName;

        /// <summary>
        /// The tag of the element(s) to return.
        /// </summary>
        [Newtonsoft.Json.JsonProperty("Tag")]
        [ProtoMember(3)]
        public string Tag;

        /// <summary>
        /// The squad selector button to get
        /// </summary>        
        [Newtonsoft.Json.JsonProperty("SquadIndex")]
        [ProtoMember(4)]
        public int SquadIndex = 0;

        /// <summary>
        /// Flag used only by the UI
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public bool? TagIsDynamic;

        /// <summary>
        /// Flag used only by the UI
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public bool ModifiedViaDragAndDrop;

        #endregion


        #region Unity Serialization Support

        [SerializeField]
        protected NullableSerializedBool _tagIsDynamic;

        public void OnBeforeSerialize()
        {
            _tagIsDynamic = new NullableSerializedBool
            {
                Value = TagIsDynamic,
            };
        }

        public void OnAfterDeserialize()
        {
            if (_tagIsDynamic != null)
            {
                TagIsDynamic = _tagIsDynamic.Value;
            }
            _tagIsDynamic = null;
        }

        #endregion


        #region Public methods

        public bool IsCorrectUIElement(GameObject gameObject)
        {
            var uiElementTag = gameObject.GetComponent<UIElementTag>();
            return uiElementTag.Tags.Contains(Tag);
        }

        public GameObject GetUIElement()
        {
            // there may be multiple gameObjects with this tag (especially with pooled objects sitting in the pool disabled) so try to find the first enabled tagged gameObject and if that
            // fails then simply return the first/default one
            IEnumerable<GameObject> elements = GetUIElements();
            using (var enumer = elements.GetEnumerator ()) 
            {
                while (enumer.MoveNext ()) 
                {
                    if (enumer.Current != null && enumer.Current.activeInHierarchy) 
                    {
                        return enumer.Current;
                    }
                }
            }
                
            return elements.FirstOrDefault();
        }

        public IEnumerable<GameObject> GetUIElements()
        {
            List<GameObject> foundElements = new List<GameObject>();

            if (TypeOfDesignation == DesignationType.ByTag)
            {
                return UIElementTag.GetElementsWithElementTag(Tag);
            }
            else if (TypeOfDesignation == DesignationType.ByName)
            {
                GameObject UIElement = UIUtil.GetGameObjectByPath(ElementName);
                if (UIElement != null)
                {
                    foundElements.Add(UIElement);
                }
            }
            else if (TypeOfDesignation == DesignationType.BySquad)
            {
                if (WCMApplicationDirector.Instance.UI == null)
                {
                    Log.Error(this, null, "UIController not found.");
                    return Enumerable.Empty<GameObject>();
                }
                // special case that gets the squad button in the current hud, and moves to the next one
                // if the squad in the given button isn't viable

                BattleHUD battleHUD = WCMApplicationDirector.Instance.UI.CurrentHUD as BattleHUD;
                if (battleHUD != null)
                {
                    SquadCombatCardUGUI squadWidget = null;
                    int index = 0;
                    // squads may be rearanged and some left blank so SquadIndex might not correspond to the card index
                    // so we need to find out the position of the designated squad
                    for (; index < GameTypes.Constants.MAX_SQUADS_PER_PLATOON; index++)
                    {
                        squadWidget = battleHUD.GetSquadCardWidget(index);
                        if (squadWidget != null && squadWidget.Squad != null && squadWidget.Squad.SquadIndex == SquadIndex)
                        {
                            break;
                        }
                        squadWidget = null;
                    }

                    if (squadWidget == null)
                    {
                        index = 0;
                        squadWidget = battleHUD.GetSquadCardWidget(index);
                    }

                    while (squadWidget == null || squadWidget.Squad == null || squadWidget.Squad.LivingUnitCount == 0)
                    {
                        ++index;
                        if (index >= GameTypes.Constants.MAX_SQUADS_PER_PLATOON + 1)
                        {
                            index = 0;
                        }

                        if (index == SquadIndex)
                        {
                            // Wrapped around, couldn't find one
                            index = -1;
                            break;
                        }
                        squadWidget = battleHUD.GetSquadCardWidget(index);
                    }

                    if (index != -1 && squadWidget != null)
                    {
                        foundElements.Add(squadWidget.gameObject);
                    }
                }
            }

            return foundElements;
        }

        /// <summary>
        /// Returns a readable description of the element designated for error messages.
        /// </summary>
        /// <returns></returns>
        public string GetDescription(bool brief = false)
        {
            switch (TypeOfDesignation)
            {
                case DesignationType.ByName:
                    if (brief) return ElementName;
                    return string.Format("Element: {0}", ElementName);
                case DesignationType.ByTag:
                    if (brief) return Tag;
                    return string.Format("Tag: {0}", Tag);
                case DesignationType.BySquad:
                    return string.Format("Squad: {0}", SquadIndex);
            }

            return "Unknown";
        }

        #endregion

    }
}

