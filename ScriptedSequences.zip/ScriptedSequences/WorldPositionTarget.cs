using System;
using UnityEngine;
using GameTypes;

namespace Kixeye.WCM
{
    /// <summary>
    /// A UITarget to a world position.
    /// </summary>
    public class WorldPositionTarget : IUITarget
    {
        /// <summary>
        /// The world position to target.
        /// </summary>
        private readonly PositionData _worldPosition;

        private readonly bool _useUGUI;

        public WorldPositionTarget (PositionData worldPosition, bool useUGUI = false)
        {
            _worldPosition = worldPosition;
            _useUGUI = useUGUI;
        }

        #region IUITarget implementation

        /// <summary>
        /// Returns the screen position of the world position.
        /// </summary>
        /// <value>The screen position.</value>
        public PositionData ScreenPosition 
        {
            get 
            {
                if (_useUGUI)
                {
                    return Utilities.WorldToUGUIScreenPos(_worldPosition.ToVector()).ToPositionData();
                }
                return Utilities.WorldToUIScreenPos(_worldPosition.ToVector()).ToPositionData();
            }
        }

        #endregion
    }
}

