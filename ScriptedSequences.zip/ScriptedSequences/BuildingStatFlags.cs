using System;

namespace Kixeye.WCM.ScriptedSequences
{
    /// <summary>
    /// Flags indicating stat fields.
    /// </summary>
    [Flags]
    public enum BuildingStatFlags
    {
        Health = 1,
        StoredMetal = 2,
        StoredOil = 4,
        StoredThorium = 8
    }
}

