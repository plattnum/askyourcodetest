﻿using System.Collections.Generic;
using UnityEngine;

namespace Kixeye.WCM
{
    [System.Serializable]
    public class UIElementAllTags : ScriptableObject
    {
        public List<string> Tags = new List<string>();
    }

}
