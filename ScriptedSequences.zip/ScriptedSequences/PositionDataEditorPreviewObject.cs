using System;
using UnityEngine;
//using UnityEditor;
using GameTypes;

namespace Kixeye.WCM.ScriptedSequences
{
    // NOTE: This class can't be in the editor folder since it will be added to a GameObject.
    [ExecuteInEditMode]
    public class PositionDataEditorPreviewObject : MonoBehaviour
    {
        public Action<PositionData> OnPositionUpdated;
        
        [ExecuteInEditMode]
        void Update()
        {
            if (OnPositionUpdated != null &&
                transform.hasChanged)
            {
                OnPositionUpdated(transform.position.ToPositionData());
            }
                
        }
    }
}

