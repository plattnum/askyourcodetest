﻿//#define VERBOSE_LOGGING

using System.Collections.Generic;
using System.Diagnostics;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Kixeye.WCM.Events;
using Ninject;
using UnityEngine;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Kixeye.WCM
{
    public class UIElementTag : InjectableMonoBehaviour
    {
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(UIElementTag));
        #region Injected members

        /// <summary>
        /// The game's event manager
        /// </summary>
        [Inject]
        public EventManager _events
        {
            private get; 
            set;
        }

        #endregion

        /// <summary>
        /// List of all scene objects with UIElementTag attached
        /// </summary>
        private static readonly HashSet<GameObject> _allTaggedGameObjects = new HashSet<GameObject>();

        /// <summary>
        /// List of all tags used by scene objects (these do not get removed during a play session, only added to)
        /// </summary>
        private static readonly HashSet<string> _allGameObjectTags = new HashSet<string>();

        private List<Button> childButtons = new List<Button>();

        #region Public fields

        public List<string> Tags = new List<string>();

        #endregion

        // the following tags will be ignored when finding the returning default tags
        private static List<string> ignoreForDefaultTags = new List<string>() { "HUD_All" };


        protected override void Awake()
        {
            base.Awake();

            // pre-populate the static tags list with what is set in the inspector
            AddTagsToStaticList(Tags);
        }

        private static void AddTagsToStaticList(List<string> tags)
        {
            if (tags == null) {
                return;
            }

            for (int i = 0; i < tags.Count; i++) {
                AddTagToStaticList (tags [i]);
            }
        }

        private static void AddTagToStaticList(string tag)
        {
            // only add the tag if it doesn't exist in the hashset
            if (!string.IsNullOrEmpty(tag)) {
                _allGameObjectTags.Add(tag);
            }
        }

        public static HashSet<string>.Enumerator GetAllGameObjectTags()
        {
            return _allGameObjectTags.GetEnumerator();
        }

        public static HashSet<GameObject>.Enumerator GetAllTaggedGameObjects()
        {
            return _allTaggedGameObjects.GetEnumerator();
        }

        public static bool TagExists(string tag)
        {
            if (string.IsNullOrEmpty(tag))
            {
                return false;
            }

            return _allGameObjectTags.Contains(tag);
        }

        public void ReplaceTags(List<string> tags)
        {
            Tags = tags;
            AddTagsToStaticList(tags);
            OnTagsChanged();
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                if (gameObject != null && tags != null)
                {
                    _logger.Debug(null, "UI tags replaced for {0}, new values are '{1}'", gameObject.name, string.Join(",", tags.ToArray()));
                } 
                else if (tags != null)
                {
                    _logger.Debug(null, "UI tags replaced for unknown object, new values are '{0}'", string.Join(",", tags.ToArray()));
                }
            }
        }

        public void AddTag(string name)
        {
            if (!Tags.Contains(name))
            {
                Tags.Add(name);
                AddTagToStaticList(name);
                OnTagsChanged();
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    if (gameObject != null)
                    {
                        _logger.Debug(null, "UI tag added to {0}, added tag is '{1}'", gameObject.name, name);
                    }
                    else
                    {
                        _logger.Debug(null, "UI tag added to unknown object, added tag is '{0}'", name);
                    }
                }
            }
        }

        public void RemoveTag(string name)
        {
            if (Tags.Contains(name))
            {
                Tags.Remove(name);
                OnTagsChanged();
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    if (gameObject != null)
                    {
                        _logger.Debug(null, "UI tag removed from {0}, removed tag is '{1}'", gameObject.name, name);
                    } 
                    else
                    {
                        _logger.Debug(null, "UI tag removed from unknown object, removed tag is '{0}'", name);
                    }
                }
            }
        }

        public void RemoveAllTags()
        {
            Tags.Clear();
            OnTagsChanged();
            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                if (gameObject != null)
                {
                    _logger.Debug(null, "All UI tags removed from {0}", gameObject.name);
                } 
                else
                {
                    _logger.Debug(null, "All UI tags removed from unknown object");
                }
            }
        }

        private void OnTagsChanged()
        {
            if (gameObject != null
                && WCMApplicationDirector.Instance != null
                && WCMApplicationDirector.Instance.Events != null)
                WCMApplicationDirector.Instance.Events.HandleEvent(new ScriptedSequenceUIElementEvent(gameObject, gameObject.activeInHierarchy ? ScriptedSequenceUIElementEvent.EventType.Activated : ScriptedSequenceUIElementEvent.EventType.Deactivated));
        }

        public string GetDefaultTag()
        {
            // return the first tag in the list
            if (Tags.Count > 0) 
            {
                // special case, if this element has multiple tags don't return tags from the default ignore list
                for (int i = 0; i < Tags.Count; i++) 
                {
                    if (!ignoreForDefaultTags.Contains(Tags[i]))
                    {
                        return Tags [i];
                    }
                }

                // default to first tag if all the tags are in the ignore list
                return Tags [0];
            }

            return null;
        }

        /// <summary>
        /// Gets the tag that last changed state, or the default tag if we can't determine that
        /// </summary>
        /// <returns>tag.</returns>
        public string GetLastChangedStateOrDefaultTag()
        {
            if (Tags.Count == 1) 
            {
                return Tags [0];
            } 
            else if (Tags.Count > 1) 
            {
                float lastChangedTime = InteractionManager.Instance.GetUIStateChangedTime(Tags [0]);
                int lastChangedOffset = InteractionManager.Instance.GetUIStateChangedTimeOffset(Tags [0]);
                string lastChangedTag = Tags [0];
                for (int i = 1; i < Tags.Count; i++) 
                {
                    float lct = InteractionManager.Instance.GetUIStateChangedTime(Tags [i]);
                    int lco = InteractionManager.Instance.GetUIStateChangedTimeOffset(Tags [i]);
                    if (lct < lastChangedTime) {
                        lastChangedTime = lct;
                        lastChangedOffset = lco;
                        lastChangedTag = Tags [i];
                    }
                    else if (lct == lastChangedTime && lco < lastChangedOffset)
                    {
                        lastChangedTime = lct;
                        lastChangedOffset = lco;
                        lastChangedTag = Tags [i];
                    }
                }

                return lastChangedTag;
            }

            return GetDefaultTag();
        }

        /// <summary>
        /// MonoBehaviour callback from Unity, used to fire one of our events to notify about enabled state.
        /// </summary>
        public void OnEnable()
        {
            LogInfo("OnEnable()");

            if (gameObject == null) 
            {
                LogInfo("OnEnable(): gameObject is null while registering it as tagged UI widget");
                return;
            }

            if (_allTaggedGameObjects.Add(gameObject)) 
            {
                LogInfo(string.Format("OnEnable(): registering {0} as tagged UI widget", gameObject.XPath()));
            } 
            else 
            {
                LogInfo(string.Format("OnEnable(): {0} is already registered as tagged UI widget", gameObject.XPath()));
            }
                
            // first check with the InteractionManager to see if it knows what state this gameOject should be in
            string tag = GetLastChangedStateOrDefaultTag();
            InteractionManager.UI_STATE state = InteractionManager.Instance.GetUIState(tag);
            InteractionManager.UI_STATE_PRIORITY priority = InteractionManager.Instance.GetUIStatePriority(tag);
            switch (state) 
            {
            case InteractionManager.UI_STATE.NOTACTIVE:
                // Don't let ourselves be shown if we should be hidden.
                LogInfo("OnEnable() deactivating object because we are hidden");
                InteractionManager.Instance.SetUIState(tag, InteractionManager.UI_STATE.NOTACTIVE, priority, false, true);
                break;
            case InteractionManager.UI_STATE.UNKNOWN:
            case InteractionManager.UI_STATE.ACTIVE:
            default:
                // if the state was unknown then there is no state set (set it)
                if (state == InteractionManager.UI_STATE.UNKNOWN) 
                {
                    // if we are adding the tag for the first time, let's add every tag that is unset for this gameObject in case there are multiple
                    for (int i = 0; i < Tags.Count; i++) 
                    {
                        if (!string.IsNullOrEmpty(Tags [i]) && InteractionManager.Instance.GetUIState(Tags [i]) == InteractionManager.UI_STATE.UNKNOWN) 
                        {
                            InteractionManager.Instance.SetUIState(Tags [i], InteractionManager.UI_STATE.ACTIVE);
                        }
                    }
                }
                    
                LogInfo("OnEnable() recorded intentional enable");
                _events.HandleEvent (new ScriptedSequenceUIElementEvent(gameObject, ScriptedSequenceUIElementEvent.EventType.Activated));

                GetComponentsInChildren<Button>(childButtons);
                for (int i = 0; i < childButtons.Count; i++) 
                {
                    childButtons [i].onClick.AddListener(OnButtonClicked);
                }
                break;   
            }
        }

        /// <summary>
        /// MonoBehaviour callback from Unity, used to fire one of our events to notify about enabled state.
        /// </summary>
        public void OnDisable()
        {
            LogInfo("OnDisable()");

            _events.HandleEvent( new ScriptedSequenceUIElementEvent( gameObject, ScriptedSequenceUIElementEvent.EventType.Deactivated ) );

            GetComponentsInChildren<Button>(childButtons);
            for (int i = 0; i < childButtons.Count; i++) 
            {
                childButtons[i].onClick.RemoveListener(OnButtonClicked);
            }
        }

        public void OnDestroy()
        {
            _allTaggedGameObjects.Remove(gameObject);
        }

        private void OnElementClicked( GameObject sender )
        {
            _events.HandleEvent( new ScriptedSequenceUIElementEvent( gameObject, ScriptedSequenceUIElementEvent.EventType.Pressed ) );
        }

        private void OnButtonClicked()
        {
            _events.HandleEvent(new ScriptedSequenceUIElementEvent(gameObject, ScriptedSequenceUIElementEvent.EventType.Pressed));
        }

        /// <summary>
        /// Finds all game objects under the UI root that have the given tag in their tag list.
        /// WARNING: calling this often is NOT efficient because it creates and allocates a new list every time. Consider using GetAllTaggedGameObjects() and iterating over the objects instead
        /// </summary>
        /// <param name="tag">The single tag to search for.</param>
        /// <returns>A list containing all found game objects.</returns>
        public static List<GameObject> GetElementsWithElementTag(string tag)
        {
            List<GameObject> foundList = new List<GameObject>();

            using (var enumer = _allTaggedGameObjects.GetEnumerator())
            {
                while (enumer.MoveNext()) 
                {
                    var rootGameObject = enumer.Current;
                    UIElementTag tags = (rootGameObject != null) ? rootGameObject.GetComponent<UIElementTag>() : null;
                    if (tags != null && tags.Tags.Contains(tag)) {
                        foundList.Add(rootGameObject);
                    }
                }
            }

            return foundList;
        }

#if UNITY_EDITOR

        private const string allTagsAssetPath = "Assets/Editor/UIElementTags.asset";
        private static UIElementAllTags _allTagsObject = null;

        public static List<string> GetAllUsedTags()
        {
            if (_allTagsObject == null)
            {
                _allTagsObject = AssetDatabase.LoadAssetAtPath( allTagsAssetPath, typeof(UIElementAllTags) ) as UIElementAllTags;

                if (_allTagsObject == null)
                {
                    _allTagsObject = (UIElementAllTags)ScriptableObject.CreateInstance(typeof(UIElementAllTags));
                    if (_allTagsObject == null)
                    {
                        _logger.Error("UIElementTag", "Failed to create a UIElementAllTags");
                        return null;
                    }
                    AssetDatabase.CreateAsset( _allTagsObject, allTagsAssetPath );

                }
            }

            return _allTagsObject.Tags;
        }

        public static void AddToUsedTags( string newTag )
        {
            List<string> allTags = GetAllUsedTags();
            if (allTags != null)
            {
                allTags.Add( newTag );
                EditorUtility.SetDirty( _allTagsObject );
            }
        }

#endif

        /// <summary>
        /// Sets the forced invisibility of the tagged component.  Setting this 
        /// value can hide an active object and prevent an inactive object from
        /// being activated. 
        /// </summary>
        public void SetHidden(bool hide, InteractionManager.UI_STATE_PRIORITY priority, string tag="", bool force = false)
        {
            // if no tag was passed use the default tag on this element
            if (string.IsNullOrEmpty(tag)) 
            {
                tag = GetDefaultTag();
            }
                
            LogInfo("SetHidden({0})", hide);
            if (!hide)
            {
                InteractionManager.Instance.SetUIState(tag, InteractionManager.UI_STATE.ACTIVE, priority, force);
            }
            else if (hide && (isActiveAndEnabled || force))
            {
                InteractionManager.Instance.SetUIState(tag, InteractionManager.UI_STATE.NOTACTIVE, priority, force);
            }
            else
            {
                LogInfo("SetHidden({0}) doing nothing", hide);
            }
        }

        [Conditional("VERBOSE_LOGGING")]
        private void LogInfo(string message, params object[] args)
        {
            if (_logger.IsEnabled(LogMessageLevel.Info))
            {
                _logger.Info(null, 
                    "{0}: {1} (isActiveAndEnabled: {2})",
                    gameObject.name,
                    message.FormatWith(args),
                    isActiveAndEnabled);
            }
        }

        /// <summary>
        /// Initialization method to smooth-out any issues with object pooling.
        /// Any values which game logic assume are their default initialized values should be set here.
        /// </summary>
        public void Initialize()
        {
        }
    }
}
