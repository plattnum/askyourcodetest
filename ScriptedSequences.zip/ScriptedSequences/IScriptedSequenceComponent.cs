namespace Kixeye.WCM.ScriptedSequences
{
    public interface IScriptedSequenceComponent
    {
        ScriptedSequence ScriptedSequence { get; }

        /// <summary>
        /// Gets the the descriptive name for this component for debugging.
        /// </summary>
        string GetDebugName();

        /// <summary>
        /// Gets the the fully-qualified descriptive name for this component for debugging.
        /// </summary>
        string GetDebugNameFull();
    }
}