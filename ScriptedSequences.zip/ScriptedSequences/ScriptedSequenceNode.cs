using System;
using System.Collections.Generic;
using Kixeye.Common;
using Kixeye.Core.Logging;
using ILogger = Kixeye.Core.Logging.ILogger;
using Newtonsoft.Json;
using ProtoBuf;
using System.ComponentModel;
using GameTypes;
using Kixeye.Core.Threading;
using Kixeye.Core.Analytics;

namespace Kixeye.WCM.ScriptedSequences
{
    [JsonObject(MemberSerialization.OptIn)]
    [Serializable]
    public class ScriptedSequenceNode : IScriptedSequenceComponentParent, ISaveAsset
    {
        #region Serialized Properties
        /// <summary>
        /// A unique identifier for the node (within its sequence).
        /// </summary>
        [JsonProperty("NodeID")]
        [ProtoMember(1)]
        [DefaultValue(-1)]
        public int NodeID = -1;

        /// <summary>
        /// A descriptive name for this node.
        /// </summary>
        [JsonProperty("Name")]
        [ProtoMember(2)]
        public string Name;

        /// <summary>
        /// If true this node will disable all its conditions when they are all met so the node won't be repeated.
        /// </summary>
        [JsonProperty("DisableOnComplete")]
        [ProtoMember(3)]
        [DefaultValue(true)]
        public bool DisableOnComplete = true;

        /// <summary>
        /// The conditions that must be met for this sequence to activate.
        /// </summary>
        [JsonProperty("Conditions")]
        [ProtoMember(4)]
        public List<ScriptedSequenceCondition> Conditions
        {
            get
            {
                if (_conditions == null)
                {
                    _conditions = new List<ScriptedSequenceCondition>();
                }
                return _conditions;
            }
            set
            {
                _conditions = value;
            }
        }
        [UnityEngine.SerializeField]
        private List<ScriptedSequenceCondition> _conditions = new List<ScriptedSequenceCondition>();

        /// <summary>
        /// The actions that are executed when this sequence activates.
        /// </summary>
        [JsonProperty("Actions")]
        [ProtoMember(5)]
        public List<ScriptedSequenceAction> Actions
        {
            get
            {
                if (_actions == null)
                {
                    _actions = new List<ScriptedSequenceAction>();
                }
                return _actions;
            }
            set
            {
                _actions = value;
            }
        }
        [UnityEngine.SerializeField]
        private List<ScriptedSequenceAction> _actions = null;

        public void WriteTo(AssetSaver saver)
        {
#if UNITY_EDITOR
            Actions.ForAll(it => it.WriteTo(saver));
            Conditions.ForAll(it => it.WriteTo(saver));
#endif
        }

        /// <summary>
        /// Whether we should fail and bail upon hitting an error (useful for loading failures)
        /// </summary>
        [JsonProperty("FailOnError")]
        [ProtoMember(6)]
        public bool FailOnError = false;

        /// <summary>
        /// If true, this node will disable all its conditions when the mission is played again.
        /// </summary>
        [JsonProperty("DisableOnReplay"), DefaultValue(true)]
        [ProtoMember(7)]
        public bool DisableOnReplay = true;

        public ScriptedSequenceNode PreviousNode
        {
            get
            {
                ScriptedSequenceNode previousNode = null;
                if (Parent != null)
                {
                    foreach (var node in Parent.Nodes)
                    {
                        if (node.NodeID == NodeID)
                        {
                            break;
                        }
                        previousNode = node;
                    }
                }
                return previousNode;
            }
        }

        public ScriptedSequenceNode NextNode
        {
            get
            {
                if (Parent == null)
                {
                    return null;
                }
                ScriptedSequenceNode previousNode = null;
                foreach (var node in Parent.Nodes)
                {
                    if (previousNode == this)
                    {
                        return node;
                    }
                    previousNode = node;
                }
                return null;
            }
        }

        /// <summary>
        /// Returns the ID of the node previous to this
        /// </summary>
        private int PreviousNodeID
        {
            get
            {
                if (Parent == null)
                {
                    return -1;
                }
                var previousNode = PreviousNode;
                if (previousNode == null)
                {
                    return -1;
                }
                return previousNode.NodeID;
            }
        }

        /// <summary>
        /// Whether we should require the previous node to be complete for this one to be active
        /// </summary>
        //[JsonProperty("RequirePreviousNodeCompletion")]
        //[ProtoMember(8)]
        //public bool RequirePreviousNodeCompletion = false;
        public bool RequirePreviousNodeCompletion
        {
            get
            {
                int previousNodeID = PreviousNodeID;
                foreach (var condition in Conditions)
                {
                    if (condition.GetType() == typeof(SSConditionNodeComplete))
                    {
                        if ((condition as SSConditionNodeComplete).NodeID == previousNodeID)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            set
            {
                int previousNodeID = PreviousNodeID;
                if (value)
                {
                    // check if we don't already have a node complete condition for the previous node
                    foreach (var condition in Conditions)
                    {
                        if (condition.GetType() == typeof(SSConditionNodeComplete))
                        {
                            if ((condition as SSConditionNodeComplete).NodeID == previousNodeID)
                            {
                                // we already have a 'SSConditionNodeComplete' for the previous node
                                return;
                            }
                        }
                    }
                    // add a node complete condition for the previous node
                    SSConditionNodeComplete nodeCompleteCondition = new SSConditionNodeComplete();
                    nodeCompleteCondition.NodeID = previousNodeID;
                    nodeCompleteCondition.Parent = this;
                    Conditions.Insert(0, nodeCompleteCondition);
                }
                else
                {
                    // check if we have a node complete condition for the previous node
                    foreach (var condition in Conditions)
                    {
                        if (condition.GetType() == typeof(SSConditionNodeComplete))
                        {
                            if ((condition as SSConditionNodeComplete).NodeID == previousNodeID)
                            {
                                // remove the condition
                                Conditions.Remove(condition);
                                return;
                            }
                        }
                    }
                }
            }
        }

        [JsonProperty("Description")]
        [ProtoMember(8)] // No need to distribute to clients, but if we don't serializa here we lose descriptions when live-editing in-game.
        public string Description { get; set; }

        [JsonProperty("ReenableOnComplete")]
        [ProtoMember(9)]
        [DefaultValue(false)] // Keep json diffs minimal
        public bool ReenableOnComplete;

        #endregion

        #region Public Variables

        public ScriptedSequencesController ScriptedSequences { get { return Parent == null ? null : Parent.ScriptedSequences; } }

        public ScriptedSequence ScriptedSequence { get { return Parent; } }

        [JsonIgnore]
        public IEnumerable<ScriptedSequenceComponent> Components
        {
            get
            {
                for (int j = 0, count = Conditions.Count; j < count; ++j)
                {
                    yield return Conditions[j];
                }
                for (int i = 0, count = Actions.Count; i < count; ++i)
                {
                    yield return Actions[i];
                }
            }
        }

        /// <summary>
        /// The ScriptedSequence that owns this step.
        /// </summary>
        [NonSerialized]
        public ScriptedSequence Parent = null;

        /// <summary>
        /// The callback to notify the sequence when all the conditions on this node have been met.
        /// </summary>
        public event Action<ScriptedSequenceNode> OnAllConditionsMet = null;

        /// <summary>
        /// The callback to notify the sequence when all the actions of the node have completed.
        /// </summary>
        public event Action<ScriptedSequenceNode, bool> OnAllActionsComplete = null;

        /// <summary>
        /// Returns the actions complete state.
        /// </summary>
        public bool AllActionsComplete
        {
            get
            {
                return _allActionsComplete;
            }
            set
            {
                _allActionsComplete = value;
            }
        }
        private bool _allActionsComplete = false;
        #endregion

        #region Private Variables
        /// <summary>
        /// The static logger instance for this class.
        /// </summary>
        protected static readonly ILogger _logger = Log.GetLoggerForType(typeof(ScriptedSequenceNode));
        /// <summary>
        /// The token created when this node is activated, so we can abort all current actions on Reset.
        /// </summary>
        private IAsyncToken<ISimpleAsyncToken[]> _actToken;
        #endregion

        #region Constructor
        public ScriptedSequenceNode()
        {
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Registers all the conditions in this node to watch for their condition being met and triggering this node.
        /// </summary>
        /// <param name='onAllConditionsMetCallback'>
        /// The callback to notify the sequence when all the conditions on this node have been met.
        /// </param>
        public void Initialize(ScriptedSequence parent, Action<ScriptedSequenceNode> onAllConditionsMetCallback)
        {
            Parent = parent;
            OnAllConditionsMet += onAllConditionsMetCallback;

            // initialize the list of conditions
            int i = 0;
            foreach (var condition in Conditions.ToArray())
            {
                i++;
                if (condition == null)
                {
                    Log.Error(this, "Found a NULL condition in " + GetDebugNameFull() + " slot " + i + " - Aborting Initialize.");
                    return;
                }
                // make sure that the 'SSConditionNodeComplete' conditions are placed first
                if (condition.GetType() == typeof(SSConditionNodeComplete))
                {
                    Conditions.Remove(condition);
                    Conditions.Insert(0, condition);
                }
                condition.Enabled = false;
                condition.Initialize(this);
            }

            // initialize the list of actions
            foreach (ScriptedSequenceAction action in Actions)
            {
                action.Initialize(this);
            }
        }

        /// <summary>
        /// Resets condition enabled states so the node can be re-executed properly
        /// </summary>
        public void Reset()
        {
            for (int i = 0, count = Conditions.Count; i < count; ++i)
            {
                Conditions[i].Reset();
                Conditions[i].Enabled = false;
                Conditions[i].Met = false;
            }

            for (int i = 0, count = Actions.Count; i < count; ++i)
            {
                //  TODO: move this into a Reset() call. Update IScriptedSequenceComponent interface to have Reset(). Refactor as needed.
                Actions[i].ResetAsyncToken();
                Actions[i].Status = Status.Dormant;
            }

            AllConditionsMet = false;
            AllActionsComplete = false;
            if (_actToken != null)
            {
                _actToken.ClearCallbacks();
                _actToken = null;
            }
        }

        /// <summary>
        /// Gates this node so that once all the conditions are met the actions will activate but won't activate again until
        /// the conditions have been un-met and met again.
        /// </summary>
        public bool AllConditionsMet
        {
            get { return _allConditionsMet; }
            set { _allConditionsMet = value; }
        }
        private bool _allConditionsMet = false;

        /// <summary>
        /// Enable the next condition in the list
        /// </summary>
        /// <param name=""></param>
        public static void EnableNextCondition(List<ScriptedSequenceCondition> conditionList, ScriptedSequenceCondition conditionThatChanged)
        {
            var i = conditionList.IndexOf(conditionThatChanged);
            if (i < conditionList.Count - 1)
            {
                var conditionToEnable = conditionList[i + 1];
                conditionToEnable.Enabled = true;
            }
        }

        /// <summary>
        /// Called whenever a child condition's status has changed.
        /// </summary>
        /// <param name="conditionThatChanged">Condition that changed.</param>
        public void OnConditionMetChanged(ScriptedSequenceCondition conditionThatChanged)
        {
            if (AllConditionsMet && DisableOnComplete)
            {
                return;
            }

            if (conditionThatChanged != null && !conditionThatChanged.Enabled)
            {
                if (_logger.IsEnabled(LogMessageLevel.Warn))
                {
                    _logger.Warn(conditionThatChanged.GetDebugNameFull() + " has had its status change but it is disabled.");
                }
                return;
            }

            if (Conditions.Count > 0)
            {
                EnableNextCondition(Conditions, conditionThatChanged);

                bool allMet = true;
                foreach (var condition in Conditions)
                {
                    if (condition.Met == false)
                    {
                        allMet = false;
                        break;
                    }
                }
                if (allMet && !AllConditionsMet)
                {
                    AllConditionsMet = true;
                    if (DisableOnComplete)
                    {
                        for (int i = 0, count = Conditions.Count; i < count; ++i)
                        {
                            Conditions[i].Enabled = false;
                        }
                    }

                    // Be sure to activate *after* disabling the conditions - this might be the last activation
                    // and it might reset the sequence
                    Activate();
                }

                if (!allMet)
                {
                    if (AllConditionsMet && OnAllActionsComplete != null)
                    {
                        // e.g. a condition becomes unmet after we've activated.
                        OnAllActionsComplete(this, false);
                    }
                    AllConditionsMet = false;
                    AllActionsComplete = false;
                }
            }
            else
            {
                Log.Error(this, "A condition changed state but this node has no conditions?  How? (" + GetDebugNameFull() + ")");
            }
        }

        /// <summary>
        /// Gets the the fully-qualified descriptive name of this node for debugging.
        /// </summary>
        virtual public string GetDebugNameFull()
        {
            return (Parent != null ? Parent.Name : "<NULL>") + ":" + GetDebugName();
        }

        /// <summary>
        /// Enables the first condition in the node.
        /// </summary>
        public void Enable(PlayerDetailsData localPlayerDetails)
        {
            if (DisableOnReplay && Parent.TimesPlayerHasCompleted(localPlayerDetails) > 0)
            {
                return;
            }
            if (Conditions.Count > 0 && Conditions[0] != null)
            {
                Conditions[0].Enabled = true;
            }
        }

        /// <summary>
        /// Called when all of the conditions have been met at the same time.
        /// </summary>
        public void Activate()
        {
            if (OnAllConditionsMet == null)
            {
                if (_logger.IsEnabled(LogMessageLevel.Error))
                {
                    _logger.Error("Scripted sequence " + Parent.Name + " has tried to execute without being properly started.");
                }
                return;
            }

            // Handle global breakpoint
            if (ScriptedSequences.Breakpoint != null)
            {
                Actions.ForEach(_ => _.Status = Status.Waiting);
                ScriptedSequences.Breakpoint.Ready(_ => Activate());
                return;
            }

            // At this point we know the node is activated;
            // let's send funnel message log
            Parent.SendFunnelStepMessage(NodeID + "__" + Name);

            List<ISimpleAsyncToken> tokenList = new List<ISimpleAsyncToken>();
            string fullDebugName = GetDebugNameFull();
            foreach (ScriptedSequenceAction action in Actions)
            {
                if (action == null)
                {
                    Log.Error(this, null, "{0}: Action is null in node.", fullDebugName);
                    continue;
                }
                if (_logger.IsEnabled(LogMessageLevel.Debug))
                {
                    _logger.Debug(null, "{0}: Calling Act(): {1}",
                              fullDebugName,
                              action.GetDebugName());
                }
                ISimpleAsyncToken token;
                token = ActWithStatus(action);
                tokenList.Add(token);
            }

            if (_logger.IsEnabled(LogMessageLevel.Debug))
            {
                _logger.Debug(null, "{0}: OnAllConditionsMet", fullDebugName);
            }

            if (fullDebugName.Equals("Z_Combat_NUX_01_Setup:Node 4"))
            {
                LoadTimeReport.GetReport("CombatNux").MarkTimestamp("CombatNuxLoad");
                LoadTimeReport.GetReport("CombatNux").PrintReport();
                WCMApplicationDirector.Instance.Analytics.EndHeartbeat();
                WCMApplicationDirector.Instance.Analytics.EndLoadSequence("combat_nux");
                WCMApplicationDirector.Instance.Analytics.StartLoadSequence("combat_nux_start");
            }

            if (fullDebugName.Equals("Z_Combat_NUX_05_BattleEnd:Reload Player Data"))
            {
                WCMApplicationDirector.Instance.Analytics.EndLoadSequence("combat_nux_end");
                WCMApplicationDirector.Instance.Analytics.StartLoadSequence("combat_nux_end");
            }

            OnAllConditionsMet(this);

            var frameCount = UnityEngine.Time.frameCount;
            _actToken = SimpleAsyncToken.PessimisticReduce(tokenList);
            _actToken.ReadyUnity(actResponse =>
            {
                if (actResponse == _actToken)
                {
                    _actToken = null;
                }

                bool failed = false;
                if (actResponse.Success)
                {
                    for (int i = 0, len = actResponse.Value.Length; i < len; i++)
                    {
                        if (!actResponse.Value[i].Success)
                        {
                            failed = true;
                            ScriptedSequence.LogError(string.Format("{0} Failed to complete an action: {1}", fullDebugName, actResponse.Value[i].Error));
                        }
                    }
                }

                if (FailOnError && failed)
                {
                    // TODO: handle failure? v1 of WCRA reloaded game.
                    if (_logger.IsEnabled(LogMessageLevel.Debug))
                    {
                        _logger.Debug(null, "{0}: FailOnError", fullDebugName);
                    }
                }
                else
                {
                    if (_logger.IsEnabled(LogMessageLevel.Debug))
                    {
                        _logger.Debug(null, "{0}: OnAllActionsComplete", fullDebugName);
                    }
                    AllActionsComplete = true;
                    if (OnAllActionsComplete != null)
                    {
                        OnAllActionsComplete(this, true);
                    }
                }

                if (ReenableOnComplete)
                {
                    // Prevent infinite loops.
                    if (frameCount != UnityEngine.Time.frameCount)
                    {
                        Reenable();
                    }
                    else
                    {
                        CoroutineSynchronizationContext.Instance.Post(_ => Reenable(), null);
                    }
                }
            });
        }

        private void Reenable()
        {
            AllConditionsMet = false;
            AllActionsComplete = false;
            for (int i = 0, count = Conditions.Count; i < count; ++i)
            {
                Conditions[i].Reset(); // Met -> false
            }
            if (Conditions.Count > 0)
            {
                Conditions[0].Enabled = true;
            }
            else
            {
                Activate();
            }
        }

        private static ISimpleAsyncToken ActWithStatus(ScriptedSequenceAction action)
        {
            action.Status = Status.Running;
            ISimpleAsyncToken token;
            try
            {
                token = action.Act();
            }
            catch (Exception exception)
            {
                token = new SimpleAsyncToken(exception);
            }
            if (token == null)
            {
                token = new SimpleAsyncToken(new NullReferenceException("Action returned null from Act()."));
            }
            token.Ready(_ =>
            {
                if (_.Success)
                {
                    action.Status = Status.Complete;
                    action.StatusMessage = null;
                    action.Exception = null;
                }
                else
                {
                    action.Status = Status.Failed;
                    action.StatusMessage = _.Error.Message;
                    action.Exception = _.Error;
                }
            });
            return token;
        }

        /// <summary>
        /// Gets the the descriptive name of this node for debugging.
        /// </summary>
        virtual public string GetDebugName()
        {
            return Name;
        }

        public void Migrate(bool onCreate)
        {
            this.MigrateConditionsAndActions(onCreate);
        }

        #endregion Public methods
    }
}